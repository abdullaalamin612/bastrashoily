import React, { useState, useMemo } from 'react';
import { useShop } from '../../context/ShopContext';
import { Category } from '../../types';
import {
  Layers,
  Plus,
  Edit2,
  Trash2,
  Image as ImageIcon,
  Eye,
  EyeOff,
  Search,
  ArrowUpDown,
  CheckCircle2,
  AlertCircle,
  Archive,
  Sparkles,
  ArrowUp,
  ArrowDown,
  FolderTree,
  ExternalLink,
} from 'lucide-react';

const MAIN_CATEGORIES_LIST = [
  { id: 'MEN', name: 'MEN', banglaName: 'পুরুষ' },
  { id: 'WOMEN', name: 'WOMEN', banglaName: 'নারী' },
  { id: 'KIDS', name: 'KIDS', banglaName: 'শিশু' },
  { id: 'OTHERS & ACCESSORIES', name: 'OTHERS & ACCESSORIES', banglaName: 'অন্যান্য ও আনুষঙ্গিক' },
];

export const CategoryManagementModule: React.FC = () => {
  const { categories, addCategory, updateCategory, deleteCategory, products, showToast } = useShop();

  const [activeTab, setActiveTab] = useState<'subcategories' | 'main_categories'>('subcategories');
  const [selectedMainFilter, setSelectedMainFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Editing state
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Active / Archived filter
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'archived'>('all');

  // Subcategories
  const subcategories = useMemo(() => {
    return categories.filter((c) => !c.isMain);
  }, [categories]);

  // Main Categories
  const mainCategories = useMemo(() => {
    return categories.filter((c) => c.isMain);
  }, [categories]);

  // Filtered subcategories
  const filteredSubcategories = useMemo(() => {
    return subcategories.filter((c) => {
      if (selectedMainFilter !== 'all' && c.parentCategory !== selectedMainFilter) {
        return false;
      }
      if (statusFilter === 'active' && (c.isActive === false || c.isArchived)) return false;
      if (statusFilter === 'archived' && !c.isArchived) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = c.name?.toLowerCase().includes(q);
        const matchesBn = c.banglaName?.toLowerCase().includes(q);
        const matchesSlug = c.slug?.toLowerCase().includes(q);
        return matchesName || matchesBn || matchesSlug;
      }
      return true;
    }).sort((a, b) => (a.circleGalleryOrder || 0) - (b.circleGalleryOrder || 0));
  }, [subcategories, selectedMainFilter, statusFilter, searchQuery]);

  // Product counts per category
  const productCountMap = useMemo(() => {
    const map: Record<string, number> = {};
    products.forEach((p) => {
      const catKey = p.subCategory || p.categoryId;
      if (catKey) {
        map[catKey] = (map[catKey] || 0) + 1;
      }
    });
    return map;
  }, [products]);

  const handleOpenAddModal = (defaultParent?: string) => {
    setEditingCategory({
      name: '',
      banglaName: '',
      slug: '',
      parentCategory: defaultParent || (selectedMainFilter !== 'all' ? selectedMainFilter : 'MEN'),
      image: '',
      banner: '',
      circleImage: '',
      showInCircleGallery: true,
      circleGalleryOrder: subcategories.length + 1,
      isActive: true,
      description: '',
      seoTitle: '',
      seoDescription: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (cat: Category) => {
    setEditingCategory({ ...cat });
    setIsModalOpen(true);
  };

  const handleNameChange = (name: string) => {
    if (!editingCategory) return;
    const slug = name
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '');

    setEditingCategory((prev) => ({
      ...prev,
      name,
      slug: prev?.slug ? prev.slug : slug,
      seoTitle: prev?.seoTitle ? prev.seoTitle : `${name} - বস্ত্র শৈলী`,
    }));
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory?.name?.trim() || !editingCategory?.banglaName?.trim()) {
      showToast('ইংরেজি ও বাংলা নাম উভয়ই আবশ্যক!');
      return;
    }

    const finalSlug = (editingCategory.slug || editingCategory.name)
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-');

    setIsSubmitting(true);
    try {
      if (editingCategory.id) {
        await updateCategory(editingCategory.id, {
          ...editingCategory,
          slug: finalSlug,
          circleGalleryOrder: Number(editingCategory.circleGalleryOrder || 0),
        });
        showToast('ক্যাটাগরি সফলভাবে হালনাগাদ করা হয়েছে');
      } else {
        await addCategory({
          name: editingCategory.name.trim(),
          banglaName: editingCategory.banglaName.trim(),
          slug: finalSlug,
          parentCategory: editingCategory.parentCategory || 'MEN',
          image: editingCategory.image || editingCategory.circleImage || '',
          banner: editingCategory.banner || '',
          circleImage: editingCategory.circleImage || editingCategory.image || '',
          showInCircleGallery: editingCategory.showInCircleGallery !== false,
          order: Number(editingCategory.circleGalleryOrder || subcategories.length + 1),
          circleGalleryOrder: Number(editingCategory.circleGalleryOrder || subcategories.length + 1),
          isActive: editingCategory.isActive !== false,
          description: editingCategory.description || '',
          seoTitle: editingCategory.seoTitle || '',
          seoDescription: editingCategory.seoDescription || '',
          isMain: false,
        });
        showToast('নতুন ক্যাটাগরি সফলভাবে যুক্ত করা হয়েছে');
      }
      setIsModalOpen(false);
      setEditingCategory(null);
    } catch {
      showToast('ক্যাটাগরি সংরক্ষণে সমস্যা হয়েছে');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteOrArchive = async (cat: Category) => {
    const linkedCount = productCountMap[cat.slug] || productCountMap[cat.id] || productCountMap[cat.name] || 0;
    const confirmMessage = linkedCount > 0
      ? `"${cat.banglaName}" ক্যাটাগরির সাথে ${linkedCount}টি পণ্য যুক্ত আছে। এটি ডাটাবেজ থেকে স্থায়ীভাবে মুছে ফেলার বদলে নিরাপদে নিষ্ক্রিয় (Archive) করা হবে। আপনি কি নিশ্চিত?`
      : `আপনি কি "${cat.banglaName}" ক্যাটাগরি মুছে ফেলতে চান?`;

    if (!window.confirm(confirmMessage)) return;

    try {
      await deleteCategory(cat.id);
    } catch {
      showToast('ক্যাটাগরি অপারেশনে ব্যর্থ হয়েছে');
    }
  };

  const handleMoveOrder = async (cat: Category, direction: 'up' | 'down') => {
    const currentIndex = filteredSubcategories.findIndex((c) => c.id === cat.id);
    if (currentIndex < 0) return;

    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (targetIndex < 0 || targetIndex >= filteredSubcategories.length) return;

    const targetCat = filteredSubcategories[targetIndex];
    const currentOrder = cat.circleGalleryOrder || currentIndex + 1;
    const targetOrder = targetCat.circleGalleryOrder || targetIndex + 1;

    await updateCategory(cat.id, { circleGalleryOrder: targetOrder });
    await updateCategory(targetCat.id, { circleGalleryOrder: currentOrder });
    showToast('ক্রম পরিবর্তন করা হয়েছে');
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white rounded-xl shadow-sm border border-stone-200 p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-[#240B07]/5 rounded-lg text-[#240B07]">
              <Layers className="w-6 h-6" />
            </span>
            <h1 className="text-2xl font-bold text-[#240B07]">ক্যাটাগরি ম্যানেজমেন্ট</h1>
          </div>
          <p className="text-sm text-stone-600 mt-1">
            মূল ক্যাটাগরি, সাব-ক্যাটাগরি, ব্যানার, হোমপেজ সার্কুলার গ্যালারি ও এসইও নিয়ন্ত্রণ কেন্দ্র
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => handleOpenAddModal()}
            className="flex items-center gap-2 bg-[#240B07] text-[#FFF8ED] px-4 py-2.5 rounded-lg text-sm font-semibold hover:bg-[#38120B] transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            নতুন সাবক্যাটাগরি যুক্ত করুন
          </button>
        </div>
      </div>

      {/* View Switcher Tabs */}
      <div className="flex border-b border-stone-200 gap-4">
        <button
          onClick={() => setActiveTab('subcategories')}
          className={`pb-3 text-sm font-semibold border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'subcategories'
              ? 'border-[#240B07] text-[#240B07]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <FolderTree className="w-4 h-4" />
          সাবক্যাটাগরি সমূহ ({subcategories.length})
        </button>
        <button
          onClick={() => setActiveTab('main_categories')}
          className={`pb-3 text-sm font-semibold border-b-2 flex items-center gap-2 transition-colors ${
            activeTab === 'main_categories'
              ? 'border-[#240B07] text-[#240B07]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          মূল ৪টি ক্যাটাগরি ({mainCategories.length || 4})
        </button>
      </div>

      {/* MAIN CATEGORIES TAB */}
      {activeTab === 'main_categories' && (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-xs text-amber-900 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <strong>মূল ৪টি মাস্টার ক্যাটাগরি:</strong> MEN, WOMEN, KIDS, OTHERS & ACCESSORIES। এই ৪টি ক্যাটাগরি পুরো স্টোরের মূল পিলার। সাবক্যাটাগরি ও পণ্য এদের অধীনে পরিচালিত হয়।
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {MAIN_CATEGORIES_LIST.map((mc) => {
              const matchedInDb = mainCategories.find((c) => c.name.toUpperCase() === mc.name);
              const subCount = subcategories.filter((s) => s.parentCategory === mc.name).length;
              return (
                <div key={mc.id} className="bg-white rounded-xl border border-stone-200 p-5 shadow-sm hover:border-[#240B07]/40 transition-colors">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold uppercase tracking-wider text-stone-600 bg-stone-100 px-2.5 py-1 rounded">
                      {mc.name}
                    </span>
                    <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> সক্রিয়
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-[#240B07] mb-1">{mc.banglaName}</h3>
                  <p className="text-xs text-stone-600 mb-4">
                    সংযুক্ত সাবক্যাটাগরি: <strong className="text-stone-800">{subCount} টি</strong>
                  </p>

                  <div className="flex items-center gap-2 pt-3 border-t border-stone-100">
                    <button
                      onClick={() => {
                        setSelectedMainFilter(mc.name);
                        setActiveTab('subcategories');
                      }}
                      className="text-xs text-[#240B07] font-semibold hover:underline flex items-center gap-1"
                    >
                      সাবক্যাটাগরি দেখুন <ExternalLink className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => handleOpenAddModal(mc.name)}
                      className="ml-auto text-xs bg-stone-100 hover:bg-stone-200 text-stone-800 px-2 py-1 rounded font-medium"
                    >
                      + সাবক্যাটাগরি
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUBCATEGORIES TAB */}
      {activeTab === 'subcategories' && (
        <div className="space-y-4">
          {/* Controls / Filter Bar */}
          <div className="bg-white rounded-xl shadow-sm border border-stone-200 p-4 flex flex-wrap items-center justify-between gap-3">
            {/* Main Category Filter Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 max-w-full">
              <button
                onClick={() => setSelectedMainFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedMainFilter === 'all'
                    ? 'bg-[#240B07] text-[#FFF8ED]'
                    : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                সকল ({subcategories.length})
              </button>
              {MAIN_CATEGORIES_LIST.map((m) => {
                const count = subcategories.filter((s) => s.parentCategory === m.name).length;
                return (
                  <button
                    key={m.id}
                    onClick={() => setSelectedMainFilter(m.name)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                      selectedMainFilter === m.name
                        ? 'bg-[#240B07] text-[#FFF8ED]'
                        : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                    }`}
                  >
                    {m.banglaName} ({count})
                  </button>
                );
              })}
            </div>

            {/* Search and Status */}
            <div className="flex items-center gap-2 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="w-4 h-4 text-stone-600 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="নাম বা স্লাগ খুঁজুন..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#240B07]"
                />
              </div>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="py-1.5 px-3 text-xs border border-stone-300 rounded-lg bg-white focus:outline-none"
              >
                <option value="all">সব স্ট্যাটাস</option>
                <option value="active">সক্রিয়</option>
                <option value="archived">নিষ্ক্রিয়/আর্কাইভ</option>
              </select>
            </div>
          </div>

          {/* Subcategories Table */}
          <div className="bg-white rounded-xl shadow-sm border border-stone-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-stone-700">
                <thead className="bg-[#240B07]/5 text-[#240B07] font-bold uppercase tracking-wider border-b border-stone-200">
                  <tr>
                    <th className="py-3 px-4 w-12 text-center">ক্রম</th>
                    <th className="py-3 px-4 w-16 text-center">সার্কেল ছবি</th>
                    <th className="py-3 px-4">ক্যাটাগরির নাম (বাংলা ও ইংরেজি)</th>
                    <th className="py-3 px-4">মূল ক্যাটাগরি</th>
                    <th className="py-3 px-4">স্লাগ (URL)</th>
                    <th className="py-3 px-4 text-center">সংযুক্ত পণ্য</th>
                    <th className="py-3 px-4 text-center">সার্কুলার গ্যালারি</th>
                    <th className="py-3 px-4 text-center">স্ট্যাটাস</th>
                    <th className="py-3 px-4 text-right">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {filteredSubcategories.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-stone-600">
                        কোনো সাবক্যাটাগরি পাওয়া যায়নি
                      </td>
                    </tr>
                  ) : (
                    filteredSubcategories.map((cat, idx) => {
                      const linkedCount = productCountMap[cat.slug] || productCountMap[cat.id] || productCountMap[cat.name] || 0;
                      const displayImg = cat.circleImage || cat.image || 'https://images.unsplash.com/photo-1607344645866-009c320b5ab8?w=100';
                      return (
                        <tr key={cat.id} className="hover:bg-stone-50/70 transition-colors">
                          {/* Order & Reordering */}
                          <td className="py-3 px-4 text-center">
                            <div className="flex items-center justify-center gap-1">
                              <span className="font-semibold text-stone-600">{cat.circleGalleryOrder || idx + 1}</span>
                              <div className="flex flex-col">
                                <button
                                  onClick={() => handleMoveOrder(cat, 'up')}
                                  disabled={idx === 0}
                                  className="text-stone-600 hover:text-[#240B07] disabled:opacity-30"
                                  title="উপরে নিন"
                                >
                                  <ArrowUp className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={() => handleMoveOrder(cat, 'down')}
                                  disabled={idx === filteredSubcategories.length - 1}
                                  className="text-stone-600 hover:text-[#240B07] disabled:opacity-30"
                                  title="নিচে নিন"
                                >
                                  <ArrowDown className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          </td>

                          {/* Circle Image Preview */}
                          <td className="py-3 px-4 text-center">
                            <div className="w-10 h-10 rounded-full border-2 border-amber-300 shadow-sm overflow-hidden mx-auto bg-stone-100 flex items-center justify-center">
                              {displayImg ? (
                                <img src={displayImg} alt={cat.name} className="w-full h-full object-cover" />
                              ) : (
                                <ImageIcon className="w-4 h-4 text-stone-600" />
                              )}
                            </div>
                          </td>

                          {/* Names */}
                          <td className="py-3 px-4">
                            <div className="font-bold text-stone-900 text-sm">{cat.banglaName}</div>
                            <div className="text-stone-600 font-mono text-[11px]">{cat.name}</div>
                          </td>

                          {/* Parent Category */}
                          <td className="py-3 px-4">
                            <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#240B07]/10 text-[#240B07]">
                              {cat.parentCategory || 'MEN'}
                            </span>
                          </td>

                          {/* Slug */}
                          <td className="py-3 px-4 font-mono text-stone-600">
                            /category/{cat.slug}
                          </td>

                          {/* Product count */}
                          <td className="py-3 px-4 text-center">
                            <span className="inline-block px-2 py-0.5 rounded font-bold text-stone-700 bg-stone-100">
                              {linkedCount} টি
                            </span>
                          </td>

                          {/* Homepage Circle Gallery Toggle */}
                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => updateCategory(cat.id, { showInCircleGallery: !cat.showInCircleGallery })}
                              className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                                cat.showInCircleGallery !== false
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                  : 'bg-stone-100 text-stone-600'
                              }`}
                            >
                              {cat.showInCircleGallery !== false ? 'হোমপেজে দৃশ্যমান' : 'লুকানো'}
                            </button>
                          </td>

                          {/* Status */}
                          <td className="py-3 px-4 text-center">
                            {cat.isArchived ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                                <Archive className="w-3 h-3" /> আর্কাইভ
                              </span>
                            ) : cat.isActive !== false ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                                <CheckCircle2 className="w-3 h-3" /> সক্রিয়
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-stone-100 text-stone-600">
                                নিষ্ক্রিয়
                              </span>
                            )}
                          </td>

                          {/* Actions */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleOpenEditModal(cat)}
                                className="p-1.5 text-stone-600 hover:text-[#240B07] hover:bg-stone-100 rounded"
                                title="সম্পাদনা করুন"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteOrArchive(cat)}
                                className="p-1.5 text-rose-600 hover:bg-rose-50 rounded"
                                title="মুছুন / আর্কাইভ করুন"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ADD / EDIT MODAL */}
      {isModalOpen && editingCategory && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-stone-200 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-stone-100 mb-5">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-[#240B07]/5 rounded-lg text-[#240B07]">
                  <Layers className="w-5 h-5" />
                </span>
                <h2 className="text-lg font-bold text-[#240B07]">
                  {editingCategory.id ? 'সাবক্যাটাগরি সম্পাদনা' : 'নতুন সাবক্যাটাগরি তৈরি'}
                </h2>
              </div>
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setEditingCategory(null);
                }}
                className="text-stone-600 hover:text-stone-700"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveCategory} className="space-y-4 text-xs">
              {/* Row 1: Parent Category & English Name */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">মূল ক্যাটাগরি (Parent Category) *</label>
                  <select
                    value={editingCategory.parentCategory || 'MEN'}
                    onChange={(e) => setEditingCategory({ ...editingCategory, parentCategory: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-1 focus:ring-[#240B07] bg-white text-xs"
                    required
                  >
                    {MAIN_CATEGORIES_LIST.map((m) => (
                      <option key={m.id} value={m.name}>
                        {m.banglaName} ({m.name})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">ক্যাটাগরির নাম (English) *</label>
                  <input
                    type="text"
                    value={editingCategory.name || ''}
                    onChange={(e) => handleNameChange(e.target.value)}
                    placeholder="e.g. Lungi, Saree, Panjabi, Gift Box"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-1 focus:ring-[#240B07] text-xs"
                    required
                  />
                </div>
              </div>

              {/* Row 2: Bangla Name & Slug */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">ক্যাটাগরির নাম (বাংলা) *</label>
                  <input
                    type="text"
                    value={editingCategory.banglaName || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, banglaName: e.target.value })}
                    placeholder="যেমন: লুঙ্গি, শাড়ি, পাঞ্জাবি, গিফট বক্স"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-1 focus:ring-[#240B07] text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">ইউআরএল স্লাগ (URL Slug) *</label>
                  <input
                    type="text"
                    value={editingCategory.slug || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, slug: e.target.value })}
                    placeholder="lungi, saree, panjabi"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-1 focus:ring-[#240B07] text-xs font-mono"
                    required
                  />
                </div>
              </div>

              {/* Row 3: Circle Gallery Image & Banner Image */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    সার্কুলার গ্যালারি ছবি URL (হোমপেজ সার্কেল)
                  </label>
                  <input
                    type="url"
                    value={editingCategory.circleImage || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, circleImage: e.target.value })}
                    placeholder="https://..."
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-1 focus:ring-[#240B07] text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">ক্যাটাগরি ব্যানার ছবি URL</label>
                  <input
                    type="url"
                    value={editingCategory.banner || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, banner: e.target.value })}
                    placeholder="https://..."
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-1 focus:ring-[#240B07] text-xs"
                  />
                </div>
              </div>

              {/* Row 4: Homepage Gallery Order & Toggles */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-stone-50 p-3 rounded-lg border border-stone-200">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">ডিসপ্লে অর্ডার / ক্রম</label>
                  <input
                    type="number"
                    value={editingCategory.circleGalleryOrder || 1}
                    onChange={(e) => setEditingCategory({ ...editingCategory, circleGalleryOrder: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 border border-stone-300 rounded-lg text-xs"
                    min={1}
                  />
                </div>

                <div className="flex items-center gap-2 pt-5">
                  <input
                    type="checkbox"
                    id="showInCircle"
                    checked={editingCategory.showInCircleGallery !== false}
                    onChange={(e) => setEditingCategory({ ...editingCategory, showInCircleGallery: e.target.checked })}
                    className="w-4 h-4 text-[#240B07] rounded"
                  />
                  <label htmlFor="showInCircle" className="font-semibold text-stone-700 cursor-pointer">
                    হোমপেজ সার্কেল গ্যালারিতে দেখান
                  </label>
                </div>

                <div className="flex items-center gap-2 pt-5">
                  <input
                    type="checkbox"
                    id="catActive"
                    checked={editingCategory.isActive !== false}
                    onChange={(e) => setEditingCategory({ ...editingCategory, isActive: e.target.checked })}
                    className="w-4 h-4 text-[#240B07] rounded"
                  />
                  <label htmlFor="catActive" className="font-semibold text-stone-700 cursor-pointer">
                    ক্যাটাগরি সক্রিয় রাখুন
                  </label>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block font-semibold text-stone-700 mb-1">ক্যাটাগরি বিবরণ</label>
                <textarea
                  value={editingCategory.description || ''}
                  onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  rows={2}
                  placeholder="ঐতিহ্যবাহী বস্ত্র ও ফেব্রিক সম্পর্কে সংক্ষিপ্ত বিবরণ..."
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-[#240B07]"
                />
              </div>

              {/* SEO Title & Description */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">এসইও টাইটেল (SEO Title)</label>
                  <input
                    type="text"
                    value={editingCategory.seoTitle || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, seoTitle: e.target.value })}
                    placeholder="লুঙ্গি কালেকশন | বস্ত্র শৈলী"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">এসইও মেটা বিবরণ (Meta Description)</label>
                  <input
                    type="text"
                    value={editingCategory.seoDescription || ''}
                    onChange={(e) => setEditingCategory({ ...editingCategory, seoDescription: e.target.value })}
                    placeholder="সিরাজগঞ্জের খাঁটি তাঁতের সুতি লুঙ্গি অনলাইনে অর্ডার করুন..."
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              {/* Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingCategory(null);
                  }}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-lg text-xs font-semibold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-[#240B07] text-[#FFF8ED] hover:bg-[#38120B] rounded-lg text-xs font-bold transition-colors disabled:opacity-50"
                >
                  {isSubmitting ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
