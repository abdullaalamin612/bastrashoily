import React, { useState, useEffect, useMemo } from 'react';
import { useShop } from '../../context/ShopContext';
import { adminFetch } from '../adminApi';
import { SizeChartDoc, SizeChartDesignSettings } from '../../types';
import {
  Ruler,
  Plus,
  Trash2,
  Edit2,
  Save,
  CheckCircle2,
  Image as ImageIcon,
  Table as TableIcon,
  Palette,
  Eye,
  RefreshCw,
  FolderTree,
} from 'lucide-react';

const MAIN_CATEGORIES = ['MEN', 'WOMEN', 'KIDS', 'OTHERS & ACCESSORIES'];

interface TableColumn {
  id: string;
  label: string;
}

interface TableRow {
  id: string;
  size: string;
  [colId: string]: string;
}

const DEFAULT_COLUMNS: TableColumn[] = [
  { id: 'chest', label: 'বুকের মাপ (Chest)' },
  { id: 'length', label: 'লম্বা (Length)' },
  { id: 'shoulder', label: 'কাঁধ (Shoulder)' },
  { id: 'sleeve', label: 'হাতা (Sleeve)' },
];

const DEFAULT_ROWS: TableRow[] = [
  { id: 'r-m', size: 'M', chest: '38-40', length: '40', shoulder: '17.5', sleeve: '24' },
  { id: 'r-l', size: 'L', chest: '40-42', length: '42', shoulder: '18.5', sleeve: '24.5' },
  { id: 'r-xl', size: 'XL', chest: '42-44', length: '44', shoulder: '19.5', sleeve: '25' },
  { id: 'r-xxl', size: 'XXL', chest: '44-46', length: '46', shoulder: '20.5', sleeve: '25.5' },
];

const DEFAULT_DESIGN: SizeChartDesignSettings = {
  boxBgColor: '#FFFFFF',
  tableBgColor: '#FFFFFF',
  headerBgColor: '#240B07',
  headerTextColor: '#FFF8ED',
  headingColor: '#240B07',
  borderColor: '#E7E5E4',
  borderStyle: 'solid',
  padding: '16px',
};

export const SizeChartManagementModule: React.FC = () => {
  const { categories, showToast } = useShop();

  const [charts, setCharts] = useState<SizeChartDoc[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedMainCat, setSelectedMainCat] = useState<string>('MEN');

  // Currently editing chart
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingChartId, setEditingChartId] = useState<string | null>(null);

  // Form Fields
  const [formName, setFormName] = useState('');
  const [formBanglaName, setFormBanglaName] = useState('');
  const [formMainCategory, setFormMainCategory] = useState('MEN');
  const [formSubCategory, setFormSubCategory] = useState('');
  const [formUnit, setFormUnit] = useState<'inch' | 'cm'>('inch');
  const [formNotes, setFormNotes] = useState('');
  const [formMode, setFormMode] = useState<'table' | 'image'>('table');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formDesign, setFormDesign] = useState<SizeChartDesignSettings>(DEFAULT_DESIGN);

  // Table Structure
  const [columns, setColumns] = useState<TableColumn[]>(DEFAULT_COLUMNS);
  const [rows, setRows] = useState<TableRow[]>(DEFAULT_ROWS);
  const [newColLabel, setNewColLabel] = useState('');

  // Fetch all charts
  const fetchSizeCharts = async () => {
    setLoading(true);
    try {
      const res = await adminFetch('/api/admin/size-charts');
      const data = await res.json().catch(() => ({}));
      if (data && data.charts) {
        setCharts(data.charts);
      }
    } catch {
      showToast('সাইজ চার্ট লোড করতে ব্যর্থ হয়েছে');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSizeCharts();
  }, []);

  // Filter subcategories for selected main category
  const availableSubcategories = useMemo(() => {
    return categories.filter((c) => !c.isMain && (c.parentCategory === formMainCategory || !c.parentCategory));
  }, [categories, formMainCategory]);

  const openNewChartModal = (defaultSub = '') => {
    setEditingChartId(null);
    setFormName('');
    setFormBanglaName('');
    setFormMainCategory(selectedMainCat);
    setFormSubCategory(defaultSub || (availableSubcategories[0]?.slug || ''));
    setFormUnit('inch');
    setFormNotes('সব মাপ ইঞ্চিতে উল্লেখ করা হলো। কাপড় সেলাই অনুযায়ী সামান্য (+- ০.৫") তারতম্য হতে পারে।');
    setFormMode('table');
    setFormImageUrl('');
    setFormDesign(DEFAULT_DESIGN);
    setColumns(DEFAULT_COLUMNS);
    setRows(DEFAULT_ROWS);
    setIsModalOpen(true);
  };

  const openEditChartModal = (chart: SizeChartDoc) => {
    setEditingChartId(chart.id);
    setFormName(chart.name || '');
    setFormBanglaName(chart.banglaName || chart.name || '');
    setFormMainCategory(chart.mainCategory || 'MEN');
    setFormSubCategory(chart.subCategory || chart.categorySlug || '');
    setFormUnit(chart.unit || 'inch');
    setFormNotes(chart.notes || '');
    setFormMode(chart.mode || 'table');
    setFormImageUrl(chart.imageUrl || '');
    setFormDesign(chart.designSettings ? { ...DEFAULT_DESIGN, ...chart.designSettings } : DEFAULT_DESIGN);

    // Parse measurementsJson
    if (chart.measurementsJson) {
      try {
        const parsed = typeof chart.measurementsJson === 'string'
          ? JSON.parse(chart.measurementsJson)
          : chart.measurementsJson;

        if (parsed.columns && parsed.rows) {
          setColumns(parsed.columns);
          setRows(parsed.rows);
        } else if (Array.isArray(parsed) && parsed.length > 0) {
          // Fallback legacy array of measurements
          const inferredCols: TableColumn[] = Object.keys(parsed[0])
            .filter((k) => k !== 'size' && k !== 'id')
            .map((k) => ({ id: k, label: k }));
          setColumns(inferredCols);
          setRows(parsed.map((item, idx) => ({ id: `r-${idx}`, ...item })));
        }
      } catch (err) {
        console.warn('Error parsing size chart table JSON:', err);
      }
    }
    setIsModalOpen(true);
  };

  const handleAddColumn = () => {
    if (!newColLabel.trim()) return;
    const colId = `col_${Date.now()}`;
    const newCol: TableColumn = { id: colId, label: newColLabel.trim() };
    setColumns([...columns, newCol]);
    setRows(rows.map((r) => ({ ...r, [colId]: '' })));
    setNewColLabel('');
  };

  const handleDeleteColumn = (colId: string) => {
    setColumns(columns.filter((c) => c.id !== colId));
    setRows(rows.map((r) => {
      const copy = { ...r };
      delete copy[colId];
      return copy;
    }));
  };

  const handleAddRow = () => {
    const newRowId = `r_${Date.now()}`;
    const emptyRow: TableRow = { id: newRowId, size: '' };
    columns.forEach((c) => {
      emptyRow[c.id] = '';
    });
    setRows([...rows, emptyRow]);
  };

  const handleDeleteRow = (rowId: string) => {
    setRows(rows.filter((r) => r.id !== rowId));
  };

  const handleCellChange = (rowId: string, field: string, val: string) => {
    setRows(rows.map((r) => (r.id === rowId ? { ...r, [field]: val } : r)));
  };

  const handleSaveChart = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formBanglaName.trim()) {
      showToast('সাইজ চার্টের নাম প্রদান করুন');
      return;
    }

    const payload = {
      name: formName || formBanglaName,
      banglaName: formBanglaName,
      mainCategory: formMainCategory,
      subCategory: formSubCategory,
      categorySlug: formSubCategory,
      unit: formUnit,
      notes: formNotes,
      mode: formMode,
      imageUrl: formImageUrl,
      measurementsJson: JSON.stringify({ columns, rows }),
      designSettings: formDesign,
    };

    try {
      if (editingChartId) {
        await adminFetch(`/api/admin/size-charts/${editingChartId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        showToast('সাইজ চার্ট সফলভাবে আপডেট হয়েছে');
      } else {
        await adminFetch('/api/admin/size-charts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        showToast('নতুন সাইজ চার্ট সফলভাবে যুক্ত হয়েছে');
      }
      setIsModalOpen(false);
      fetchSizeCharts();
    } catch {
      showToast('সাইজ চার্ট সংরক্ষণে ব্যর্থ হয়েছে');
    }
  };

  const handleDeleteChart = async (id: string, name: string) => {
    if (!window.confirm(`আপনি কি "${name}" সাইজ চার্ট মুছে ফেলতে চান?`)) return;
    try {
      await adminFetch(`/api/admin/size-charts/${id}`, { method: 'DELETE' });
      showToast('সাইজ চার্ট মুছে ফেলা হয়েছে');
      fetchSizeCharts();
    } catch {
      showToast('সাইজ চার্ট মুছতে সমস্যা হয়েছে');
    }
  };

  // Filtered by selected tab
  const displayedCharts = charts.filter(
    (c) => !selectedMainCat || (c.mainCategory && c.mainCategory.toUpperCase() === selectedMainCat)
  );

  return (
    <div className="space-y-6">
      {/* Module Header */}
      <div className="bg-white rounded-xl shadow-sm border border-stone-200 p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-[#240B07]/5 rounded-lg text-[#240B07]">
              <Ruler className="w-6 h-6" />
            </span>
            <h1 className="text-2xl font-bold text-[#240B07]">সাইজ চার্ট ম্যানেজমেন্ট</h1>
          </div>
          <p className="text-sm text-stone-600 mt-1">
            পোশাক ক্যাটাগরি ও সাবক্যাটাগরি ভিত্তিক কাস্টম সাইজ টেবিল অথবা সাইজ চার্ট ইমেজ নিয়ন্ত্রণ করুন
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => fetchSizeCharts()}
            className="p-2 text-stone-600 hover:text-stone-900 border border-stone-200 rounded-lg hover:bg-stone-50 transition-colors"
            title="রিফ্রেশ"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={() => openNewChartModal()}
            className="flex items-center gap-2 bg-[#240B07] text-[#FFF8ED] px-4 py-2.5 rounded-lg text-sm font-semibold hover:bg-[#38120B] transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            নতুন সাইজ চার্ট তৈরি
          </button>
        </div>
      </div>

      {/* Main Category Selector Tabs */}
      <div className="flex border-b border-stone-200 gap-2 overflow-x-auto pb-1">
        {MAIN_CATEGORIES.map((cat) => {
          const count = charts.filter((c) => c.mainCategory?.toUpperCase() === cat).length;
          return (
            <button
              key={cat}
              onClick={() => setSelectedMainCat(cat)}
              className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-colors border-b-2 flex items-center gap-2 ${
                selectedMainCat === cat
                  ? 'border-[#240B07] text-[#240B07] bg-stone-50'
                  : 'border-transparent text-stone-500 hover:text-stone-800'
              }`}
            >
              <span>{cat}</span>
              <span className="text-[10px] bg-stone-200 text-stone-700 px-1.5 py-0.2 rounded-full font-mono">
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Charts Grid */}
      {loading ? (
        <div className="py-16 text-center text-stone-500 text-sm">সাইজ চার্ট লোড হচ্ছে...</div>
      ) : displayedCharts.length === 0 ? (
        <div className="bg-white rounded-xl border border-stone-200 p-12 text-center">
          <Ruler className="w-12 h-12 text-stone-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-stone-800 mb-1">
            {selectedMainCat} ক্যাটাগরিতে কোনো সাইজ চার্ট নেই
          </h3>
          <p className="text-xs text-stone-500 mb-4 max-w-sm mx-auto">
            সাবক্যাটাগরির পণ্যের জন্য কাস্টম মাপজোক টেবিল বা মাপের ছবি যুক্ত করতে নিচের বাটনে চাপ দিন।
          </p>
          <button
            onClick={() => openNewChartModal()}
            className="inline-flex items-center gap-2 bg-[#240B07] text-[#FFF8ED] px-4 py-2 rounded-lg text-xs font-semibold"
          >
            <Plus className="w-4 h-4" />
            প্রথম সাইজ চার্ট যোগ করুন
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayedCharts.map((chart) => {
            let colCount = 0;
            let rowCount = 0;
            if (chart.measurementsJson) {
              try {
                const parsed = typeof chart.measurementsJson === 'string' ? JSON.parse(chart.measurementsJson) : chart.measurementsJson;
                colCount = parsed.columns?.length || 0;
                rowCount = parsed.rows?.length || (Array.isArray(parsed) ? parsed.length : 0);
              } catch {}
            }

            return (
              <div key={chart.id} className="bg-white rounded-xl border border-stone-200 p-5 shadow-sm hover:border-[#240B07]/40 transition-colors flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#240B07] bg-[#240B07]/10 px-2 py-0.5 rounded">
                      {chart.subCategory || chart.categorySlug || 'সার্বজনীন'}
                    </span>
                    <span className="text-[11px] font-mono text-stone-500 flex items-center gap-1">
                      {chart.mode === 'image' ? (
                        <span className="flex items-center gap-1 text-purple-700 bg-purple-50 px-2 py-0.5 rounded">
                          <ImageIcon className="w-3 h-3" /> ইমেজ মোড
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          <TableIcon className="w-3 h-3" /> টেবিল ({rowCount} সাইজ)
                        </span>
                      )}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-stone-900 mb-1">{chart.banglaName || chart.name}</h3>
                  <p className="text-xs text-stone-500 line-clamp-2 mb-3">
                    {chart.notes || 'কোনো অতিরিক্ত নোট নেই'}
                  </p>

                  {/* Mode Preview */}
                  {chart.mode === 'image' && chart.imageUrl ? (
                    <div className="w-full h-32 rounded-lg bg-stone-100 overflow-hidden mb-3 border border-stone-200">
                      <img src={chart.imageUrl} alt={chart.banglaName} className="w-full h-full object-contain" />
                    </div>
                  ) : (
                    <div className="bg-stone-50 p-2.5 rounded-lg border border-stone-200 mb-3 text-[11px] text-stone-600">
                      <div className="flex justify-between font-semibold text-stone-800 pb-1 border-b border-stone-200">
                        <span>একক: {chart.unit === 'cm' ? 'সেন্টিমিটার (CM)' : 'ইঞ্চি (Inch)'}</span>
                        <span>কলাম: {colCount} টি</span>
                      </div>
                      <div className="pt-1 text-[10px] text-stone-500 truncate">
                        সাইজ তালিকা: S, M, L, XL, XXL ইত্যাদি
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
                  <button
                    onClick={() => openEditChartModal(chart)}
                    className="p-1.5 text-stone-600 hover:text-[#240B07] hover:bg-stone-100 rounded text-xs flex items-center gap-1 font-semibold"
                  >
                    <Edit2 className="w-3.5 h-3.5" /> সম্পাদনা
                  </button>
                  <button
                    onClick={() => handleDeleteChart(chart.id, chart.banglaName || chart.name)}
                    className="p-1.5 text-rose-600 hover:bg-rose-50 rounded text-xs flex items-center gap-1 font-semibold"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> মুছুন
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* CREATE / EDIT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 shadow-2xl border border-stone-200 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-stone-100 mb-5">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-[#240B07]/5 rounded-lg text-[#240B07]">
                  <Ruler className="w-5 h-5" />
                </span>
                <h2 className="text-lg font-bold text-[#240B07]">
                  {editingChartId ? 'সাইজ চার্ট সম্পাদনা' : 'নতুন সাইজ চার্ট তৈরি'}
                </h2>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-stone-400 hover:text-stone-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveChart} className="space-y-6 text-xs">
              {/* Category Assignment */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-stone-50 p-4 rounded-xl border border-stone-200">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">মূল ক্যাটাগরি (Main Category) *</label>
                  <select
                    value={formMainCategory}
                    onChange={(e) => {
                      setFormMainCategory(e.target.value);
                      const sub = categories.find((c) => !c.isMain && c.parentCategory === e.target.value);
                      if (sub) setFormSubCategory(sub.slug);
                    }}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white"
                  >
                    {MAIN_CATEGORIES.map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">সাবক্যাটাগরি নির্বাচন *</label>
                  <select
                    value={formSubCategory}
                    onChange={(e) => setFormSubCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white"
                    required
                  >
                    <option value="">নির্বাচন করুন...</option>
                    {availableSubcategories.map((sc) => (
                      <option key={sc.id} value={sc.slug}>
                        {sc.banglaName} ({sc.name})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">চার্টের বাংলা নাম *</label>
                  <input
                    type="text"
                    value={formBanglaName}
                    onChange={(e) => setFormBanglaName(e.target.value)}
                    placeholder="যেমন: প্রিমিয়াম পাঞ্জাবি সাইজ গাইড"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                    required
                  />
                </div>
              </div>

              {/* Operational Mode: Table vs Image */}
              <div>
                <label className="block font-bold text-stone-900 mb-2">চার্ট প্রদর্শন মোড নির্বাচন করুন:</label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setFormMode('table')}
                    className={`p-4 rounded-xl border text-left transition-all flex items-start gap-3 ${
                      formMode === 'table'
                        ? 'border-[#240B07] bg-[#240B07]/5 ring-2 ring-[#240B07]'
                        : 'border-stone-200 hover:border-stone-300'
                    }`}
                  >
                    <TableIcon className={`w-5 h-5 shrink-0 ${formMode === 'table' ? 'text-[#240B07]' : 'text-stone-400'}`} />
                    <div>
                      <div className="font-bold text-stone-900">মোড ১: কাস্টম সাইজ টেবিল</div>
                      <div className="text-[11px] text-stone-500 mt-0.5">
                        ইন্টারেক্টিভ টেবিল বিল্ডার। সাইজ, বুক, লম্বা ইত্যাদির মাপ যোগ ও এডিট করুন।
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormMode('image')}
                    className={`p-4 rounded-xl border text-left transition-all flex items-start gap-3 ${
                      formMode === 'image'
                        ? 'border-[#240B07] bg-[#240B07]/5 ring-2 ring-[#240B07]'
                        : 'border-stone-200 hover:border-stone-300'
                    }`}
                  >
                    <ImageIcon className={`w-5 h-5 shrink-0 ${formMode === 'image' ? 'text-[#240B07]' : 'text-stone-400'}`} />
                    <div>
                      <div className="font-bold text-stone-900">মোড ২: চার্ট ইমেজ আপলোড</div>
                      <div className="text-[11px] text-stone-500 mt-0.5">
                        আগে থেকে ডিজাইন করা সাইজ চার্ট ছবি সরাসরি প্রদর্শন করুন।
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              {/* MODE 1: TABLE BUILDER */}
              {formMode === 'table' && (
                <div className="space-y-4 border border-stone-200 rounded-xl p-4 bg-white">
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-stone-200">
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-stone-900">পরিমাপের একক:</span>
                      <div className="inline-flex rounded-lg border border-stone-300 p-0.5 bg-stone-100">
                        <button
                          type="button"
                          onClick={() => setFormUnit('inch')}
                          className={`px-3 py-1 rounded text-xs font-bold ${
                            formUnit === 'inch' ? 'bg-[#240B07] text-[#FFF8ED]' : 'text-stone-600'
                          }`}
                        >
                          ইঞ্চি (Inch)
                        </button>
                        <button
                          type="button"
                          onClick={() => setFormUnit('cm')}
                          className={`px-3 py-1 rounded text-xs font-bold ${
                            formUnit === 'cm' ? 'bg-[#240B07] text-[#FFF8ED]' : 'text-stone-600'
                          }`}
                        >
                          সেমি (CM)
                        </button>
                      </div>
                    </div>

                    {/* Add Column */}
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={newColLabel}
                        onChange={(e) => setNewColLabel(e.target.value)}
                        placeholder="নতুন কলাম (যেমন: কোমর)"
                        className="px-2.5 py-1.5 border border-stone-300 rounded-lg text-xs"
                      />
                      <button
                        type="button"
                        onClick={handleAddColumn}
                        className="bg-stone-800 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-stone-900"
                      >
                        + কলাম যোগ
                      </button>
                    </div>
                  </div>

                  {/* Interactive Table Grid */}
                  <div className="overflow-x-auto border border-stone-200 rounded-lg">
                    <table className="w-full text-xs">
                      <thead>
                        <tr style={{ backgroundColor: formDesign.headerBgColor, color: formDesign.headerTextColor }}>
                          <th className="py-2.5 px-3 text-left w-24">সাইজ</th>
                          {columns.map((col) => (
                            <th key={col.id} className="py-2.5 px-3 text-left">
                              <div className="flex items-center justify-between gap-2">
                                <span>{col.label}</span>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteColumn(col.id)}
                                  className="text-white/60 hover:text-white"
                                  title="কলাম মুছুন"
                                >
                                  ✕
                                </button>
                              </div>
                            </th>
                          ))}
                          <th className="py-2.5 px-3 w-12 text-center">মুছুন</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-200 bg-white">
                        {rows.map((row) => (
                          <tr key={row.id}>
                            <td className="py-2 px-3">
                              <input
                                type="text"
                                value={row.size}
                                onChange={(e) => handleCellChange(row.id, 'size', e.target.value)}
                                className="w-full px-2 py-1 font-bold border border-stone-300 rounded text-center text-xs"
                                placeholder="M"
                              />
                            </td>
                            {columns.map((col) => (
                              <td key={col.id} className="py-2 px-3">
                                <input
                                  type="text"
                                  value={row[col.id] || ''}
                                  onChange={(e) => handleCellChange(row.id, col.id, e.target.value)}
                                  className="w-full px-2 py-1 border border-stone-200 rounded text-xs"
                                  placeholder="00"
                                />
                              </td>
                            ))}
                            <td className="py-2 px-3 text-center">
                              <button
                                type="button"
                                onClick={() => handleDeleteRow(row.id)}
                                className="text-rose-500 hover:text-rose-700"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddRow}
                    className="w-full py-2 border-2 border-dashed border-stone-300 hover:border-[#240B07] text-stone-600 hover:text-[#240B07] rounded-lg font-semibold text-xs transition-colors flex items-center justify-center gap-1"
                  >
                    <Plus className="w-4 h-4" /> নতুন রো (Row) যোগ করুন
                  </button>

                  {/* Notes / Disclaimer */}
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">মাপজোক সংক্রান্ত নোট / ডিসক্লেইমার</label>
                    <textarea
                      value={formNotes}
                      onChange={(e) => setFormNotes(e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                      placeholder="সব মাপ ইঞ্চিতে উল্লেখ করা হয়েছে..."
                    />
                  </div>
                </div>
              )}

              {/* MODE 2: IMAGE UPLOAD */}
              {formMode === 'image' && (
                <div className="space-y-4 border border-stone-200 rounded-xl p-4 bg-white">
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">সাইজ চার্ট ইমেজ URL *</label>
                    <input
                      type="url"
                      value={formImageUrl}
                      onChange={(e) => setFormImageUrl(e.target.value)}
                      placeholder="https://example.com/size-guide-chart.jpg"
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                      required={formMode === 'image'}
                    />
                  </div>

                  {formImageUrl && (
                    <div className="p-4 border border-stone-200 rounded-lg bg-stone-50 max-w-md mx-auto">
                      <div className="text-[11px] font-bold text-stone-600 mb-2">লাইভ ইমেজ প্রিভিউ:</div>
                      <img src={formImageUrl} alt="Size Guide Preview" className="w-full h-auto rounded object-contain" />
                    </div>
                  )}
                </div>
              )}

              {/* Design Customizer (Phase 4.3) */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-2 font-bold text-stone-800">
                  <Palette className="w-4 h-4 text-[#240B07]" />
                  <span>ডিজাইন ও কালার কাস্টমাইজেশন</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 mb-1">হেডার ব্যাকগ্রাউন্ড</label>
                    <input
                      type="color"
                      value={formDesign.headerBgColor || '#240B07'}
                      onChange={(e) => setFormDesign({ ...formDesign, headerBgColor: e.target.value })}
                      className="w-full h-8 rounded border border-stone-300 cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 mb-1">হেডার টেক্সট কালার</label>
                    <input
                      type="color"
                      value={formDesign.headerTextColor || '#FFF8ED'}
                      onChange={(e) => setFormDesign({ ...formDesign, headerTextColor: e.target.value })}
                      className="w-full h-8 rounded border border-stone-300 cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 mb-1">বর্ডার কালার</label>
                    <input
                      type="color"
                      value={formDesign.borderColor || '#E7E5E4'}
                      onChange={(e) => setFormDesign({ ...formDesign, borderColor: e.target.value })}
                      className="w-full h-8 rounded border border-stone-300 cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 mb-1">বক্স ব্যাকগ্রাউন্ড</label>
                    <input
                      type="color"
                      value={formDesign.boxBgColor || '#FFFFFF'}
                      onChange={(e) => setFormDesign({ ...formDesign, boxBgColor: e.target.value })}
                      className="w-full h-8 rounded border border-stone-300 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Modal Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-lg text-xs font-semibold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#240B07] text-[#FFF8ED] hover:bg-[#38120B] rounded-lg text-xs font-bold transition-colors"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
