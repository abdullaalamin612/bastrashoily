import React, { useState, useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import { QuickOrderModal } from './QuickOrderModal';
import {
  Tag,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ShoppingBag,
  ArrowRight,
  Flame,
  CheckCircle2,
  Clock,
  Plus,
  Gift,
} from 'lucide-react';

export interface ComboItem {
  id: string;
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  image?: string;
  variant?: string;
}

export interface ComboOffer {
  id: string;
  title: string;
  bangla_title?: string;
  tagline?: string;
  description?: string;
  badge?: string;
  original_price: number;
  combo_price: number;
  savings_amount?: number;
  savings_percent?: number;
  image?: string;
  items: ComboItem[];
  isActive?: boolean;
}

export const ComboOffersSlider: React.FC = () => {
  const { addToCart, showToast } = useShop();

  const [comboOffers, setComboOffers] = useState<ComboOffer[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  // Quick Order Modal state for 1-click combo order
  const [quickOrderProduct, setQuickOrderProduct] = useState<any | null>(null);

  useEffect(() => {
    let isMounted = true;
    const fetchCombos = async () => {
      try {
        const res = await fetch('/api/combo-offers');
        const data = await res.json();
        if (isMounted && data.success && Array.isArray(data.comboOffers)) {
          const activeOnly = data.comboOffers.filter(
            (c: any) => c.isActive !== false && c.active !== 0
          );
          setComboOffers(activeOnly);
        }
      } catch (err) {
        console.warn('Failed to load combo offers from API:', err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };
    fetchCombos();
    return () => {
      isMounted = false;
    };
  }, []);

  // Auto-slide effect
  useEffect(() => {
    if (comboOffers.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % comboOffers.length);
    }, 6500);
    return () => clearInterval(interval);
  }, [comboOffers.length]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + comboOffers.length) % comboOffers.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % comboOffers.length);
  };

  const createComboProductObj = (combo: ComboOffer) => {
    return {
      id: `combo-${combo.id}`,
      name: combo.title,
      banglaName: combo.bangla_title || combo.title,
      slug: `combo-${combo.id}`,
      sku: `COMBO-${combo.id}`,
      description: combo.description || combo.tagline || '',
      shortDescription: combo.tagline || '',
      category: 'MEN',
      subCategory: 'Combo',
      brand: 'BASTRA SHOILY',
      price: combo.combo_price,
      originalPrice: combo.original_price,
      discountPrice: combo.combo_price,
      stock: 50,
      isFeatured: true,
      isNewArrival: false,
      isBestSeller: true,
      isOffer: true,
      status: 'active' as const,
      mainImage:
        combo.image ||
        combo.items[0]?.image ||
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80',
      galleryImages: (combo.items || []).map((it) => it.image).filter(Boolean) as string[],
      variants: [],
      createdAt: new Date().toISOString(),
    };
  };

  const handleAddBundleToCart = (combo: ComboOffer) => {
    const comboProduct = createComboProductObj(combo);
    addToCart(comboProduct as any, undefined, 1);
    showToast(`🎉 "${combo.bangla_title || combo.title}" কম্বো প্যাকটি কার্টে যোগ করা হয়েছে!`);
  };

  const handleQuickOrder = (combo: ComboOffer) => {
    const comboProduct = createComboProductObj(combo);
    setQuickOrderProduct(comboProduct);
  };

  if (isLoading || comboOffers.length === 0) {
    return null;
  }

  const activeCombo = comboOffers[currentIndex];
  const savings =
    activeCombo.savings_amount ||
    Math.max(0, activeCombo.original_price - activeCombo.combo_price);
  const savingsPercent =
    activeCombo.savings_percent ||
    (activeCombo.original_price > 0
      ? Math.round((savings / activeCombo.original_price) * 100)
      : 20);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-6 pb-3 border-b border-stone-200 gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-[#2B1208] text-[#F7EEDB] border border-[#DFB788]/40 shadow-xs">
              <Gift className="w-3.5 h-3.5 text-[#E6A868]" />
              এক্সক্লুসিভ গিফট বক্স ও কম্বো বান্ডেল
            </span>
            <span className="text-xs text-stone-500 font-medium hidden sm:inline">
              • প্রিমিয়াম প্যাকেজিং ও আকর্ষণীয় সাশ্রয়ী অফার
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-stone-900">
            স্পেশাল কম্বো অফার
          </h2>
        </div>

        {/* Navigation Arrows */}
        {comboOffers.length > 1 && (
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={handlePrev}
              className="w-9 h-9 rounded-full bg-[#2B1208] hover:bg-[#3D1A0D] text-[#F7EEDB] border border-[#DFB788]/40 flex items-center justify-center transition-all shadow-sm cursor-pointer active:scale-95"
              aria-label="Previous combo offer"
            >
              <ChevronLeft className="w-5 h-5 text-[#E6A868]" />
            </button>
            <span className="text-xs font-mono font-bold text-stone-600 px-1">
              {currentIndex + 1} / {comboOffers.length}
            </span>
            <button
              onClick={handleNext}
              className="w-9 h-9 rounded-full bg-[#2B1208] hover:bg-[#3D1A0D] text-[#F7EEDB] border border-[#DFB788]/40 flex items-center justify-center transition-all shadow-sm cursor-pointer active:scale-95"
              aria-label="Next combo offer"
            >
              <ChevronRight className="w-5 h-5 text-[#E6A868]" />
            </button>
          </div>
        )}
      </div>

      {/* =========================================================================
          HERO COMBO BANNER (Matched to Reference Image Design)
          - Deep chocolate / rich mahogany background (#281108 to #1C0B05)
          - Antique gold filigree corners
          - Circular craft seal badge at top
          - Bold cream calligraphy: "সকল গিফট বক্সে / স্পেশাল কম্বো প্যাকে"
          - "— ✦ চলছে ✦ —" with radiant ornamental rays
          - Extra large Bengali headline: "ফ্ল্যাট [XX]% ডিসকাউন্ট"
          - Traditional woven cane tray visual frame for the bundle
          ========================================================================= */}
      <div className="relative rounded-3xl sm:rounded-4xl bg-gradient-to-br from-[#2D1309] via-[#240E06] to-[#180803] text-[#F7EEDB] shadow-2xl border-2 border-[#DFB788]/40 overflow-hidden">
        {/* Corner Filigree Ornaments (SVG flourishes exactly matching the photo style) */}
        {/* Top-Left Corner */}
        <div className="absolute top-2.5 left-2.5 sm:top-4 sm:left-4 w-8 h-8 sm:w-12 sm:h-12 pointer-events-none opacity-80 select-none">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-none stroke-[#E6A868] stroke-[2.5]">
            <path d="M 10 90 Q 10 10 90 10" />
            <path d="M 20 90 Q 20 20 90 20" strokeWidth="1.5" strokeDasharray="3,3" />
            <circle cx="10" cy="10" r="4" fill="#E6A868" />
            <path d="M 15 15 Q 35 15 45 35 Q 15 45 15 15 Z" fill="#E6A868" fillOpacity="0.3" />
          </svg>
        </div>

        {/* Top-Right Corner */}
        <div className="absolute top-2.5 right-2.5 sm:top-4 sm:right-4 w-8 h-8 sm:w-12 sm:h-12 pointer-events-none opacity-80 select-none scale-x-[-1]">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-none stroke-[#E6A868] stroke-[2.5]">
            <path d="M 10 90 Q 10 10 90 10" />
            <path d="M 20 90 Q 20 20 90 20" strokeWidth="1.5" strokeDasharray="3,3" />
            <circle cx="10" cy="10" r="4" fill="#E6A868" />
            <path d="M 15 15 Q 35 15 45 35 Q 15 45 15 15 Z" fill="#E6A868" fillOpacity="0.3" />
          </svg>
        </div>

        {/* Bottom-Left Corner */}
        <div className="absolute bottom-2.5 left-2.5 sm:bottom-4 sm:left-4 w-8 h-8 sm:w-12 sm:h-12 pointer-events-none opacity-80 select-none scale-y-[-1]">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-none stroke-[#E6A868] stroke-[2.5]">
            <path d="M 10 90 Q 10 10 90 10" />
            <path d="M 20 90 Q 20 20 90 20" strokeWidth="1.5" strokeDasharray="3,3" />
            <circle cx="10" cy="10" r="4" fill="#E6A868" />
            <path d="M 15 15 Q 35 15 45 35 Q 15 45 15 15 Z" fill="#E6A868" fillOpacity="0.3" />
          </svg>
        </div>

        {/* Bottom-Right Corner */}
        <div className="absolute bottom-2.5 right-2.5 sm:bottom-4 sm:right-4 w-8 h-8 sm:w-12 sm:h-12 pointer-events-none opacity-80 select-none scale-[-1]">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-none stroke-[#E6A868] stroke-[2.5]">
            <path d="M 10 90 Q 10 10 90 10" />
            <path d="M 20 90 Q 20 20 90 20" strokeWidth="1.5" strokeDasharray="3,3" />
            <circle cx="10" cy="10" r="4" fill="#E6A868" />
            <path d="M 15 15 Q 35 15 45 35 Q 15 45 15 15 Z" fill="#E6A868" fillOpacity="0.3" />
          </svg>
        </div>

        {/* Inset Double Border Line */}
        <div className="absolute inset-2 sm:inset-3 rounded-2xl sm:rounded-3xl border border-[#DFB788]/20 pointer-events-none" />

        <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 p-6 sm:p-10 lg:p-12 items-center">
          {/* Left: Traditional Cane Tray / ডালা Style Product Visual Presentation (lg:col-span-5) */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center">
            {/* Wicker / Cane Basket Effect Ring matching the photo */}
            <div className="relative w-64 h-64 sm:w-80 sm:h-80 md:w-96 md:h-96 rounded-full p-3 sm:p-4 bg-gradient-to-tr from-[#9B6634] via-[#75441E] to-[#4A260D] shadow-2xl border-4 border-[#E6A868]/60 group">
              {/* Outer decorative stitch border */}
              <div className="w-full h-full rounded-full overflow-hidden border-2 border-dashed border-[#F7EEDB]/40 relative bg-stone-950">
                <img
                  src={
                    activeCombo.image ||
                    activeCombo.items[0]?.image ||
                    '/assets/aistudio/Screenshot_2026-11-01-22-43-47-24_99c04817c0de5652397fc8b56c3b3817_48ce3279.jpg'
                  }
                  alt={activeCombo.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />

                {/* Floating Tag */}
                <div className="absolute bottom-4 inset-x-4 text-center">
                  <span className="inline-block px-3 py-1 rounded-full bg-stone-950/85 backdrop-blur-md text-[#E6A868] text-[11px] font-bold border border-[#E6A868]/40 shadow-lg">
                    {activeCombo.items.length} টি প্রিমিয়াম পণ্যের এক্সক্লুসিভ বান্ডেল
                  </span>
                </div>
              </div>

              {/* Floating Savings Seal */}
              <div className="absolute -top-2 -right-2 sm:top-2 sm:right-2 w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-br from-[#E6A868] to-[#9B6634] text-stone-950 font-black flex flex-col items-center justify-center shadow-xl border-2 border-[#F7EEDB] rotate-12">
                <span className="text-[10px] sm:text-xs leading-none uppercase font-bold">ছাড়</span>
                <span className="text-sm sm:text-base leading-none font-black">৳{savings}</span>
                <span className="text-[9px] leading-none text-stone-900 font-bold">সাশ্রয়</span>
              </div>
            </div>
          </div>

          {/* Right: Video-Style Typography & Callout Layout (lg:col-span-7) */}
          <div className="lg:col-span-7 space-y-5 text-center lg:text-left flex flex-col items-center lg:items-start pt-2 sm:pt-4">
            {/* Top Banner Header with Dynamic Radiating Accent Rays (Exact Reference Match - No Top Logo) */}
            <div className="space-y-1.5 w-full flex flex-col items-center lg:items-start">
              <div className="flex items-center justify-center lg:justify-start gap-3 sm:gap-4">
                {/* 3 Left Radiating Rays */}
                <div className="flex items-center gap-1 text-[#E6A868] text-sm sm:text-base font-black tracking-tighter select-none opacity-90">
                  <span className="inline-block transform -rotate-12">\</span>
                  <span className="inline-block transform -rotate-6">\</span>
                  <span className="inline-block">\</span>
                </div>

                <h3 className="text-xl sm:text-2xl lg:text-3xl font-black text-[#F7EEDB] tracking-tight">
                  {activeCombo.bangla_title || activeCombo.title || 'সকল গিফট বক্সে'}
                </h3>

                {/* 3 Right Radiating Rays */}
                <div className="flex items-center gap-1 text-[#E6A868] text-sm sm:text-base font-black tracking-tighter select-none opacity-90">
                  <span className="inline-block">/</span>
                  <span className="inline-block transform rotate-6">/</span>
                  <span className="inline-block transform rotate-12">/</span>
                </div>
              </div>

              {/* Decorative "— ✦ চলছে ✦ —" */}
              <div className="flex items-center justify-center lg:justify-start gap-2 py-0.5">
                <span className="text-[#E6A868]/70 font-serif text-sm">—</span>
                <span className="text-xs sm:text-sm font-black text-[#E6A868] tracking-widest uppercase">
                  ✦ চলছে ✦
                </span>
                <span className="text-[#E6A868]/70 font-serif text-sm">—</span>
              </div>
            </div>

            {/* Extra Large Discount Calligraphy Headline (Matching "ফ্ল্যাট ২০% ডিসকাউন্ট" from photo) */}
            <div className="space-y-0 text-center lg:text-left py-1">
              <div className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black text-[#F7EEDB] tracking-tight leading-none drop-shadow-md">
                ফ্ল্যাট {savingsPercent}%
              </div>
              <div className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-[#F7EEDB] tracking-tight leading-tight flex items-center justify-center lg:justify-start gap-3 mt-1">
                <span>ডিসকাউন্ট</span>
                <span className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-[#F7EEDB] inline-block shadow-sm" />
              </div>
            </div>

            {/* Tagline / Narrative */}
            {activeCombo.tagline && (
              <p className="text-xs sm:text-sm text-[#F7EEDB]/85 max-w-lg leading-relaxed">
                {activeCombo.tagline}
              </p>
            )}

            {/* Price Row: Original Price vs Combo Price */}
            <div className="w-full max-w-md p-3.5 sm:p-4 rounded-2xl bg-[#1D0B05]/80 border border-[#DFB788]/30 flex items-center justify-between gap-4">
              <div>
                <span className="text-[10px] text-stone-400 block uppercase font-bold tracking-wider">
                  কম্বো অফার মূল্য:
                </span>
                <span className="text-2xl sm:text-3xl font-black text-[#E6A868]">
                  ৳{activeCombo.combo_price}
                </span>
              </div>

              {activeCombo.original_price > activeCombo.combo_price && (
                <div>
                  <span className="text-[10px] text-stone-500 block uppercase font-bold tracking-wider">
                    পূর্বের রেগুলার মূল্য:
                  </span>
                  <span className="text-base sm:text-lg font-bold text-stone-400 line-through">
                    ৳{activeCombo.original_price}
                  </span>
                </div>
              )}

              <div className="text-right">
                <span className="text-[10px] text-emerald-400 font-bold block uppercase tracking-wider">
                  নিশ্চিত সেভিংস
                </span>
                <span className="text-sm sm:text-base font-black text-emerald-400">
                  -৳{savings}
                </span>
              </div>
            </div>

            {/* Included Items Pill Thumbnails */}
            {activeCombo.items && activeCombo.items.length > 0 && (
              <div className="w-full max-w-md space-y-2">
                <span className="text-[11px] font-bold text-[#E6A868] uppercase tracking-wider block">
                  প্যাকে অন্তর্ভুক্ত পণ্যসমূহ ({activeCombo.items.length} টি):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeCombo.items.map((item, idx) => (
                    <div
                      key={item.id || idx}
                      className="flex items-center gap-2.5 p-2 rounded-xl bg-black/40 border border-[#DFB788]/20 text-xs"
                    >
                      {item.image && (
                        <img
                          src={item.image}
                          alt={item.productName}
                          className="w-9 h-9 rounded-lg object-cover border border-[#DFB788]/30 shrink-0"
                        />
                      )}
                      <div className="min-w-0 flex-1">
                        <span className="font-bold text-[#F7EEDB] block truncate text-[11px]">
                          {item.productName}
                        </span>
                        <span className="text-[10px] text-stone-400 block">
                          {item.quantity} টি • {item.variant || 'স্ট্যান্ডার্ড'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons: 1-Click Order & Add to Cart */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3 w-full max-w-md">
              <button
                type="button"
                onClick={() => handleQuickOrder(activeCombo)}
                className="w-full sm:flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#DFB788] via-[#E6A868] to-[#C98B4B] hover:from-[#E6A868] hover:to-[#DFB788] text-stone-950 font-black text-sm sm:text-base tracking-wide uppercase shadow-xl hover:shadow-2xl transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
              >
                <ShoppingBag className="w-4.5 h-4.5" />
                <span>সরাসরি অর্ডার করুন • ৳{activeCombo.combo_price}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => handleAddBundleToCart(activeCombo)}
                className="w-full sm:w-auto py-3.5 px-5 rounded-2xl bg-[#3D1A0D] hover:bg-[#4E2211] text-[#F7EEDB] font-bold text-xs sm:text-sm border border-[#DFB788]/40 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
              >
                <Plus className="w-4 h-4 text-[#E6A868]" />
                <span>কার্টে নিন</span>
              </button>
            </div>
          </div>
        </div>

        {/* Carousel Pagination Dots */}
        {comboOffers.length > 1 && (
          <div className="relative pb-6 flex items-center justify-center gap-2">
            {comboOffers.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  idx === currentIndex
                    ? 'w-8 bg-[#E6A868] shadow-md shadow-[#E6A868]/50'
                    : 'w-2 bg-[#DFB788]/30 hover:bg-[#DFB788]/60'
                }`}
                aria-label={`Go to combo offer ${idx + 1}`}
              />
            ))}
          </div>
        )}
      </div>

      {/* 1-Click Quick Order Modal */}
      {quickOrderProduct && (
        <QuickOrderModal
          product={quickOrderProduct}
          isOpen={Boolean(quickOrderProduct)}
          onClose={() => setQuickOrderProduct(null)}
        />
      )}
    </section>
  );
};
