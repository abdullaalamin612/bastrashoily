import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { Logo } from './Logo';
import {
  Phone,
  Mail,
  MapPin,
  Facebook,
  Instagram,
  Youtube,
  Store,
  ChevronRight,
  ExternalLink,
  MessageCircle,
  X,
  ShieldCheck,
  CheckCircle2,
  Send,
  Sparkles,
  Heart,
  Clock,
  Award,
  Truck,
} from 'lucide-react';

export const Footer: React.FC = () => {
  const {
    footerConfig,
    navigateToHome,
    navigateToCmsGuide,
    navigateToClothingGuide,
    navigateToTracking,
    showToast,
  } = useShop();

  const [activeModal, setActiveModal] = useState<{
    title: string;
    content: string;
  } | null>(null);

  const [isOutletModalOpen, setIsOutletModalOpen] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  // Dynamic social links from footerConfig or defaults
  const facebookUrl = footerConfig.facebookUrl || 'https://facebook.com/bastrashoily';
  const instagramUrl = footerConfig.instagramUrl || 'https://instagram.com/bastrashoily';
  const youtubeUrl = footerConfig.youtubeUrl || 'https://youtube.com/@bastrashoily';
  const tiktokUrl = (footerConfig as any).tiktokUrl || 'https://tiktok.com/@bastrashoily';
  const whatsappUrl =
    (footerConfig as any).whatsappUrl ||
    'https://wa.me/8801864528488?text=' + encodeURIComponent('আসসালামু আলাইকুম বাস্ত্র শৈলী, আমি পণ্য সম্পর্কে জানতে চাই।');

  const phone = footerConfig.phone || '+8801864-528488';
  const email = footerConfig.email || 'bastrashoily@gmail.com';
  const address = footerConfig.address || 'দ্বারিয়াপুর, শাহজাদপুর, সিরাজগঞ্জ - ৬৭৭০, বাংলাদেশ';

  const brandBio =
    footerConfig.aboutUs ||
    'বাস্ত্র শৈলী (BASTRA SHOILY) সিরাজগঞ্জ ও পাবনার তাঁত কারিগরদের নিপুণ হাতের ছোঁয়ায় বোনা খাঁটি সুতি তাঁতের লুঙ্গি, প্রিমিয়াম রয়্যাল পাঞ্জাবি ও ঐতিহ্যবাহী জামদানি শাড়ির সবচেয়ে নির্ভরযোগ্য অনলাইন ঠিকানা। শতভাগ আরামদায়ক কাপড়ে দেশীয় ঐতিহ্যের আভিজাত্য।';

  const handleOpenPolicy = (title: string, content: string) => {
    setActiveModal({ title, content });
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setNewsletterSubscribed(true);
    showToast('ধন্যবাদ! বাস্ত্র শৈলীর বিশেষ ছাড় ও নতুন কালেকশনের আপডেটে যুক্ত হলেন।');
    setNewsletterEmail('');
  };

  // Dynamic lists if configured by admin in FooterManagementModule
  const customQuickLinks = footerConfig.quickLinks || [];
  const customPolicies = footerConfig.policies || [];
  const customContacts = footerConfig.contactItems || [];

  return (
    <footer className="bg-[#121212] text-stone-300 border-t border-stone-800 font-sans selection:bg-amber-900 selection:text-white">
      {/* Main 4-Column Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
          {/* Column 1: Brand Logo, Bio & Social Links */}
          <div className="space-y-4">
            <div className="cursor-pointer inline-block" onClick={navigateToHome}>
              <Logo variant="light" />
            </div>

            <p className="text-xs text-stone-400 leading-relaxed">
              {brandBio}
            </p>

            <div className="pt-2">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block mb-2.5">
                সোশ্যাল মিডিয়ায় যুক্ত থাকুন:
              </span>
              <div className="flex items-center gap-2.5">
                {/* Facebook */}
                <a
                  href={facebookUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-9 h-9 rounded-xl bg-stone-900 hover:bg-[#1877F2] text-stone-300 hover:text-white flex items-center justify-center border border-stone-800 hover:border-[#1877F2] transition-all cursor-pointer active:scale-95 shadow-sm"
                  title="Facebook"
                  aria-label="Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </a>

                {/* Instagram */}
                <a
                  href={instagramUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-9 h-9 rounded-xl bg-stone-900 hover:bg-gradient-to-tr hover:from-[#f09433] hover:via-[#dc2743] hover:to-[#bc1888] text-stone-300 hover:text-white flex items-center justify-center border border-stone-800 hover:border-transparent transition-all cursor-pointer active:scale-95 shadow-sm"
                  title="Instagram"
                  aria-label="Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </a>

                {/* TikTok */}
                <a
                  href={tiktokUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-9 h-9 rounded-xl bg-stone-900 hover:bg-black text-stone-300 hover:text-[#00f2fe] flex items-center justify-center border border-stone-800 hover:border-[#00f2fe] transition-all cursor-pointer active:scale-95 shadow-sm"
                  title="TikTok"
                  aria-label="TikTok"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298-.002.595.042.88.13V9.4a6.33 6.33 0 0 0-1-.08A6.34 6.34 0 0 0 3 15.66a6.34 6.34 0 0 0 10.82 4.47 6.27 6.27 0 0 0 1.87-4.47V8.71a8.19 8.19 0 0 0 4.9 1.63v-3.45a4.85 4.85 0 0 1-1-.2z" />
                  </svg>
                </a>

                {/* YouTube */}
                <a
                  href={youtubeUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-9 h-9 rounded-xl bg-stone-900 hover:bg-[#FF0000] text-stone-300 hover:text-white flex items-center justify-center border border-stone-800 hover:border-[#FF0000] transition-all cursor-pointer active:scale-95 shadow-sm"
                  title="YouTube"
                  aria-label="YouTube"
                >
                  <Youtube className="w-4 h-4" />
                </a>

                {/* WhatsApp */}
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-9 h-9 rounded-xl bg-stone-900 hover:bg-[#25D366] text-stone-300 hover:text-white flex items-center justify-center border border-stone-800 hover:border-[#25D366] transition-all cursor-pointer active:scale-95 shadow-sm"
                  title="WhatsApp Direct Chat"
                  aria-label="WhatsApp Direct Chat"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Artisan Guarantee */}
            <div className="pt-2 flex items-center gap-2 text-[11px] text-amber-400/90 font-medium">
              <Award className="w-4 h-4 text-amber-500 shrink-0" />
              <span>শাহজাদপুর-সিরাজগঞ্জের ১০০% আসল তাঁত শিল্প</span>
            </div>
          </div>

          {/* Column 2: দ্রুত লিংকসমূহ (Quick Links) */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-2">
              <span className="w-1.5 h-3.5 bg-amber-500 rounded-full" />
              <span>দ্রুত লিংকসমূহ (Quick Links)</span>
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={navigateToHome}
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                  <span>হোম পেজ (Home)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateToTracking()}
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                  <span>অর্ডার ট্র্যাক করুন (Track Order)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={navigateToCmsGuide}
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                  <span>কিভাবে অর্ডার করবেন? (How to Order)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={navigateToClothingGuide}
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                  <span>কাপড়ের যত্ন ও সাইজ গাইড (Care & Size)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setIsOutletModalOpen(true)}
                  className="hover:text-amber-400 transition-colors flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                  <span>শোরুম ও আউটলেটসমূহ (Outlets)</span>
                </button>
              </li>

              {/* Admin configured custom links */}
              {customQuickLinks.filter((l) => l.isActive).map((l) => (
                <li key={l.id}>
                  <a
                    href={l.url}
                    className="hover:text-amber-400 transition-colors flex items-center gap-1.5 text-stone-400 hover:text-white"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                    <span>{l.title}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: কাস্টমার সাপোর্ট ও পলিসি (Customer Service & Policies) */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-2">
              <span className="w-1.5 h-3.5 bg-amber-500 rounded-full" />
              <span>সার্ভিস ও পলিসি (Policies)</span>
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() =>
                    handleOpenPolicy(
                      'Refund and Returns Policy (রিটার্ন ও এক্সচেঞ্জ পলিসি)',
                      footerConfig.returnPolicy ||
                        'পণ্য হাতে পাওয়ার ৭ দিনের মধ্যে যেকোনো ত্রুটি বা সাইজ পরিবর্তনের জন্য আমাদের সহজ রিটার্ন ও এক্সচেঞ্জ পলিসি প্রযোজ্য। ডেলিভারিম্যানের সামনে চেক করে নেওয়ার পূর্ণ সুযোগ রয়েছে। কোনো অমিল থাকলে সাথে সাথেই ফেরত দিন।'
                    )
                  }
                  className="hover:text-amber-400 transition-colors text-left flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                  <span>রিটার্ন ও এক্সচেঞ্জ পলিসি (Returns)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() =>
                    handleOpenPolicy(
                      'Terms & Conditions (শর্তাবলী)',
                      footerConfig.termsAndConditions ||
                        'বাস্ত্র শৈলী থেকে অর্ডারকৃত প্রতিটি পণ্য ১০০% অরিজিনাল ও গুণমান নিশ্চিত করে সরবরাহ করা হয়। অর্ডার কনফার্মেশনের ২৪ ঘণ্টার মধ্যে ডেলিভারি প্রক্রিয়া শুরু হয়। ওয়েবসাইট ও পণ্যের যেকোনো তথ্যাদি শতভাগ খাঁটি।'
                    )
                  }
                  className="hover:text-amber-400 transition-colors text-left flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                  <span>শর্তাবলী (Terms & Conditions)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() =>
                    handleOpenPolicy(
                      'Privacy Policy (গোপনীয়তা নীতি)',
                      footerConfig.privacyPolicy ||
                        'গ্রাহকের ব্যক্তিগত তথ্য যেমন নাম, ফোন নম্বর এবং ডেলিভারি ঠিকানা সম্পূর্ণ গোপন ও সুরক্ষিত থাকে। কোনো তৃতীয় পক্ষের নিকট বা বাণিজ্যিক উদ্দেশ্যে তথ্য হস্তান্তর করা হয় না।'
                    )
                  }
                  className="hover:text-amber-400 transition-colors text-left flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                  <span>গোপনীয়তা নীতি (Privacy Policy)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() =>
                    handleOpenPolicy(
                      'ডেলিভারি ও ক্যাশ অন ডেলিভারি তথ্য',
                      'আমরা সারা দেশে ৬৪ জেলায় ক্যাশ অন ডেলিভারি সুবিধা প্রদান করি। সিরাজগঞ্জ জেলায় ২৪ থেকে ৪৮ ঘণ্টার মধ্যে এবং দেশের অন্যান্য জেলায় ২ থেকে ৩ কর্মদিবসের মধ্যে নির্ভরযোগ্য কুরিয়ারের মাধ্যমে পার্সেল পৌঁছে দেওয়া হয়।'
                    )
                  }
                  className="hover:text-amber-400 transition-colors text-left flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                >
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                  <span>ডেলিভারি তথ্য (Delivery Info)</span>
                </button>
              </li>

              {/* Admin custom policies */}
              {customPolicies.filter((p) => p.isActive).map((p) => (
                <li key={p.id}>
                  <button
                    onClick={() => handleOpenPolicy(p.title, p.content)}
                    className="hover:text-amber-400 transition-colors text-left flex items-center gap-1.5 cursor-pointer text-stone-400 hover:text-white"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                    <span>{p.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: যোগাযোগ ও কাস্টমার কেয়ার (Contact Us) */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-stone-800 pb-2">
              <span className="w-1.5 h-3.5 bg-amber-500 rounded-full" />
              <span>যোগাযোগ করুন (Contact Us)</span>
            </h4>

            <div className="space-y-3 text-xs text-stone-300">
              {/* Address */}
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{address}</span>
              </div>

              {/* Phone */}
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                <div>
                  <a
                    href={`tel:${phone.replace(/\s+/g, '')}`}
                    className="text-amber-400 hover:underline font-bold text-xs"
                  >
                    {phone}
                  </a>
                  <span className="text-[10px] text-stone-500 block">
                    (সকাল ৯:০০টা - রাত ১১:০০টা)
                  </span>
                </div>
              </div>

              {/* Email */}
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-amber-500 shrink-0" />
                <a
                  href={`mailto:${email}`}
                  className="text-stone-300 hover:text-amber-400 transition-colors text-xs"
                >
                  {email}
                </a>
              </div>

              {/* WhatsApp Chat Button */}
              <div className="pt-1">
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 text-[#25D366] border border-[#25D366]/30 font-bold text-xs transition-all cursor-pointer active:scale-95"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>হোয়াটসঅ্যাপে সরাসরি চ্যাট করুন</span>
                </a>
              </div>

              {/* Admin custom contact items */}
              {customContacts.filter((c) => c.isActive).map((c) => (
                <div key={c.id} className="flex items-center gap-2 pt-1 text-stone-300">
                  <span className="font-bold text-amber-400">{c.label}:</span>
                  <span>{c.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          SECTION 7: BOTTOM BAR (Outlets Modal Trigger + Copyright)
          ========================================================================= */}
      <div className="border-t border-stone-800/80 bg-black/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Outlets Button */}
          <button
            onClick={() => setIsOutletModalOpen(true)}
            className="px-4 py-2 rounded-full bg-stone-900 hover:bg-amber-600 text-stone-300 hover:text-white border border-stone-800 hover:border-amber-600 font-bold text-xs flex items-center gap-2 transition-all active:scale-95 cursor-pointer shadow-sm"
          >
            <Store className="w-3.5 h-3.5 text-amber-500" />
            <span>আমাদের শোরুম ও আউটলেটসমূহ</span>
          </button>

          {/* Copyright Text */}
          <div className="text-xs text-stone-400 text-center">
            {footerConfig.copyrightText || (
              <>
                © {new Date().getFullYear()} <span className="text-white font-bold">বাস্ত্র শৈলী (BASTRA SHOILY)</span>. সর্বস্বত্ব সংরক্ষিত।
              </>
            )}
          </div>
        </div>
      </div>

      {/* Policy Modal */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-lg w-full p-6 text-stone-200 shadow-2xl relative">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 right-4 p-2 text-stone-400 hover:text-white rounded-full bg-stone-800 hover:bg-stone-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-base font-black text-amber-400 mb-3 pr-8">{activeModal.title}</h3>
            <div className="text-xs text-stone-300 leading-relaxed whitespace-pre-line max-h-96 overflow-y-auto">
              {activeModal.content}
            </div>
            <div className="mt-5 text-right">
              <button
                onClick={() => setActiveModal(null)}
                className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                ঠিক আছে
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Shopping Outlets Modal */}
      {isOutletModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-xs animate-in fade-in">
          <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-lg w-full p-6 text-stone-200 shadow-2xl relative">
            <button
              onClick={() => setIsOutletModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-stone-400 hover:text-white rounded-full bg-stone-800 hover:bg-stone-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2 text-amber-500 font-extrabold text-sm mb-1">
              <Store className="w-5 h-5" />
              <span>বাস্ত্র শৈলী শোরুম ও আউটলেটসমূহ</span>
            </div>
            <p className="text-xs text-stone-400 mb-4">আমাদের প্রধান শোরুম ও আউটলেটের তথ্য</p>

            <div className="space-y-3 text-xs bg-stone-950 p-4 rounded-2xl border border-stone-800">
              <div>
                <span className="font-bold text-amber-400 block">শাহজাদপুর ফ্ল্যাগশিপ আউটলেট:</span>
                <span className="text-stone-300">দ্বারিয়াপুর বাজার মোড়, শাহজাদপুর, সিরাজগঞ্জ - ৬৭৭০</span>
              </div>
              <div>
                <span className="font-bold text-amber-400 block">খোলা থাকার সময়:</span>
                <span className="text-stone-300">সকাল ৯:০০টা থেকে রাত ১০:০০টা (প্রতিদিন খোলা)</span>
              </div>
              <div>
                <span className="font-bold text-amber-400 block">আউটলেট হটলাইন:</span>
                <span className="text-stone-300">+8801864-528488</span>
              </div>
            </div>

            <div className="mt-5 text-right">
              <button
                onClick={() => setIsOutletModalOpen(false)}
                className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};
