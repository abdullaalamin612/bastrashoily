import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Plus,
  Tag,
  Calendar,
  Layers,
  Edit3,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  ShoppingBag,
  ArrowRight,
  TrendingUp,
  Percent,
  Eye,
  Check,
  X,
  RefreshCw,
  Gift,
  Flame,
  ShieldCheck,
} from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { adminFetch } from '../adminApi';

export interface ComboItem {
  id: string;
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  image?: string;
  variant?: string;
}

export interface ComboOffer {
  id: string;
  title: string;
  banglaTitle?: string;
  tagline?: string;
  description?: string;
  badge?: string;
  originalPrice: number;
  comboPrice: number;
  savingsAmount: number;
  savingsPercent: number;
  items: ComboItem[];
  image?: string;
  startDate?: string;
  endDate?: string;
  isActive: boolean;
  displayOrder: number;
}

export const ComboOffersModule: React.FC = () => {
  const { products, showToast } = useShop();

  const [combos, setCombos] = useState<ComboOffer[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCombo, setEditingCombo] = useState<ComboOffer | null>(null);
  const [previewCombo, setPreviewCombo] = useState<ComboOffer | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [banglaTitle, setBanglaTitle] = useState('');
  const [tagline, setTagline] = useState('');
  const [description, setDescription] = useState('');
  const [badge, setBadge] = useState('স্পেশাল কম্বো');
  const [comboPrice, setComboPrice] = useState<number>(1850);
  const [image, setImage] = useState('');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState('2026-12-31');
  const [isActive, setIsActive] = useState(true);
  const [displayOrder, setDisplayOrder] = useState(1);
  const [selectedItems, setSelectedItems] = useState<ComboItem[]>([]);

  // Calculate sum of selected items
  const originalPrice = selectedItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const savingsAmount = originalPrice > comboPrice ? originalPrice - comboPrice : 0;
  const savingsPercent = originalPrice > 0 ? Math.round((savingsAmount / originalPrice) * 100) : 0;

  // Load Combos
  const fetchCombos = async () => {
    setLoading(true);
    try {
      const res = await adminFetch('/api/admin/combo-offers');
      const data = await res.json();
      if (data && data.comboOffers) {
        const formatted: ComboOffer[] = data.comboOffers.map((c: any) => ({
          id: c.id,
          title: c.title,
          banglaTitle: c.bangla_title || c.title,
          tagline: c.tagline || '',
          description: c.description || '',
          badge: c.badge || 'স্পেশাল কম্বো',
          originalPrice: Number(c.original_price || c.originalPrice || 0),
          comboPrice: Number(c.combo_price || c.comboPrice || 0),
          savingsAmount: Number(c.savings_amount || c.savingsAmount || 0),
          savingsPercent: Number(c.savings_percent || c.savingsPercent || 0),
          items: Array.isArray(c.items) ? c.items : (typeof c.items_json === 'string' ? JSON.parse(c.items_json) : []),
          image: c.image || '',
          startDate: c.start_date || c.startDate || '',
          endDate: c.end_date || c.endDate || '',
          isActive: Boolean(c.active !== undefined ? c.active : c.isActive),
          displayOrder: Number(c.display_order || c.displayOrder || 1),
        }));
        setCombos(formatted);
        if (formatted.length > 0 && !previewCombo) {
          setPreviewCombo(formatted[0]);
        }
      }
    } catch {
      // Fallback sample data if network issue
      const sampleCombos: ComboOffer[] = [
        {
          id: 'combo-1',
          title: 'Traditional Handloom Lungi & Cotton Panjabi Duo',
          banglaTitle: 'প্রিমিয়াম তাঁতের লুঙ্গি + সুতি পাঞ্জাবি কম্বো প্যাক',
          tagline: 'শতভাগ আরামদায়ক ও খাঁটি দেশীয় বুননের প্রিমিয়াম ডুও বান্ডেল',
          description: 'সিরাজগঞ্জের ঐতিহ্যবাহী তাঁতের তৈরি সুতি লুঙ্গি ও আধুনিক কাটের সুতি পাঞ্জাবির এক অপূর্ব যুগলবন্দি। বিশেষ উৎসবে আপনার কিংবা প্রিয়জনের জন্য সেরা উপহার।',
          badge: 'স্পেশাল কম্বো',
          originalPrice: 2450,
          comboPrice: 1850,
          savingsAmount: 600,
          savingsPercent: 24,
          items: [
            {
              id: 'it-1',
              productId: 'prod-1',
              productName: 'প্রিমিয়াম তাঁতের লুঙ্গি (Royal Handloom Lungi)',
              price: 950,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=400&q=80',
              variant: 'রয়েল ব্লু / স্ট্যান্ডার্ড',
            },
            {
              id: 'it-2',
              productId: 'prod-2',
              productName: 'ক্লাসিক সুতি পাঞ্জাবি (Classic Cotton Panjabi)',
              price: 1500,
              quantity: 1,
              image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=400&q=80',
              variant: 'আইভরি হোয়াইট / L',
            },
          ],
          image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80',
          startDate: '2026-01-01',
          endDate: '2026-12-31',
          isActive: true,
          displayOrder: 1,
        },
      ];
      setCombos(sampleCombos);
      setPreviewCombo(sampleCombos[0]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCombos();
  }, []);

  const openCreateModal = () => {
    setEditingCombo(null);
    setTitle('');
    setBanglaTitle('');
    setTagline('শতভাগ দেশীয় তাঁতের ঐতিহ্য ও আরামদায়ক ফ্যাশন বান্ডেল');
    setDescription('');
    setBadge('স্পেশাল কম্বো');
    setComboPrice(1500);
    setImage('');
    setStartDate(new Date().toISOString().split('T')[0]);
    setEndDate('2026-12-31');
    setIsActive(true);
    setDisplayOrder(combos.length + 1);

    // Default select 2 products if available
    if (products.length >= 2) {
      setSelectedItems([
        {
          id: `item-${Date.now()}-1`,
          productId: products[0].id,
          productName: products[0].name,
          price: products[0].price,
          quantity: 1,
          image: products[0].images?.[0] || '',
          variant: 'ডিফল্ট সাইজ',
        },
        {
          id: `item-${Date.now()}-2`,
          productId: products[1].id,
          productName: products[1].name,
          price: products[1].price,
          quantity: 1,
          image: products[1].images?.[0] || '',
          variant: 'ডিফল্ট সাইজ',
        },
      ]);
    } else {
      setSelectedItems([]);
    }

    setIsModalOpen(true);
  };

  const openEditModal = (c: ComboOffer) => {
    setEditingCombo(c);
    setTitle(c.title);
    setBanglaTitle(c.banglaTitle || c.title);
    setTagline(c.tagline || '');
    setDescription(c.description || '');
    setBadge(c.badge || 'স্পেশাল কম্বো');
    setComboPrice(c.comboPrice);
    setImage(c.image || '');
    setStartDate(c.startDate || new Date().toISOString().split('T')[0]);
    setEndDate(c.endDate || '2026-12-31');
    setIsActive(c.isActive);
    setDisplayOrder(c.displayOrder || 1);
    setSelectedItems(c.items || []);
    setIsModalOpen(true);
  };

  const handleAddItemToCombo = (productId: string) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;
    const newItem: ComboItem = {
      id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      productId: prod.id,
      productName: prod.name,
      price: prod.price,
      quantity: 1,
      image: prod.images?.[0] || '',
      variant: 'স্ট্যান্ডার্ড',
    };
    setSelectedItems([...selectedItems, newItem]);
  };

  const handleRemoveItem = (id: string) => {
    setSelectedItems(selectedItems.filter((it) => it.id !== id));
  };

  const handleUpdateItemQty = (id: string, qty: number) => {
    if (qty < 1) return;
    setSelectedItems(
      selectedItems.map((it) => (it.id === id ? { ...it, quantity: qty } : it))
    );
  };

  const handleSaveCombo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !banglaTitle.trim()) {
      showToast('অনুগ্রহ করে কম্বোর ইংরেজি ও বাংলা শিরোনাম লিখুন');
      return;
    }
    if (comboPrice <= 0) {
      showToast('কম্বো মূল্য শূন্য হতে পারবে না');
      return;
    }

    const payload = {
      title: title.trim(),
      banglaTitle: banglaTitle.trim(),
      tagline: tagline.trim(),
      description: description.trim(),
      badge,
      originalPrice,
      comboPrice,
      savingsAmount,
      savingsPercent,
      items: selectedItems,
      image: image.trim() || selectedItems[0]?.image || '',
      startDate,
      endDate,
      active: isActive ? 1 : 0,
      displayOrder,
    };

    try {
      if (editingCombo) {
        const res = await adminFetch(`/api/admin/combo-offers/${editingCombo.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.success) {
          showToast('কম্বো অফার সফলভাবে আপডেট হয়েছে!');
        }
      } else {
        const res = await adminFetch('/api/admin/combo-offers', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.success) {
          showToast('নতুন কম্বো অফার সফলভাবে তৈরি হয়েছে!');
        }
      }
      setIsModalOpen(false);
      fetchCombos();
    } catch {
      showToast('সার্ভার এরর: কম্বো সংরক্ষণ করা যায়নি');
    }
  };

  const handleToggleActive = async (combo: ComboOffer) => {
    try {
      const res = await adminFetch(`/api/admin/combo-offers/${combo.id}`, {
        method: 'PUT',
        body: JSON.stringify({ active: combo.isActive ? 0 : 1 }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(
          combo.isActive
            ? 'কম্বো অফার নিষ্ক্রিয় করা হয়েছে'
            : 'কম্বো অফার সক্রিয় করা হয়েছে'
        );
        fetchCombos();
      }
    } catch {
      showToast('স্ট্যাটাস পরিবর্তনে সমস্যা হয়েছে');
    }
  };

  const handleDeleteCombo = async (id: string) => {
    if (!window.confirm('আপনি কি নিশ্চিতভাবে এই কম্বো অফারটি মুছে ফেলতে চান?')) {
      return;
    }
    try {
      const res = await adminFetch(`/api/admin/combo-offers/${id}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data.success) {
        showToast('কম্বো অফার মুছে ফেলা হয়েছে');
        fetchCombos();
      }
    } catch {
      showToast('কম্বো ডিলিট করা যায়নি');
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* 1. Header with Bengali & English Typography */}
      <div className="bg-gradient-to-r from-stone-900 via-neutral-900 to-amber-950 text-white rounded-2xl p-6 lg:p-8 shadow-xl border border-amber-900/40 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-medium mb-3 border border-amber-500/30">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>নান্দনিক টাইপোগ্রাফি ও বান্ডেল আর্কিটেকচার</span>
            </div>
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-serif font-bold tracking-tight text-amber-50">
              কম্বো অফার ও বান্ডেল ডিল
            </h1>
            <p className="text-neutral-300 text-sm md:text-base mt-2 max-w-2xl font-light">
              গ্রাহকদের জন্য উচ্চ মূল্যের প্যাকেজ তৈরি করুন। একাধিক তাঁতের পণ্য একসাথে আকর্ষণীয় সাশ্রয়ে বান্ডেল অফার করে গড় অর্ডার ভ্যালু (AOV) দ্বিগুণ করুন।
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchCombos}
              className="px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-sm font-medium transition flex items-center gap-2 border border-neutral-700"
              title="রিফ্রেশ"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>রিফ্রেশ</span>
            </button>
            <button
              onClick={openCreateModal}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-sm font-semibold shadow-lg shadow-orange-950/40 transition flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>নতুন কম্বো তৈরি করুন</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Key Performance Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
            <Gift className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs text-stone-500 font-medium">মোট কম্বো প্যাক</div>
            <div className="text-xl md:text-2xl font-bold text-stone-900 mt-0.5">
              {combos.length} টি
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs text-stone-500 font-medium">সক্রিয় বান্ডেল</div>
            <div className="text-xl md:text-2xl font-bold text-emerald-700 mt-0.5">
              {combos.filter((c) => c.isActive).length} টি
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center font-bold">
            <Percent className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs text-stone-500 font-medium">গড় সাশ্রয় রেট</div>
            <div className="text-xl md:text-2xl font-bold text-rose-700 mt-0.5">
              {combos.length > 0
                ? Math.round(
                    combos.reduce((a, b) => a + (b.savingsPercent || 0), 0) / combos.length
                  )
                : 22}%
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs text-stone-500 font-medium">প্রত্যাশিত AOV বৃদ্ধি</div>
            <div className="text-xl md:text-2xl font-bold text-indigo-700 mt-0.5">
              +৩৫%
            </div>
          </div>
        </div>
      </div>

      {/* 3. Main Grid: Active Combos List + Interactive Live Storefront Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Combos Management Table / Cards */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-stone-200">
            <h2 className="text-lg font-serif font-bold text-stone-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-amber-700" />
              <span>উপলব্ধ কম্বো অফার তালিকা</span>
            </h2>
            <span className="text-xs text-stone-500 font-medium">
              সর্বমোট {combos.length} টি প্যাকেজ
            </span>
          </div>

          {loading ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-stone-200 text-stone-500">
              <RefreshCw className="w-8 h-8 animate-spin mx-auto text-amber-600 mb-3" />
              <span>কম্বো তালিকা লোড হচ্ছে...</span>
            </div>
          ) : combos.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-stone-200 text-stone-500">
              <Gift className="w-12 h-12 mx-auto text-stone-300 mb-3" />
              <div className="font-semibold text-stone-700">কোনো কম্বো অফার পাওয়া যায়নি</div>
              <p className="text-xs text-stone-400 mt-1">
                গ্রাহকদের জন্য আকর্ষণীয় বান্ডেল ডিল তৈরি করতে &quot;নতুন কম্বো তৈরি করুন&quot; বাটনে ক্লিক করুন।
              </p>
              <button
                onClick={openCreateModal}
                className="mt-4 px-4 py-2 bg-amber-700 text-white rounded-xl text-xs font-semibold hover:bg-amber-800 transition"
              >
                প্রথম কম্বো তৈরি করুন
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {combos.map((combo) => {
                const isSelectedForPreview = previewCombo?.id === combo.id;
                return (
                  <div
                    key={combo.id}
                    onClick={() => setPreviewCombo(combo)}
                    className={`bg-white rounded-2xl p-5 border transition-all cursor-pointer relative ${
                      isSelectedForPreview
                        ? 'border-amber-600 ring-2 ring-amber-500/20 shadow-md'
                        : 'border-stone-200/80 hover:border-amber-300 hover:shadow-sm'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row gap-4">
                      {/* Image Thumbnail */}
                      <div className="w-full sm:w-28 h-28 rounded-xl overflow-hidden bg-stone-100 flex-shrink-0 relative">
                        {combo.image ? (
                          <img
                            src={combo.image}
                            alt={combo.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-stone-300">
                            <Gift className="w-10 h-10" />
                          </div>
                        )}
                        <span className="absolute top-1.5 left-1.5 bg-amber-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">
                          {combo.badge || 'কম্বো'}
                        </span>
                      </div>

                      {/* Content & Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h3 className="font-serif font-bold text-stone-900 text-base leading-snug truncate">
                              {combo.banglaTitle || combo.title}
                            </h3>
                            <p className="text-xs text-stone-500 mt-0.5 line-clamp-1">
                              {combo.tagline || combo.title}
                            </p>
                          </div>

                          <span
                            className={`px-2.5 py-0.5 rounded-full text-xs font-medium flex items-center gap-1 flex-shrink-0 ${
                              combo.isActive
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-stone-100 text-stone-500 border border-stone-200'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                combo.isActive ? 'bg-emerald-600' : 'bg-stone-400'
                              }`}
                            />
                            {combo.isActive ? 'সক্রিয়' : 'নিষ্ক্রিয়'}
                          </span>
                        </div>

                        {/* Items in Combo Tags */}
                        <div className="flex flex-wrap gap-1.5 mt-3">
                          {combo.items.map((it, idx) => (
                            <span
                              key={idx}
                              className="text-[11px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md border border-stone-200 flex items-center gap-1"
                            >
                              <span className="font-bold text-amber-800">{it.quantity}x</span>
                              <span className="truncate max-w-[140px]">{it.productName}</span>
                            </span>
                          ))}
                        </div>

                        {/* Price & Savings */}
                        <div className="flex items-center justify-between mt-3 pt-3 border-t border-stone-100">
                          <div className="flex items-baseline gap-2">
                            <span className="text-lg font-bold text-amber-800 font-serif">
                              ৳ {combo.comboPrice.toLocaleString()}
                            </span>
                            {combo.originalPrice > combo.comboPrice && (
                              <span className="text-xs text-stone-400 line-through">
                                ৳ {combo.originalPrice.toLocaleString()}
                              </span>
                            )}
                            {combo.savingsAmount > 0 && (
                              <span className="text-[11px] font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-100">
                                ৳ {combo.savingsAmount.toLocaleString()} সাশ্রয়
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleToggleActive(combo);
                              }}
                              className={`p-1.5 rounded-lg border text-xs transition ${
                                combo.isActive
                                  ? 'border-stone-200 text-stone-600 hover:bg-stone-100'
                                  : 'border-emerald-300 text-emerald-700 hover:bg-emerald-50'
                              }`}
                              title={combo.isActive ? 'নিষ্ক্রিয় করুন' : 'সক্রিয় করুন'}
                            >
                              {combo.isActive ? 'পজ' : 'চালু'}
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                openEditModal(combo);
                              }}
                              className="p-1.5 rounded-lg border border-stone-200 text-stone-600 hover:bg-amber-50 hover:text-amber-800 hover:border-amber-200 transition"
                              title="এডিট করুন"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteCombo(combo.id);
                              }}
                              className="p-1.5 rounded-lg border border-stone-200 text-rose-600 hover:bg-rose-50 hover:border-rose-200 transition"
                              title="মুছে ফেলুন"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Column: Live Storefront Card Preview with Custom Design & Beautiful Typography */}
        <div className="lg:col-span-5 sticky top-6 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-stone-200">
            <h2 className="text-lg font-serif font-bold text-stone-900 flex items-center gap-2">
              <Eye className="w-5 h-5 text-amber-700" />
              <span>লাইভ স্টোরফ্রন্ট প্রিভিউ (Live Preview)</span>
            </h2>
            <span className="text-[11px] text-amber-700 font-medium bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              গ্রাহকরা যেভাবে দেখবেন
            </span>
          </div>

          {previewCombo ? (
            <div className="bg-white rounded-3xl overflow-hidden border border-amber-200/70 shadow-2xl shadow-amber-950/10 relative">
              {/* Top Banner Ribbon */}
              <div className="bg-gradient-to-r from-amber-700 via-orange-600 to-amber-800 px-6 py-2.5 text-white flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider font-semibold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  {previewCombo.badge || 'স্পেশাল কম্বো অফার'}
                </span>
                {previewCombo.savingsPercent > 0 && (
                  <span className="bg-white/20 backdrop-blur-sm text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-white/30">
                    {previewCombo.savingsPercent}% ছাড়
                  </span>
                )}
              </div>

              {/* Main Image Header */}
              <div className="h-56 bg-stone-100 relative overflow-hidden">
                {previewCombo.image ? (
                  <img
                    src={previewCombo.image}
                    alt={previewCombo.title}
                    className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-stone-300 bg-amber-50">
                    <Gift className="w-16 h-16 text-amber-300" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-stone-900/80 via-stone-900/20 to-transparent" />
                <div className="absolute bottom-4 left-5 right-5 text-white">
                  <div className="text-xs text-amber-300 font-medium tracking-wide">
                    {previewCombo.title}
                  </div>
                  <h3 className="text-xl font-serif font-bold tracking-tight text-white mt-0.5 drop-shadow">
                    {previewCombo.banglaTitle || previewCombo.title}
                  </h3>
                </div>
              </div>

              {/* Content Body */}
              <div className="p-6 space-y-5">
                <p className="text-xs text-stone-600 leading-relaxed font-light">
                  {previewCombo.description ||
                    previewCombo.tagline ||
                    'ঐতিহ্যবাহী খাঁটি সুতি ও হ্যান্ডলুম কাপড়ে তৈরি প্রিমিয়াম কম্বো প্যাক। আধুনিক রুচিশীল ক্রেতাদের জন্য বিশেষ সাশ্রয়ী মূল্যে।'}
                </p>

                {/* Items in the Bundle */}
                <div className="space-y-2.5">
                  <div className="text-xs font-semibold text-stone-800 uppercase tracking-wider flex items-center justify-between">
                    <span>বান্ডেলে অন্তর্ভুক্ত আইটেমসমূহ</span>
                    <span className="text-stone-400 font-normal">
                      {previewCombo.items.length} টি পণ্য
                    </span>
                  </div>

                  <div className="space-y-2">
                    {previewCombo.items.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-3 p-2.5 rounded-xl bg-stone-50 border border-stone-200/70"
                      >
                        <div className="w-12 h-12 rounded-lg bg-stone-200 overflow-hidden flex-shrink-0">
                          {item.image ? (
                            <img
                              src={item.image}
                              alt={item.productName}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-stone-400">
                              <ShoppingBag className="w-5 h-5" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-bold text-stone-800 truncate">
                            {item.productName}
                          </div>
                          <div className="text-[11px] text-stone-500">
                            {item.variant || 'স্ট্যান্ডার্ড'} • পরিমাণ: {item.quantity}
                          </div>
                        </div>
                        <div className="text-xs font-semibold text-stone-700">
                          ৳ {item.price.toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Pricing Calculation Callout */}
                <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-4 border border-amber-200/80">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs text-stone-500 block">রেগুলার মূল্য:</span>
                      <span className="text-sm font-semibold text-stone-400 line-through">
                        ৳ {previewCombo.originalPrice.toLocaleString()}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-xs text-amber-900 font-medium block">
                        কম্বো স্পেশাল প্রাইস:
                      </span>
                      <span className="text-2xl font-serif font-black text-amber-900">
                        ৳ {previewCombo.comboPrice.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {previewCombo.savingsAmount > 0 && (
                    <div className="mt-3 pt-3 border-t border-amber-200/60 flex items-center justify-between text-xs font-bold text-emerald-800">
                      <span className="flex items-center gap-1">
                        <Check className="w-4 h-4 text-emerald-600" />
                        আপনার মোট সাশ্রয়:
                      </span>
                      <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full border border-emerald-200">
                        ৳ {previewCombo.savingsAmount.toLocaleString()} ({previewCombo.savingsPercent}% অফ)
                      </span>
                    </div>
                  )}
                </div>

                {/* Simulated Order Button */}
                <button
                  type="button"
                  className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-stone-900 to-amber-950 text-white font-serif font-bold text-sm tracking-wide shadow-lg hover:shadow-xl transition flex items-center justify-center gap-2 group cursor-default"
                >
                  <ShoppingBag className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                  <span>১-ক্লিকে কম্বো অর্ডার করুন</span>
                  <ArrowRight className="w-4 h-4 text-amber-400 ml-1" />
                </button>

                <div className="flex items-center justify-center gap-4 text-[11px] text-stone-500 pt-1">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> ক্যাশ অন ডেলিভারি
                  </span>
                  <span>•</span>
                  <span>৭ দিনের সহজ রিটার্ন</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl p-12 text-center border border-stone-200 text-stone-400">
              <Eye className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <span>প্রিভিউ দেখতে বামের তালিকা থেকে যেকোনো একটি কম্বো সিলেক্ট করুন</span>
            </div>
          )}
        </div>
      </div>

      {/* 4. Create / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-stone-200 my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-stone-900 to-amber-950 px-6 py-5 text-white flex items-center justify-between">
              <div>
                <h3 className="text-xl font-serif font-bold text-amber-50">
                  {editingCombo ? 'কম্বো অফার সম্পাদনা' : 'নতুন কম্বো বান্ডেল অফার তৈরি'}
                </h3>
                <p className="text-xs text-neutral-300 mt-0.5">
                  নান্দনিক টাইপোগ্রাফি ও আকর্ষণীয় বান্ডেল ডিল কনফিগার করুন
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveCombo} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
              {/* Title & Bangla Title */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    বাংলা শিরোনাম (Title in Bengali) *
                  </label>
                  <input
                    type="text"
                    required
                    value={banglaTitle}
                    onChange={(e) => setBanglaTitle(e.target.value)}
                    placeholder="যেমন: প্রিমিয়াম তাঁতের লুঙ্গি + পাঞ্জাবি কম্বো"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 font-serif"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    ইংরেজি শিরোনাম (English Title) *
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Traditional Handloom Lungi & Panjabi Duo"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Tagline & Badge */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    ট্যাগলাইন / সাবটাইটেল
                  </label>
                  <input
                    type="text"
                    value={tagline}
                    onChange={(e) => setTagline(e.target.value)}
                    placeholder="শতভাগ আরামদায়ক ও খাঁটি দেশীয় বুনন"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    কম্বো ব্যাজ (Ribbon Badge)
                  </label>
                  <select
                    value={badge}
                    onChange={(e) => setBadge(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  >
                    <option value="স্পেশাল কম্বো">স্পেশাল কম্বো (Special Combo)</option>
                    <option value="ঈদ স্পেশাল অফার">ঈদ স্পেশাল অফার (Eid Special)</option>
                    <option value="বেস্ট ভ্যালু বান্ডেল">বেস্ট ভ্যালু বান্ডেল (Best Value)</option>
                    <option value="লিমিটেড এডিশন">লিমিটেড এডিশন (Limited Edition)</option>
                    <option value="বৈশাখী ধামাকা">বৈশাখী ধামাকা (Boishakhi Dhamaka)</option>
                    <option value="উইকেন্ড ডিল">উইকেন্ড ডিল (Weekend Deal)</option>
                  </select>
                </div>
              </div>

              {/* Product Selector for Bundle */}
              <div className="space-y-3 pt-2 border-t border-stone-100">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-stone-800 uppercase tracking-wider">
                    বান্ডেলে পণ্য যুক্ত করুন (Bundle Products) *
                  </label>
                  <span className="text-xs text-amber-800 font-semibold">
                    মোট সিলেক্টেড: {selectedItems.length} টি
                  </span>
                </div>

                {/* Add product dropdown */}
                <div className="flex gap-2">
                  <select
                    onChange={(e) => {
                      if (e.target.value) {
                        handleAddItemToCombo(e.target.value);
                        e.target.value = '';
                      }
                    }}
                    defaultValue=""
                    className="flex-1 px-3.5 py-2 rounded-xl border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  >
                    <option value="" disabled>
                      + ক্যাটালগ থেকে পণ্য সিলেক্ট করুন...
                    </option>
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} — ৳ {p.price.toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Selected Items List */}
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {selectedItems.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center gap-3 p-2.5 rounded-xl bg-stone-50 border border-stone-200"
                    >
                      <div className="w-10 h-10 rounded-lg bg-stone-200 overflow-hidden flex-shrink-0">
                        {item.image ? (
                          <img
                            src={item.image}
                            alt={item.productName}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-stone-400">
                            <ShoppingBag className="w-4 h-4" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-semibold text-stone-800 truncate">
                          {item.productName}
                        </div>
                        <div className="text-[11px] text-stone-500">
                          একক মূল্য: ৳ {item.price.toLocaleString()}
                        </div>
                      </div>

                      {/* Quantity control */}
                      <div className="flex items-center gap-1 border border-stone-300 rounded-lg px-2 py-0.5 bg-white">
                        <span className="text-xs text-stone-500">পরিমাণ:</span>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) =>
                            handleUpdateItemQty(item.id, parseInt(e.target.value) || 1)
                          }
                          className="w-10 text-xs font-bold text-center focus:outline-none"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveItem(item.id)}
                        className="p-1 text-stone-400 hover:text-rose-600 transition"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pricing & Real-Time Savings Calculator */}
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-4 border border-amber-200 space-y-3">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-600 mb-1">
                      রেগুলার মোট মূল্য
                    </label>
                    <div className="text-base font-bold text-stone-700 py-1">
                      ৳ {originalPrice.toLocaleString()}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-amber-900 mb-1">
                      কম্বো অফার মূল্য (৳) *
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={comboPrice}
                      onChange={(e) => setComboPrice(Number(e.target.value))}
                      className="w-full px-3 py-1.5 rounded-lg border border-amber-300 text-base font-bold text-amber-900 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-emerald-800 mb-1">
                      গ্রাহকের সাশ্রয়
                    </label>
                    <div className="text-sm font-bold text-emerald-700 py-1">
                      ৳ {savingsAmount.toLocaleString()} ({savingsPercent}%)
                    </div>
                  </div>
                </div>
              </div>

              {/* Image & Validity Dates */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-1">
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    ছবি URL (বাধ্যতামূলক নয়)
                  </label>
                  <input
                    type="url"
                    value={image}
                    onChange={(e) => setImage(e.target.value)}
                    placeholder="https://..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    অফার শুরুর তারিখ
                  </label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    অফার সমাপ্তির তারিখ
                  </label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  বিস্তারিত বর্ণনা (Description)
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="কম্বো অফারের বিশেষত্ব ও কাপড়ের গুণগত মান..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* Active Toggle & Display Order */}
              <div className="flex items-center justify-between pt-2 border-t border-stone-100">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                  />
                  <span className="text-xs font-semibold text-stone-800">
                    তাৎক্ষণিকভাবে ওয়েবসাইটে সক্রিয় রাখুন
                  </span>
                </label>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-stone-500">ডিসপ্লে ক্রম:</span>
                  <input
                    type="number"
                    min="1"
                    value={displayOrder}
                    onChange={(e) => setDisplayOrder(parseInt(e.target.value) || 1)}
                    className="w-14 px-2 py-1 rounded border border-stone-300 text-xs text-center"
                  />
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl border border-stone-300 text-stone-700 text-xs font-semibold hover:bg-stone-50 transition"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-700 to-orange-600 hover:from-amber-600 hover:to-orange-500 text-white text-xs font-bold shadow-lg shadow-orange-950/20 transition flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{editingCombo ? 'পরিবর্তন সংরক্ষণ করুন' : 'কম্বো প্রকাশ করুন'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
