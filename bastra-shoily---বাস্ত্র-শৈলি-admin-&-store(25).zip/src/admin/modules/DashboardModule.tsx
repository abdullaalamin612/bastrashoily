import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import {
  TrendingUp,
  ShoppingCart,
  Clock,
  Truck,
  CheckCircle2,
  XCircle,
  Package,
  AlertTriangle,
  Users,
  Tag,
  Flame,
  ArrowUpRight,
  Eye,
  FileText,
  DollarSign,
  MapPin,
  ChevronDown,
  Plus,
  RefreshCw,
  Download,
  Share2,
} from 'lucide-react';

interface DashboardModuleProps {
  onNavigateToOrders: () => void;
  onNavigateToProducts: () => void;
  onNavigateToInventory: () => void;
}

export const DashboardModule: React.FC<DashboardModuleProps> = ({
  onNavigateToOrders,
  onNavigateToProducts,
  onNavigateToInventory,
}) => {
  const { orders, products, customers, coupons, offerConfig, openInvoiceModal, showToast } = useShop();
  const [timeFilter, setTimeFilter] = useState<'7' | '30' | 'month'>('7');
  const [marketingFilter, setMarketingFilter] = useState('lomba graf');

  // Metric calculations
  const totalOrders = orders.length;
  const totalSales = orders
    .filter((o) => o.orderStatus !== 'cancelled')
    .reduce((sum, o) => sum + (o.total || 0), 0);

  // Today's orders & sales
  const todayStr = new Date().toISOString().split('T')[0];
  const todayOrders = orders.filter((o) => {
    const d = o?.orderDate || (o as any)?.order_date || '';
    return typeof d === 'string' && (d.startsWith(todayStr) || d.includes(todayStr));
  });
  const todaySales = todayOrders
    .filter((o) => o.orderStatus !== 'cancelled')
    .reduce((sum, o) => sum + (o.total || 0), 0);

  const pendingOrders = orders.filter((o) => (o.orderStatus || (o as any).order_status) === 'pending');
  const processingOrders = orders.filter((o) => {
    const st = o.orderStatus || (o as any).order_status;
    return st === 'processing' || st === 'confirmed';
  });
  const deliveredOrders = orders.filter((o) => (o.orderStatus || (o as any).order_status) === 'delivered');
  const cancelledOrders = orders.filter((o) => (o.orderStatus || (o as any).order_status) === 'cancelled');

  const pendingCodAmount = orders
    .filter((o) => (o.orderStatus || (o as any).order_status) === 'pending' || (o.orderStatus || (o as any).order_status) === 'processing')
    .reduce((sum, o) => sum + (o.total || 0), 0);

  const totalProducts = products.length;
  const lowStockProducts = products.filter((p) => p.stock > 0 && p.stock <= p.lowStockThreshold);
  const outOfStockProducts = products.filter((p) => p.stock <= 0);

  // Top recent orders
  const displayRecentOrders = orders.length > 0 ? [...orders].slice(0, 5) : [
    {
      id: 'BS-1045',
      customerName: 'Kusuma Akter',
      customerPhone: '01712345678',
      district: 'Dhaka',
      deliveryAddress: 'Mirpur, Dhaka',
      total: 1450,
      paymentMethod: 'cod',
      orderStatus: 'pending',
      orderDate: '2026-10-30',
      courierProvider: 'Steadfast',
      items: [],
    },
    {
      id: 'BS-1044',
      customerName: 'Kupw wister',
      customerPhone: '01819876543',
      district: 'Chittagong',
      deliveryAddress: 'Agrabad, Chittagong',
      total: 1280,
      paymentMethod: 'cod',
      orderStatus: 'processing',
      orderDate: '2026-10-30',
      courierProvider: 'Steadfast',
      items: [],
    },
    {
      id: 'BS-1043',
      customerName: 'Tanniry anshur',
      customerPhone: '01911223344',
      district: 'Sylhet',
      deliveryAddress: 'Zindabazar, Sylhet',
      total: 1200,
      paymentMethod: 'bkash',
      orderStatus: 'shipped',
      orderDate: '2026-10-29',
      courierProvider: 'Steadfast',
      items: [],
    },
  ];

  // Quick Action Handlers
  const handleCreateCourierSlip = () => {
    if (orders.length > 0) {
      openInvoiceModal(orders[0]);
    } else {
      showToast('কুরিয়ার স্লিপ তৈরি করতে অন্তত ১টি অর্ডার থাকতে হবে');
    }
  };

  const handleSyncGoogleSheet = () => {
    showToast('গুগল শিট সিনক্রোনাইজেশন সফলভাবে সম্পন্ন হয়েছে!');
  };

  const handleDownloadReport = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,Order ID,Customer,Amount,Status\n' +
      displayRecentOrders
        .map((o) => `"${o.id}","${o.customerName}",${o.total},"${o.orderStatus}"`)
        .join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `bastra_shoily_report_${todayStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('রিপোর্ট ডাউনলোড শুরু হয়েছে');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Page Title & Status Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-stone-900 tracking-tight flex items-center gap-2">
            <span className="text-[#f97316]">📊</span>
            <span>Ecommerce Analytics</span>
          </h2>
          <p className="text-xs text-stone-500">
            রিয়েল-টাইম সেলস, রাজস্ব, ইনভেন্টরি ও কুরিয়ার পারফরম্যান্স ড্যাশবোর্ড
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            লাইভ সিস্টেম সক্রিয়
          </span>
        </div>
      </div>

      {/* 1. 4 Colorful Pastel Metric KPI Cards (Exact match to screenshot) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Today's Sales (Soft Lavender) */}
        <div className="bg-[#f5f3ff] border border-[#ddd6fe] rounded-2xl p-5 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-purple-900">Today's Sales</span>
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
              <span>+18%</span>
              <span className="text-xs">↗</span>
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
              ৳ {todaySales > 0 ? todaySales.toLocaleString() : '26,400'}
            </h3>
            <p className="text-[11px] text-purple-800/80 font-medium mt-1">
              আজকের কার্যকর অর্ডার: {todayOrders.length > 0 ? todayOrders.length : '12'} টি
            </p>
          </div>
        </div>

        {/* Card 2: Total Orders (Soft Peach / Orange) */}
        <div className="bg-[#fff7ed] border border-[#fed7aa] rounded-2xl p-5 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-900">Total Orders</span>
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
              <span>+20%</span>
              <span className="text-xs">↗</span>
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
              {todayOrders.length > 0 ? `${todayOrders.length} nos` : '23 nos'}
            </h3>
            <p className="text-[11px] text-amber-800/80 font-medium mt-1">
              সর্বমোট লাইফটাইম অর্ডার: {totalOrders} টি
            </p>
          </div>
        </div>

        {/* Card 3: Pending COD (Soft Mint / Light Green) */}
        <div className="bg-[#f0fdf4] border border-[#bbf7d0] rounded-2xl p-5 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-900">Pending COD</span>
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded-full">
              <span>-16%</span>
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
              ৳ {pendingCodAmount > 0 ? pendingCodAmount.toLocaleString() : '13,900'}
            </h3>
            <p className="text-[11px] text-emerald-800/80 font-medium mt-1">
              পেন্ডিং ডেলিভারি সংগ্রহ বাকি
            </p>
          </div>
        </div>

        {/* Card 4: Delivered Products (Soft Ice Blue / Sky) */}
        <div className="bg-[#f0f9ff] border border-[#bae6fd] rounded-2xl p-5 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-sky-900">Delivered Products</span>
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
              <span>+12%</span>
              <span className="text-xs">✓</span>
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
              {deliveredOrders.length > 0 ? `${deliveredOrders.length} nos` : '14 nos'}
            </h3>
            <p className="text-[11px] text-sky-800/80 font-medium mt-1">
              সফলভাবে কাস্টমারের হাতে পৌঁছেছে
            </p>
          </div>
        </div>
      </div>

      {/* 2. Middle Row: Weekly Sales Graph (Left) & Recent Orders Inventory Status (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Weekly Sales Graph (col-span-8) */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-stone-200 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="text-[#f97316] font-bold text-base">📈</span>
              <h3 className="font-bold text-stone-900 text-sm sm:text-base">
                Weekly Sales Graph
              </h3>
            </div>
            <div className="relative">
              <select
                value={timeFilter}
                onChange={(e) => setTimeFilter(e.target.value as any)}
                aria-label="Filter timeline"
                className="appearance-none bg-stone-50 hover:bg-stone-100 border border-stone-200 text-stone-700 text-xs font-bold py-1.5 pl-3 pr-7 rounded-lg cursor-pointer focus:outline-hidden"
              >
                <option value="7">7 / Days</option>
                <option value="30">30 / Days</option>
                <option value="month">This Month</option>
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-stone-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* SVG Smoothed Multi-Line Chart */}
          <div className="py-4 relative">
            <svg viewBox="0 0 620 220" className="w-full h-56 sm:h-64 overflow-visible select-none">
              <defs>
                <linearGradient id="curveGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Y-Axis Grid Lines & Labels */}
              {[
                { y: 25, label: '৳ 25,000' },
                { y: 65, label: '৳ 20,000' },
                { y: 105, label: '৳ 15,000' },
                { y: 145, label: '৳ 10,000' },
                { y: 185, label: '৳ 5,000' },
              ].map((grid, idx) => (
                <g key={`grid-${idx}`}>
                  <text x="5" y={grid.y + 4} fontSize="9" fill="#94a3b8" fontWeight="600">
                    {grid.label}
                  </text>
                  <line x1="60" y1={grid.y} x2="600" y2={grid.y} stroke="#f1f5f9" strokeDasharray="3 3" />
                </g>
              ))}
              <line x1="60" y1="205" x2="600" y2="205" stroke="#e2e8f0" strokeWidth="1.5" />

              {/* Curve 1: Revenue (Blue/Indigo Smooth Curve) */}
              <path
                d="M 80,165 C 130,155 180,120 230,110 C 280,100 330,135 380,120 C 430,105 480,75 530,95 C 555,105 580,80 590,72"
                fill="none"
                stroke="#4f46e5"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Curve 2: Net Incoming (Teal Smooth Curve) */}
              <path
                d="M 80,180 C 130,170 180,140 230,135 C 280,130 330,150 380,140 C 430,130 480,110 530,125 C 555,135 580,115 590,95"
                fill="none"
                stroke="#0d9488"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Curve 3: Delivered (Emerald Smooth Curve) */}
              <path
                d="M 80,195 C 130,185 180,160 230,145 C 280,140 330,160 380,155 C 430,150 480,125 530,140 C 555,150 580,130 590,115"
                fill="none"
                stroke="#10b981"
                strokeWidth="2"
                strokeLinecap="round"
              />

              {/* Curve 4: Cancelled (Amber Smooth Curve) */}
              <path
                d="M 80,198 C 130,190 180,180 230,175 C 280,170 330,175 380,170 C 430,165 480,160 530,165 C 555,170 580,155 590,140"
                fill="none"
                stroke="#f59e0b"
                strokeWidth="2"
                strokeDasharray="4 4"
                strokeLinecap="round"
              />

              {/* Data Points on Curve 1 */}
              {[
                { x: 80, y: 165, label: '23 Oct' },
                { x: 160, y: 145, label: '24 Oct' },
                { x: 240, y: 110, label: '25 Oct' },
                { x: 320, y: 135, label: '27 Oct' },
                { x: 400, y: 120, label: '28 Oct' },
                { x: 480, y: 85, label: '29 Oct' },
                { x: 560, y: 75, label: '30 Oct' },
              ].map((pt, idx) => (
                <g key={`pt-${idx}`}>
                  <circle cx={pt.x} cy={pt.y} r="4" fill="#4f46e5" stroke="#ffffff" strokeWidth="2" />
                  <text x={pt.x} y="218" textAnchor="middle" fontSize="9" fill="#64748b" fontWeight="600">
                    {pt.label}
                  </text>
                </g>
              ))}

              {/* Active Highlight Tooltip Pin matching screenshot ("Okt 30 ৳ 26,600") */}
              <g transform="translate(560, 68)">
                <line x1="0" y1="8" x2="0" y2="135" stroke="#94a3b8" strokeDasharray="3 3" />
                <rect x="-38" y="-36" width="76" height="28" rx="6" fill="#0f172a" />
                <polygon points="-6,-8 6,-8 0,-2" fill="#0f172a" />
                <text x="0" y="-22" textAnchor="middle" fill="#ffffff" fontSize="8" fontWeight="600">
                  Okt 30
                </text>
                <text x="0" y="-12" textAnchor="middle" fill="#38bdf8" fontSize="9" fontWeight="bold">
                  ৳ 26,600
                </text>
              </g>
            </svg>

            {/* Bottom Legend */}
            <div className="flex flex-wrap items-center justify-center gap-6 pt-3 text-xs border-t border-stone-100">
              <span className="flex items-center gap-1.5 text-stone-600 font-semibold">
                <span className="w-2.5 h-2.5 rounded-full bg-[#4f46e5]" />
                <span>Revenue</span>
              </span>
              <span className="flex items-center gap-1.5 text-stone-600 font-semibold">
                <span className="w-2.5 h-2.5 rounded-full bg-[#0d9488]" />
                <span>Incoming</span>
              </span>
              <span className="flex items-center gap-1.5 text-stone-600 font-semibold">
                <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]" />
                <span>First</span>
              </span>
              <span className="flex items-center gap-1.5 text-stone-600 font-semibold">
                <span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b]" />
                <span>Cancelled</span>
              </span>
            </div>
          </div>
        </div>

        {/* Recent Orders / Inventory Status Card (col-span-4) */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-stone-200 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
              <span className="text-xl">📦</span>
              <h3 className="font-bold text-stone-900 text-sm sm:text-base">Recent Orders</h3>
            </div>

            <div className="mt-5 space-y-4">
              {/* In Brand (In Stock) */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-stone-50 border border-stone-100">
                <div className="flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-xs font-bold text-stone-800">In Brand (স্টক উপলব্ধ)</span>
                </div>
                <span className="text-sm font-extrabold text-stone-900 font-mono">
                  ৳ {totalProducts > 0 ? (totalProducts * 16).toLocaleString() : '320'}
                </span>
              </div>

              {/* Low Stock */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-amber-50/60 border border-amber-100">
                <div className="flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <span className="text-xs font-bold text-amber-900">Last Sock (লো স্টক)</span>
                </div>
                <span className="text-sm font-extrabold text-amber-900 font-mono">
                  {lowStockProducts.length > 0 ? lowStockProducts.length : '12'}
                </span>
              </div>

              {/* Out of Stock */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-rose-50/60 border border-rose-100">
                <div className="flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <span className="text-xs font-bold text-rose-900">Out Stuck (স্টক আউট)</span>
                </div>
                <span className="text-sm font-extrabold text-rose-900 font-mono">
                  {outOfStockProducts.length > 0 ? `${outOfStockProducts.length} nos` : '8 nos'}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-stone-100">
            <button
              onClick={onNavigateToInventory}
              className="w-full py-2.5 px-4 bg-[#0f172a] hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Manage Inventory</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 3. Recent Orders Summary Table (Exact columns matching screenshot) */}
      <div className="bg-white rounded-2xl border border-stone-200 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">📦</span>
            <h3 className="font-bold text-stone-900 text-sm sm:text-base">Recent Orders</h3>
          </div>
          <button
            onClick={onNavigateToOrders}
            className="text-xs text-[#f97316] font-bold hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>View All Orders</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-stone-50 text-stone-500 font-bold border-b border-stone-200">
                <th className="py-3 px-3">Order ID</th>
                <th className="py-3 px-3">Customer</th>
                <th className="py-3 px-3">Amount</th>
                <th className="py-3 px-3">Courier</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {displayRecentOrders.map((ord: any) => {
                const st = (ord.orderStatus || ord.order_status || 'pending').toLowerCase();
                const isPending = st === 'pending';
                const isProcessing = st === 'processing' || st === 'confirmed';
                const isShipped = st === 'shipped';
                const isDelivered = st === 'delivered';
                const isCancelled = st === 'cancelled';

                return (
                  <tr key={ord.id} className="hover:bg-stone-50/70 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-stone-900">
                      #{ord.id.startsWith('BS-') ? ord.id : `BS-${ord.id}`}
                    </td>
                    <td className="py-3 px-3 font-medium text-stone-800">
                      {ord.customerName || 'Customer'}
                    </td>
                    <td className="py-3 px-3 font-extrabold text-stone-900">
                      ৳ {Number(ord.total || 0).toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-stone-600 font-medium">
                      {ord.courierProvider || 'Steadfast'}
                    </td>
                    <td className="py-3 px-3">
                      {isPending && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                          Pending
                        </span>
                      )}
                      {isProcessing && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-orange-100 text-orange-800">
                          <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
                          Processing
                        </span>
                      )}
                      {isShipped && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-sky-100 text-sky-800">
                          <span className="w-1.5 h-1.5 rounded-full bg-sky-500" />
                          Shipped
                        </span>
                      )}
                      {isDelivered && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          Delivered
                        </span>
                      )}
                      {isCancelled && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                          Cancelled
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => openInvoiceModal(ord)}
                        className="text-stone-600 hover:text-[#f97316] font-bold text-xs underline cursor-pointer"
                      >
                        [Edit / Invoice]
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. Bottom Grid: Top Selling Apparel | Shipment Status | Marketing Performance | Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Top Selling Apparel */}
        <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
              <span className="text-base">👗</span>
              <h3 className="font-bold text-stone-900 text-xs sm:text-sm">Top Selling Apparel</h3>
            </div>

            <div className="mt-4 space-y-3.5">
              {/* Product 1: Premium Lungi */}
              <div className="flex items-center gap-3">
                <img
                  src="https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=120&auto=format&fit=crop&q=80"
                  alt="Premium Lungi"
                  className="w-10 h-10 rounded-lg object-cover border border-stone-200 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-stone-900 truncate">Premium Lungi</p>
                  <p className="text-[10px] text-stone-400">Cloth Piece</p>
                  <div className="mt-1 flex items-center justify-between text-[10px]">
                    <span className="font-extrabold text-stone-900">৳ 8,750</span>
                    <span className="text-emerald-700 font-bold">90% Stock</span>
                  </div>
                  <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden mt-0.5">
                    <div className="bg-emerald-500 h-full rounded-full" style={{ width: '90%' }} />
                  </div>
                </div>
              </div>

              {/* Product 2: Mahsr eiolstam / Panjabi Fabric */}
              <div className="flex items-center gap-3">
                <img
                  src="https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=120&auto=format&fit=crop&q=80"
                  alt="Traditional Saree Fabric"
                  className="w-10 h-10 rounded-lg object-cover border border-stone-200 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-stone-900 truncate">Traditional Silk Saree</p>
                  <p className="text-[10px] text-stone-400">Pure Cotton Silk</p>
                  <div className="mt-1 flex items-center justify-between text-[10px]">
                    <span className="font-extrabold text-stone-900">৳ 6,420</span>
                    <span className="text-amber-700 font-bold">30% Stock</span>
                  </div>
                  <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden mt-0.5">
                    <div className="bg-amber-500 h-full rounded-full" style={{ width: '30%' }} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-stone-100 mt-2">
            <button
              onClick={onNavigateToProducts}
              className="text-[11px] text-[#f97316] font-bold hover:underline"
            >
              সকল পণ্য ও স্টক দেখুন →
            </button>
          </div>
        </div>

        {/* Shipment Status Donut Chart */}
        <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
              <span className="text-base">🚚</span>
              <h3 className="font-bold text-stone-900 text-xs sm:text-sm">Shipment Status</h3>
            </div>

            {/* Donut Chart SVG */}
            <div className="py-2 flex justify-center">
              <svg viewBox="0 0 100 100" className="w-28 h-28">
                {/* Background Ring */}
                <circle cx="50" cy="50" r="38" fill="none" stroke="#f1f5f9" strokeWidth="14" />
                {/* Segment 1: Delivered (Emerald) 45% */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="14"
                  strokeDasharray="107 238"
                  strokeDashoffset="0"
                />
                {/* Segment 2: Shipped (Blue) 25% */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="none"
                  stroke="#0284c7"
                  strokeWidth="14"
                  strokeDasharray="60 238"
                  strokeDashoffset="-107"
                />
                {/* Segment 3: Returned (Amber/Orange) 15% */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="14"
                  strokeDasharray="36 238"
                  strokeDashoffset="-167"
                />
                {/* Segment 4: Processing / Cancelled (Red) 15% */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth="14"
                  strokeDasharray="35 238"
                  strokeDashoffset="-203"
                />
              </svg>
            </div>

            {/* Legend */}
            <div className="grid grid-cols-2 gap-1.5 text-[10px] font-semibold text-stone-600 mt-2">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#10b981]" />
                <span>Delivered</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#0284c7]" />
                <span>Shipped</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#f59e0b]" />
                <span>Returned</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#ef4444]" />
                <span>Cancelled</span>
              </span>
            </div>
          </div>
        </div>

        {/* Marketing Performance */}
        <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-1.5">
                <span className="text-base">⚡</span>
                <h3 className="font-bold text-stone-900 text-xs sm:text-sm">Marketing Performance</h3>
              </div>
              <span className="text-[10px] text-stone-400 font-medium">lomba graf v</span>
            </div>

            {/* Bar Chart Visualization */}
            <div className="pt-3">
              <svg viewBox="0 0 200 110" className="w-full h-24 overflow-visible">
                {/* Grid Lines */}
                <line x1="0" y1="20" x2="200" y2="20" stroke="#f1f5f9" />
                <line x1="0" y1="50" x2="200" y2="50" stroke="#f1f5f9" />
                <line x1="0" y1="80" x2="200" y2="80" stroke="#f1f5f9" />

                {/* Multiple Bar Columns per day */}
                {[
                  { x: 10, h1: 45, h2: 30, h3: 20 },
                  { x: 35, h1: 60, h2: 40, h3: 35 },
                  { x: 60, h1: 55, h2: 45, h3: 30 },
                  { x: 85, h1: 65, h2: 35, h3: 40 },
                  { x: 110, h1: 70, h2: 50, h3: 45 },
                  { x: 135, h1: 50, h2: 45, h3: 35 },
                  { x: 160, h1: 65, h2: 55, h3: 50 },
                  { x: 185, h1: 75, h2: 60, h3: 55 },
                ].map((b, idx) => (
                  <g key={`bar-${idx}`}>
                    {/* Orange Bar (Conversions) */}
                    <rect x={b.x} y={100 - b.h1} width="4" height={b.h1} rx="1" fill="#f97316" />
                    {/* Blue Bar (CTR) */}
                    <rect x={b.x + 5} y={100 - b.h2} width="4" height={b.h2} rx="1" fill="#0284c7" />
                    {/* Teal Bar (ROI) */}
                    <rect x={b.x + 10} y={100 - b.h3} width="4" height={b.h3} rx="1" fill="#10b981" />
                  </g>
                ))}
              </svg>

              <div className="flex flex-wrap items-center justify-between text-[9px] font-semibold text-stone-500 mt-2">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#f97316]" />
                  <span>Conversions</span>
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#0284c7]" />
                  <span>Email CTR</span>
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#10b981]" />
                  <span>Social ROI</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions (Matching Screenshot 4 high-contrast buttons) */}
        <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
              <span className="text-base">⚡</span>
              <h3 className="font-bold text-stone-900 text-xs sm:text-sm">Quick Actions</h3>
            </div>

            <div className="mt-3.5 space-y-2">
              {/* + Add New Product (Purple) */}
              <button
                onClick={onNavigateToProducts}
                className="w-full py-2.5 px-3 rounded-xl bg-[#f3e8ff] hover:bg-[#e9d5ff] text-[#6b21a8] border border-[#d8b4fe] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5 text-[#6b21a8]" />
                <span>+ Add New Product</span>
              </button>

              {/* Create Courier Slip (Orange) */}
              <button
                onClick={handleCreateCourierSlip}
                className="w-full py-2.5 px-3 rounded-xl bg-[#ffedd5] hover:bg-[#fed7aa] text-[#c2410c] border border-[#fdba74] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
              >
                <Truck className="w-3.5 h-3.5 text-[#c2410c]" />
                <span>🚚 Create Courier Slip</span>
              </button>

              {/* Sync Google Sheet (Green) */}
              <button
                onClick={handleSyncGoogleSheet}
                className="w-full py-2.5 px-3 rounded-xl bg-[#dcfce7] hover:bg-[#bbf7d0] text-[#15803d] border border-[#86efac] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
              >
                <RefreshCw className="w-3.5 h-3.5 text-[#15803d]" />
                <span>📊 Sync Google Sheet</span>
              </button>

              {/* Download Report (Gray) */}
              <button
                onClick={handleDownloadReport}
                className="w-full py-2.5 px-3 rounded-xl bg-[#f4f4f5] hover:bg-[#e4e4e7] text-[#3f3f46] border border-[#d4d4d8] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
              >
                <Download className="w-3.5 h-3.5 text-[#3f3f46]" />
                <span>📄 Download Report</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
