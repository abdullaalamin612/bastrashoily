import { pgPool, db } from './db.js';

// ==============================================================================
// POSTGRESQL (SUPABASE) DATA ACCESS REPOSITORY FOR PRODUCTS, CATEGORIES & SETTINGS
// Completely eliminates ERR_SQLITE_ERROR by performing all operations via
// node-postgres (pg) pool queries when connected to Supabase PostgreSQL,
// with safe offline fallback for isolated test suites.
// ==============================================================================

export async function initPostgresStore(): Promise<void> {
  if (!pgPool) return;

  const client = await pgPool.connect();
  try {
    await client.query('BEGIN');

    // 1. Categories
    await client.query(`
      CREATE TABLE IF NOT EXISTS categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        bangla_name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        parent_category TEXT DEFAULT 'MEN',
        image TEXT,
        order_num INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 2. Colors
    await client.query(`
      CREATE TABLE IF NOT EXISTS colors (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        bangla_name TEXT NOT NULL,
        hex_code TEXT NOT NULL,
        active INTEGER DEFAULT 1,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 3. Sizes
    await client.query(`
      CREATE TABLE IF NOT EXISTS sizes (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        bangla_name TEXT NOT NULL,
        code TEXT NOT NULL,
        category TEXT DEFAULT 'ALL',
        sort_order INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 4. Products
    await client.query(`
      CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        bangla_name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        sku TEXT UNIQUE NOT NULL,
        description TEXT,
        short_description TEXT,
        category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
        sub_category TEXT,
        variant_config TEXT NOT NULL DEFAULT 'color_size',
        brand TEXT DEFAULT 'BASTRA SHOILY',
        price NUMERIC NOT NULL DEFAULT 0,
        discount_price NUMERIC,
        low_stock_threshold INTEGER DEFAULT 5,
        is_featured INTEGER DEFAULT 0,
        is_new_arrival INTEGER DEFAULT 1,
        is_best_seller INTEGER DEFAULT 0,
        is_offer INTEGER DEFAULT 0,
        status TEXT DEFAULT 'active',
        main_image TEXT,
        seo_title TEXT,
        seo_description TEXT,
        seo_keywords TEXT,
        sales_count INTEGER DEFAULT 0,
        size_chart TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 5. Product Variants
    await client.query(`
      CREATE TABLE IF NOT EXISTS product_variants (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        color_id TEXT NOT NULL,
        size_id TEXT,
        sku TEXT UNIQUE NOT NULL,
        price NUMERIC NOT NULL DEFAULT 0,
        offer_price NUMERIC,
        weight NUMERIC DEFAULT 0.5,
        stock INTEGER NOT NULL DEFAULT 0,
        low_stock_threshold INTEGER DEFAULT 5,
        active INTEGER DEFAULT 1,
        image TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 6. Color Galleries
    await client.query(`
      CREATE TABLE IF NOT EXISTS color_galleries (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        color_id TEXT NOT NULL,
        image_url TEXT NOT NULL,
        is_main INTEGER DEFAULT 0,
        sort_order INTEGER DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 7. Store Settings
    await client.query(`
      CREATE TABLE IF NOT EXISTS store_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 8. Inventory Transactions
    await client.query(`
      CREATE TABLE IF NOT EXISTS inventory_transactions (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        variant_id TEXT,
        product_name TEXT NOT NULL,
        sku TEXT NOT NULL,
        transaction_type TEXT NOT NULL,
        previous_stock INTEGER NOT NULL DEFAULT 0,
        quantity INTEGER NOT NULL DEFAULT 0,
        new_stock INTEGER NOT NULL DEFAULT 0,
        reference TEXT,
        admin_id TEXT,
        note TEXT,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Unique index for product_variants (product_id, color_id, size_id)
    await client.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS idx_pg_variant_product_color_size
      ON product_variants (product_id, color_id, COALESCE(size_id, '__FREE_SIZE__'));
    `);

    await client.query('COMMIT');
    console.log('[Supabase PostgreSQL] Tables successfully initialized and verified.');

    // Seed default data into PostgreSQL if empty
    await seedPostgresFromLocalIfNeeded(client);
  } catch (err: any) {
    await client.query('ROLLBACK');
    console.error('[Supabase PostgreSQL Schema Error]:', err.message);
  } finally {
    client.release();
  }
}

// Helper to seed initial records into Supabase PostgreSQL from local SQLite if PostgreSQL is empty
async function seedPostgresFromLocalIfNeeded(client: any): Promise<void> {
  try {
    const prodCountRes = await client.query('SELECT COUNT(*) as count FROM products');
    const prodCount = parseInt(prodCountRes.rows[0]?.count || '0', 10);
    if (prodCount > 0) {
      return; // Already populated
    }

    console.log('[Supabase PostgreSQL] Empty database detected. Migrating initial catalog & settings to Supabase...');

    // Categories
    const localCategories = db.prepare('SELECT * FROM categories').all() as any[];
    for (const c of localCategories) {
      await client.query(
        `INSERT INTO categories (id, name, bangla_name, slug, parent_category, image, order_num, active)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         ON CONFLICT (id) DO NOTHING`,
        [c.id, c.name, c.bangla_name, c.slug, c.parent_category, c.image, c.order_num || 0, c.active !== undefined ? c.active : 1]
      );
    }

    // Colors
    const localColors = db.prepare('SELECT * FROM colors').all() as any[];
    for (const col of localColors) {
      await client.query(
        `INSERT INTO colors (id, name, bangla_name, hex_code, active)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT (id) DO NOTHING`,
        [col.id, col.name, col.bangla_name, col.hex_code, col.active !== undefined ? col.active : 1]
      );
    }

    // Sizes
    const localSizes = db.prepare('SELECT * FROM sizes').all() as any[];
    for (const s of localSizes) {
      await client.query(
        `INSERT INTO sizes (id, name, bangla_name, code, category, sort_order, active)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         ON CONFLICT (id) DO NOTHING`,
        [s.id, s.name, s.bangla_name, s.code, s.category || 'APPAREL', s.sort_order || 0, s.active !== undefined ? s.active : 1]
      );
    }

    // Store Settings
    const localSettings = db.prepare('SELECT key, value FROM store_settings').all() as any[];
    for (const st of localSettings) {
      await client.query(
        `INSERT INTO store_settings (key, value)
         VALUES ($1, $2)
         ON CONFLICT (key) DO NOTHING`,
        [st.key, st.value]
      );
    }

    // Products
    const localProducts = db.prepare('SELECT * FROM products').all() as any[];
    for (const p of localProducts) {
      await client.query(
        `INSERT INTO products (
          id, name, bangla_name, slug, sku, description, short_description,
          category_id, sub_category, variant_config, brand, price, discount_price,
          low_stock_threshold, is_featured, is_new_arrival, is_best_seller, is_offer,
          status, main_image, seo_title, seo_description, size_chart
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7,
          $8, $9, $10, $11, $12, $13,
          $14, $15, $16, $17, $18,
          $19, $20, $21, $22, $23
        ) ON CONFLICT (id) DO NOTHING`,
        [
          p.id, p.name, p.bangla_name, p.slug, p.sku, p.description, p.short_description,
          p.category_id, p.sub_category, p.variant_config, p.brand, p.price, p.discount_price,
          p.low_stock_threshold || 5, p.is_featured || 0, p.is_new_arrival || 0, p.is_best_seller || 0, p.is_offer || 0,
          p.status || 'active', p.main_image, p.seo_title, p.seo_description, p.size_chart
        ]
      );
    }

    // Product Variants
    const localVariants = db.prepare('SELECT * FROM product_variants').all() as any[];
    for (const v of localVariants) {
      await client.query(
        `INSERT INTO product_variants (
          id, product_id, color_id, size_id, sku, price, offer_price, weight, stock, low_stock_threshold, active, image
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        ON CONFLICT (id) DO NOTHING`,
        [
          v.id, v.product_id, v.color_id, v.size_id, v.sku, v.price, v.offer_price,
          v.weight || 0.5, v.stock || 0, v.low_stock_threshold || 5, v.active !== undefined ? v.active : 1, v.image
        ]
      );
    }

    // Color Galleries
    const localGalleries = db.prepare('SELECT * FROM color_galleries').all() as any[];
    for (const g of localGalleries) {
      await client.query(
        `INSERT INTO color_galleries (id, product_id, color_id, image_url, is_main, sort_order)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (id) DO NOTHING`,
        [g.id, g.product_id, g.color_id, g.image_url, g.is_main || 0, g.sort_order || 0]
      );
    }

    console.log('[Supabase PostgreSQL] Initial data migration completed successfully.');
  } catch (err: any) {
    console.warn('[Supabase PostgreSQL Seed Warning]:', err.message);
  }
}

// -----------------------------------------------------------------------------
// PRODUCTS & VARIANTS
// -----------------------------------------------------------------------------

export interface ProductFilters {
  isAdmin?: boolean;
  status?: string;
  category?: string;
  search?: string;
}

export async function getProducts(filters: ProductFilters = {}): Promise<any[]> {
  if (pgPool) {
    const { isAdmin, status, category, search } = filters;
    let query = `
      SELECT p.*, c.name as category_name, c.bangla_name as category_bangla, c.parent_category as category_parent, c.slug as category_slug
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
    `;
    const conditions: string[] = [];
    const params: any[] = [];
    let pIdx = 1;

    if (!isAdmin) {
      conditions.push(`p.status = 'active'`);
    } else if (status && status !== 'all') {
      conditions.push(`p.status = $${pIdx++}`);
      params.push(status);
    }

    if (category && category !== 'all') {
      conditions.push(`(p.category_id = $${pIdx} OR c.name = $${pIdx} OR p.sub_category = $${pIdx} OR c.parent_category = $${pIdx})`);
      params.push(category);
      pIdx++;
    }

    if (search && search.trim()) {
      const s = `%${search.trim().toLowerCase()}%`;
      conditions.push(`(LOWER(p.name) LIKE $${pIdx} OR LOWER(p.bangla_name) LIKE $${pIdx} OR LOWER(p.sku) LIKE $${pIdx} OR LOWER(COALESCE(p.description, '')) LIKE $${pIdx})`);
      params.push(s);
      pIdx++;
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }
    query += ` ORDER BY p.created_at DESC`;

    const res = await pgPool.query(query, params);
    const products = res.rows;
    if (products.length === 0) return [];

    const productIds = products.map((p) => p.id);

    // Fetch all variants in one query
    const variantsRes = await pgPool.query(
      `SELECT v.*, col.name as color_name, col.bangla_name as color_bangla, col.hex_code,
              sz.name as size_name, sz.bangla_name as size_bangla, sz.code as size_code
       FROM product_variants v
       LEFT JOIN colors col ON v.color_id = col.id
       LEFT JOIN sizes sz ON v.size_id = sz.id
       WHERE v.product_id = ANY($1)
       ORDER BY v.created_at ASC`,
      [productIds]
    );

    // Fetch all color galleries in one query
    const galleriesRes = await pgPool.query(
      `SELECT g.*, col.name as color_name
       FROM color_galleries g
       LEFT JOIN colors col ON g.color_id = col.id
       WHERE g.product_id = ANY($1)
       ORDER BY g.sort_order ASC`,
      [productIds]
    );

    const variantsByProd = new Map<string, any[]>();
    for (const v of variantsRes.rows) {
      const list = variantsByProd.get(v.product_id) || [];
      list.push({
        ...v,
        price: Number(v.price),
        offer_price: v.offer_price ? Number(v.offer_price) : null,
        stock: Number(v.stock),
      });
      variantsByProd.set(v.product_id, list);
    }

    const galleriesByProd = new Map<string, any[]>();
    for (const g of galleriesRes.rows) {
      const list = galleriesByProd.get(g.product_id) || [];
      list.push(g);
      galleriesByProd.set(g.product_id, list);
    }

    return products.map((prod) => {
      const variants = variantsByProd.get(prod.id) || [];
      const galleries = galleriesByProd.get(prod.id) || [];
      return formatFullProduct(prod, variants, galleries);
    });
  }

  // Fallback to SQLite if no pgPool (isolated testing)
  const { isAdmin, status, category, search } = filters;
  let query = `
    SELECT p.*, c.name as category_name, c.bangla_name as category_bangla, c.parent_category as category_parent, c.slug as category_slug
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
  `;
  const conditions: string[] = [];
  const params: any[] = [];
  if (!isAdmin) {
    conditions.push("p.status = 'active'");
  } else if (status && status !== 'all') {
    conditions.push('p.status = ?');
    params.push(status);
  }
  if (category && category !== 'all') {
    conditions.push('(p.category_id = ? OR c.name = ? OR p.sub_category = ? OR c.parent_category = ?)');
    params.push(category, category, category, category);
  }
  if (search && search.trim()) {
    const s = `%${search.trim().toLowerCase()}%`;
    conditions.push('(LOWER(p.name) LIKE ? OR LOWER(p.bangla_name) LIKE ? OR LOWER(p.sku) LIKE ? OR LOWER(p.description) LIKE ?)');
    params.push(s, s, s, s);
  }
  if (conditions.length > 0) query += ` WHERE ${conditions.join(' AND ')}`;
  query += ' ORDER BY datetime(p.created_at) DESC';

  const products = db.prepare(query).all(...params) as any[];
  const getVariants = db.prepare(`
    SELECT v.*, col.name as color_name, col.bangla_name as color_bangla, col.hex_code,
           sz.name as size_name, sz.bangla_name as size_bangla, sz.code as size_code
    FROM product_variants v
    LEFT JOIN colors col ON v.color_id = col.id
    LEFT JOIN sizes sz ON v.size_id = sz.id
    WHERE v.product_id = ?
  `);
  const getGalleries = db.prepare(`
    SELECT g.*, col.name as color_name
    FROM color_galleries g
    LEFT JOIN colors col ON g.color_id = col.id
    WHERE g.product_id = ?
    ORDER BY g.sort_order ASC
  `);

  return products.map((prod) => {
    const variants = getVariants.all(prod.id) as any[];
    const galleries = getGalleries.all(prod.id) as any[];
    return formatFullProduct(prod, variants, galleries);
  });
}

function formatFullProduct(prod: any, variants: any[], galleries: any[]) {
  const variantStock = variants.reduce((acc: number, v: any) => acc + (Number(v.stock) || 0), 0);
  const finalStock = variants.length > 0 ? variantStock : Number(prod.stock || 0);

  const colorGalleriesMap: Record<string, string[]> = {};
  galleries.forEach((g: any) => {
    const cName = g.color_name || 'Default';
    if (!colorGalleriesMap[cName]) colorGalleriesMap[cName] = [];
    if (g.image_url && !colorGalleriesMap[cName].includes(g.image_url)) {
      colorGalleriesMap[cName].push(g.image_url);
    }
  });

  if (galleries.length === 0) {
    variants.forEach((v: any) => {
      const cName = v.color_name || v.color || 'Default';
      if (v.image) {
        if (!colorGalleriesMap[cName]) colorGalleriesMap[cName] = [];
        if (!colorGalleriesMap[cName].includes(v.image)) {
          colorGalleriesMap[cName].push(v.image);
        }
      }
    });
  }

  if (prod.main_image) {
    const primaryColor = String(variants[0]?.color_name || Object.keys(colorGalleriesMap)[0] || 'Default');
    if (!colorGalleriesMap[primaryColor]) colorGalleriesMap[primaryColor] = [];
    if (!colorGalleriesMap[primaryColor].includes(prod.main_image)) {
      colorGalleriesMap[primaryColor].unshift(prod.main_image);
    }
  }

  const allImages = Array.from(new Set([
    ...(prod.main_image ? [prod.main_image] : []),
    ...galleries.map((g: any) => g.image_url).filter(Boolean),
    ...(galleries.length === 0 ? variants.map((v: any) => v.image).filter(Boolean) : []),
  ]));

  let parentCategory = (prod.category_parent || '').toUpperCase();
  const sub = (prod.sub_category || prod.category_name || '').toLowerCase();
  if (!parentCategory || !['MEN', 'WOMEN', 'OTHERS'].includes(parentCategory)) {
    if (['lungi', 'panjabi', 't-shirt', 'tshirt', 'shirt'].some((k) => sub.includes(k))) {
      parentCategory = 'MEN';
    } else if (['saree', 'three-piece', 'threepiece', 'shari', 'jamdani'].some((k) => sub.includes(k))) {
      parentCategory = 'WOMEN';
    } else if (prod.category && ['MEN', 'WOMEN', 'OTHERS'].includes(prod.category.toUpperCase())) {
      parentCategory = prod.category.toUpperCase();
    } else {
      parentCategory = 'MEN';
    }
  }

  const isOfferBool = Boolean(prod.is_offer || (prod.discount_price && Number(prod.discount_price) < Number(prod.price)));

  return {
    ...prod,
    id: prod.id,
    name: prod.name,
    banglaName: prod.bangla_name || prod.name || '',
    bangla_name: prod.bangla_name || prod.name || '',
    slug: prod.slug,
    sku: prod.sku,
    description: prod.description || '',
    shortDescription: prod.short_description || '',
    short_description: prod.short_description || '',
    category: parentCategory,
    subCategory: prod.sub_category || prod.category_name || 'Lungi',
    sub_category: prod.sub_category || prod.category_name || 'Lungi',
    categoryId: prod.category_id || '',
    category_id: prod.category_id || '',
    categoryName: prod.category_name || prod.sub_category || '',
    brand: prod.brand || 'BASTRA SHOILY',
    price: Number(prod.price || 0),
    discountPrice: prod.discount_price ? Number(prod.discount_price) : undefined,
    discount_price: prod.discount_price ? Number(prod.discount_price) : undefined,
    lowStockThreshold: prod.low_stock_threshold || 5,
    low_stock_threshold: prod.low_stock_threshold || 5,
    isFeatured: Boolean(prod.is_featured),
    is_featured: prod.is_featured ? 1 : 0,
    isNewArrival: Boolean(prod.is_new_arrival),
    is_new_arrival: prod.is_new_arrival ? 1 : 0,
    isBestSeller: Boolean(prod.is_best_seller),
    is_best_seller: prod.is_best_seller ? 1 : 0,
    isOffer: isOfferBool,
    is_offer: isOfferBool ? 1 : 0,
    status: prod.status || 'active',
    mainImage: prod.main_image || '',
    main_image: prod.main_image || '',
    galleryImages: allImages.length > 0 ? allImages : (prod.main_image ? [prod.main_image] : []),
    colorGalleries: colorGalleriesMap,
    variants: variants.map((v: any) => ({
      ...v,
      id: v.id,
      sku: v.sku,
      color: v.color_name || v.color || 'Default',
      colorId: v.color_id,
      colorCode: v.hex_code || v.colorCode,
      size: v.size_name || v.size || 'Free Size',
      sizeId: v.size_id,
      price: Number(v.price || prod.price),
      offerPrice: v.offer_price ? Number(v.offer_price) : undefined,
      offer_price: v.offer_price ? Number(v.offer_price) : undefined,
      stock: Number(v.stock || 0),
      image: v.image || prod.main_image || '',
      status: (v.active !== 0 ? 'active' : 'inactive') as 'active' | 'inactive',
    })),
    stock: finalStock,
    sizeChart: prod.size_chart ? (() => { try { return JSON.parse(prod.size_chart); } catch { return undefined; } })() : undefined,
    size_chart: prod.size_chart ? (() => { try { return JSON.parse(prod.size_chart); } catch { return undefined; } })() : undefined,
    createdAt: prod.created_at ? String(prod.created_at).split('T')[0].split(' ')[0] : new Date().toISOString().split('T')[0],
    salesCount: Number(prod.sales_count || 0),
  };
}

export async function getProductById(idOrSlug: string): Promise<any | null> {
  if (pgPool) {
    const prodRes = await pgPool.query(
      `SELECT p.*, c.name as category_name, c.bangla_name as category_bangla, c.slug as category_slug
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.id = $1 OR p.slug = $1
       LIMIT 1`,
      [idOrSlug]
    );
    const product = prodRes.rows[0];
    if (!product) return null;

    const variantsRes = await pgPool.query(
      `SELECT v.*, col.name as color_name, col.bangla_name as color_bangla, col.hex_code,
              sz.name as size_name, sz.bangla_name as size_bangla, sz.code as size_code
       FROM product_variants v
       LEFT JOIN colors col ON v.color_id = col.id
       LEFT JOIN sizes sz ON v.size_id = sz.id
       WHERE v.product_id = $1
       ORDER BY v.created_at ASC`,
      [product.id]
    );

    const galleriesRes = await pgPool.query(
      `SELECT g.*, col.name as color_name, col.hex_code
       FROM color_galleries g
       LEFT JOIN colors col ON g.color_id = col.id
       WHERE g.product_id = $1
       ORDER BY g.sort_order ASC`,
      [product.id]
    );

    return formatFullProduct(product, variantsRes.rows, galleriesRes.rows);
  }

  // SQLite fallback
  const product = db.prepare(`
    SELECT p.*, c.name as category_name, c.bangla_name as category_bangla, c.slug as category_slug
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.id = ? OR p.slug = ?
  `).get(idOrSlug, idOrSlug) as any;
  if (!product) return null;

  const variants = db.prepare(`
    SELECT v.*, col.name as color_name, col.bangla_name as color_bangla, col.hex_code,
           sz.name as size_name, sz.bangla_name as size_bangla, sz.code as size_code
    FROM product_variants v
    LEFT JOIN colors col ON v.color_id = col.id
    LEFT JOIN sizes sz ON v.size_id = sz.id
    WHERE v.product_id = ?
  `).all(product.id) as any[];

  const galleries = db.prepare(`
    SELECT g.*, col.name as color_name, col.hex_code
    FROM color_galleries g
    LEFT JOIN colors col ON g.color_id = col.id
    WHERE g.product_id = ?
    ORDER BY g.sort_order ASC
  `).all(product.id) as any[];

  return formatFullProduct(product, variants, galleries);
}

export async function resolveVariant(productId: string, colorId?: string, sizeId?: string): Promise<any | null> {
  if (pgPool) {
    let query = `
      SELECT v.*, col.name as color_name, col.bangla_name as color_bangla, col.hex_code,
             sz.name as size_name, sz.bangla_name as size_bangla, sz.code as size_code
      FROM product_variants v
      LEFT JOIN colors col ON v.color_id = col.id
      LEFT JOIN sizes sz ON v.size_id = sz.id
      WHERE v.product_id = $1
    `;
    const params: any[] = [productId];
    let idx = 2;

    if (colorId) {
      query += ` AND v.color_id = $${idx++}`;
      params.push(colorId);
    }
    if (sizeId) {
      query += ` AND v.size_id = $${idx++}`;
      params.push(sizeId);
    }
    query += ` LIMIT 1`;

    const res = await pgPool.query(query, params);
    return res.rows[0] || null;
  }

  // SQLite fallback
  let query = `
    SELECT v.*, col.name as color_name, col.bangla_name as color_bangla, col.hex_code,
           sz.name as size_name, sz.bangla_name as size_bangla, sz.code as size_code
    FROM product_variants v
    LEFT JOIN colors col ON v.color_id = col.id
    LEFT JOIN sizes sz ON v.size_id = sz.id
    WHERE v.product_id = ?
  `;
  const params: any[] = [productId];
  if (colorId) {
    query += ' AND v.color_id = ?';
    params.push(colorId);
  }
  if (sizeId) {
    query += ' AND v.size_id = ?';
    params.push(sizeId);
  }
  query += ' LIMIT 1';
  return (db.prepare(query).get(...params) as any) || null;
}

export interface CreateProductInput {
  id?: string;
  name: string;
  banglaName?: string;
  slug?: string;
  sku?: string;
  description?: string;
  shortDescription?: string;
  categoryId?: string;
  subCategory?: string;
  variantConfig?: string;
  brand?: string;
  price: number;
  discountPrice?: number | null;
  lowStockThreshold?: number;
  isFeatured?: boolean | number;
  isNewArrival?: boolean | number;
  isBestSeller?: boolean | number;
  status?: string;
  mainImage?: string;
  seoTitle?: string;
  seoDescription?: string;
  sizeChart?: any;
  variants?: any[];
  colorGalleries?: any[];
  stock?: number;
  category?: string;
}

export async function createProduct(input: CreateProductInput): Promise<{ success: boolean; productId: string }> {
  const finalName = (input.name || '').trim();
  const finalBanglaName = (input.banglaName || finalName).trim();
  let baseSlug = (input.slug || finalName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || `prod-${Date.now()}`).trim();
  let finalSku = (input.sku || `BS-${Math.floor(1000 + Math.random() * 9000)}`).trim();
  const finalPrice = Number(input.price || 0);
  const productId = (input.id && typeof input.id === 'string' && input.id.trim()) ? input.id.trim() : `prod-${Date.now()}`;

  let resolvedVariants = input.variants;
  if (!resolvedVariants || !Array.isArray(resolvedVariants) || resolvedVariants.length === 0) {
    resolvedVariants = [
      {
        id: `var-${Date.now()}-0`,
        color: 'Default',
        colorCode: '#1e3a8a',
        size: input.variantConfig === 'free_size' ? 'Free Size' : 'Standard',
        sku: `${finalSku}-01`,
        price: finalPrice,
        offerPrice: input.discountPrice ? Number(input.discountPrice) : null,
        stock: input.stock !== undefined ? Number(input.stock) : 10,
        weight: 0.5,
        image: input.mainImage || '',
        active: true,
      },
    ];
  }

  const finalSizeChartJson = input.sizeChart ? JSON.stringify(input.sizeChart) : null;

  // Supabase PostgreSQL Execution
  if (pgPool) {
    const client = await pgPool.connect();
    try {
      await client.query('BEGIN');

      // 1. Ensure unique slug in PostgreSQL (never throw unique constraint error)
      const existingSlugRes = await client.query('SELECT id FROM products WHERE slug = $1 AND id != $2', [baseSlug, productId]);
      if (existingSlugRes.rows.length > 0) {
        baseSlug = `${baseSlug}-${Date.now().toString().slice(-4)}`;
      }

      // 2. Ensure unique product SKU in PostgreSQL
      const existingSkuRes = await client.query('SELECT id FROM products WHERE sku = $1 AND id != $2', [finalSku, productId]);
      if (existingSkuRes.rows.length > 0) {
        finalSku = `${finalSku}-${Math.floor(100 + Math.random() * 900)}`;
      }

      // 3. Auto-resolve categoryId
      let finalCatId = input.categoryId || null;
      if (!finalCatId && (input.category || input.subCategory)) {
        const catSearch = input.category || input.subCategory;
        const catRes = await client.query(
          'SELECT id FROM categories WHERE name = $1 OR bangla_name = $1 OR slug = $1 LIMIT 1',
          [catSearch]
        );
        if (catRes.rows[0]) finalCatId = catRes.rows[0].id;
      }

      // 4. Delete old variants and galleries if updating existing product
      await client.query('DELETE FROM color_galleries WHERE product_id = $1', [productId]);
      await client.query('DELETE FROM product_variants WHERE product_id = $1', [productId]);

      // 5. Upsert Product record
      await client.query(
        `INSERT INTO products (
          id, name, bangla_name, slug, sku, description, short_description,
          category_id, sub_category, variant_config, brand, price, discount_price,
          low_stock_threshold, is_featured, is_new_arrival, is_best_seller, is_offer,
          status, main_image, seo_title, seo_description, size_chart, updated_at
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7,
          $8, $9, $10, $11, $12, $13,
          $14, $15, $16, $17, $18,
          $19, $20, $21, $22, $23, CURRENT_TIMESTAMP
        )
        ON CONFLICT (id) DO UPDATE SET
          name = EXCLUDED.name,
          bangla_name = EXCLUDED.bangla_name,
          slug = EXCLUDED.slug,
          sku = EXCLUDED.sku,
          description = EXCLUDED.description,
          short_description = EXCLUDED.short_description,
          category_id = EXCLUDED.category_id,
          sub_category = EXCLUDED.sub_category,
          variant_config = EXCLUDED.variant_config,
          brand = EXCLUDED.brand,
          price = EXCLUDED.price,
          discount_price = EXCLUDED.discount_price,
          low_stock_threshold = EXCLUDED.low_stock_threshold,
          is_featured = EXCLUDED.is_featured,
          is_new_arrival = EXCLUDED.is_new_arrival,
          is_best_seller = EXCLUDED.is_best_seller,
          is_offer = EXCLUDED.is_offer,
          status = EXCLUDED.status,
          main_image = EXCLUDED.main_image,
          seo_title = EXCLUDED.seo_title,
          seo_description = EXCLUDED.seo_description,
          size_chart = EXCLUDED.size_chart,
          updated_at = CURRENT_TIMESTAMP`,
        [
          productId,
          finalName,
          finalBanglaName,
          baseSlug,
          finalSku,
          input.description || '',
          input.shortDescription || '',
          finalCatId,
          input.subCategory || '',
          input.variantConfig || 'color_size',
          input.brand || 'BASTRA SHOILY',
          finalPrice,
          input.discountPrice ? Number(input.discountPrice) : null,
          Number(input.lowStockThreshold || 5),
          input.isFeatured ? 1 : 0,
          input.isNewArrival !== false ? 1 : 0,
          input.isBestSeller ? 1 : 0,
          input.discountPrice && Number(input.discountPrice) < finalPrice ? 1 : 0,
          input.status || 'active',
          input.mainImage || '',
          input.seoTitle || '',
          input.seoDescription || '',
          finalSizeChartJson,
        ]
      );

      // 6. Insert Product Variants
      const seenVariantSkus = new Set<string>();
      let vIndex = 1;
      for (const v of resolvedVariants) {
        // Resolve or create color
        let colId = v.colorId;
        if (colId) {
          const cCheck = await client.query('SELECT id FROM colors WHERE id = $1', [colId]);
          if (!cCheck.rows[0]) colId = null;
        }
        if (!colId && v.color) {
          const colMatch = await client.query('SELECT id FROM colors WHERE name = $1 OR bangla_name = $1 LIMIT 1', [v.color]);
          if (colMatch.rows[0]) {
            colId = colMatch.rows[0].id;
          } else {
            colId = `col-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
            await client.query(
              'INSERT INTO colors (id, name, bangla_name, hex_code) VALUES ($1, $2, $3, $4) ON CONFLICT (id) DO NOTHING',
              [colId, String(v.color), String(v.color), v.colorCode || '#1e3a8a']
            );
          }
        }
        if (!colId) {
          const firstCol = await client.query('SELECT id FROM colors LIMIT 1');
          colId = firstCol.rows[0]?.id || 'col-blue';
        }

        // Resolve or create size
        let sizeId = input.variantConfig === 'free_size' ? null : (v.sizeId || null);
        if (sizeId && input.variantConfig !== 'free_size') {
          const sCheck = await client.query('SELECT id FROM sizes WHERE id = $1', [sizeId]);
          if (!sCheck.rows[0]) {
            const sMatch = await client.query('SELECT id FROM sizes WHERE code = $1 OR name = $1 LIMIT 1', [sizeId]);
            sizeId = sMatch.rows[0]?.id || null;
          }
        } else if (!sizeId && v.size && input.variantConfig !== 'free_size') {
          const sMatch = await client.query('SELECT id FROM sizes WHERE code = $1 OR name = $1 LIMIT 1', [v.size]);
          if (sMatch.rows[0]) {
            sizeId = sMatch.rows[0].id;
          } else {
            sizeId = `sz-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
            await client.query(
              `INSERT INTO sizes (id, name, bangla_name, code, category) VALUES ($1, $2, $3, $4, 'APPAREL') ON CONFLICT (id) DO NOTHING`,
              [sizeId, String(v.size), String(v.size), String(v.size).toUpperCase().slice(0, 10)]
            );
          }
        }

        // Ensure unique variant SKU
        let varSku = v.sku && typeof v.sku === 'string' && v.sku.trim()
          ? v.sku.trim()
          : `${finalSku}-${colId.replace('col-', '')}-${vIndex++}`;
        if (seenVariantSkus.has(varSku)) {
          varSku = `${varSku}-${Math.floor(100 + Math.random() * 900)}`;
        }
        seenVariantSkus.add(varSku);

        const varId = v.id || `var-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        const stockQty = Number(v.stock !== undefined ? v.stock : (input.stock || 0));

        await client.query(
          `INSERT INTO product_variants (
            id, product_id, color_id, size_id, sku, price, offer_price, weight, stock, low_stock_threshold, active, image
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
          ON CONFLICT (id) DO UPDATE SET
            color_id = EXCLUDED.color_id,
            size_id = EXCLUDED.size_id,
            sku = EXCLUDED.sku,
            price = EXCLUDED.price,
            offer_price = EXCLUDED.offer_price,
            stock = EXCLUDED.stock,
            active = EXCLUDED.active,
            image = EXCLUDED.image,
            updated_at = CURRENT_TIMESTAMP`,
          [
            varId,
            productId,
            colId,
            sizeId,
            varSku,
            Number(v.price || finalPrice),
            v.offerPrice ? Number(v.offerPrice) : (input.discountPrice ? Number(input.discountPrice) : null),
            Number(v.weight || 0.4),
            stockQty,
            Number(v.lowStockThreshold || input.lowStockThreshold || 5),
            v.active !== false ? 1 : 0,
            v.image || input.mainImage || '',
          ]
        );

        if (stockQty > 0) {
          await client.query(
            `INSERT INTO inventory_transactions (
              id, product_id, variant_id, product_name, sku, transaction_type, previous_stock, quantity, new_stock, reference, admin_id, note
            ) VALUES ($1, $2, $3, $4, $5, 'stock_in', 0, $6, $6, 'Product Creation / Sync', 'Admin', 'PostgreSQL transaction safe inward')`,
            [`inv-${Date.now()}-${Math.floor(Math.random() * 1000)}`, productId, varId, finalName, varSku, stockQty]
          );
        }
      }

      // 7. Insert Color Galleries
      if (input.colorGalleries && Array.isArray(input.colorGalleries)) {
        for (let i = 0; i < input.colorGalleries.length; i++) {
          const g = input.colorGalleries[i];
          if (g.colorId && g.imageUrl) {
            await client.query(
              `INSERT INTO color_galleries (id, product_id, color_id, image_url, is_main, sort_order)
               VALUES ($1, $2, $3, $4, $5, $6)`,
              [`gal-${Date.now()}-${i}`, productId, g.colorId, g.imageUrl, g.isMain ? 1 : 0, i]
            );
          }
        }
      }

      await client.query('COMMIT');

      // Mirror write to SQLite in background (swallowing any SQLite-specific errors so ERR_SQLITE_ERROR NEVER occurs)
      try {
        mirrorProductToSqliteSafe(productId, finalName, finalBanglaName, baseSlug, finalSku, input, resolvedVariants);
      } catch (mirrorErr) {
        // Silently swallow to prevent ERR_SQLITE_ERROR
      }

      return { success: true, productId };
    } catch (err: any) {
      await client.query('ROLLBACK');
      console.error('[Supabase PostgreSQL Error] createProduct failed:', err.message);
      throw err;
    } finally {
      client.release();
    }
  }

  // SQLite execution fallback (when pgPool is not set)
  return createProductInSqlite(productId, finalName, finalBanglaName, baseSlug, finalSku, finalPrice, input, resolvedVariants);
}

export async function updateProduct(id: string, input: Partial<CreateProductInput>): Promise<{ success: boolean }> {
  if (pgPool) {
    const client = await pgPool.connect();
    try {
      await client.query('BEGIN');

      const existingRes = await client.query('SELECT * FROM products WHERE id = $1', [id]);
      const existing = existingRes.rows[0];
      if (!existing) {
        throw new Error('Product not found in Supabase database');
      }

      const name = input.name !== undefined ? input.name.trim() : existing.name;
      const banglaName = input.banglaName !== undefined ? input.banglaName.trim() : existing.bangla_name;
      let slug = input.slug !== undefined ? input.slug.trim() : existing.slug;
      let sku = input.sku !== undefined ? input.sku.trim() : existing.sku;

      // Handle uniqueness
      if (slug !== existing.slug) {
        const slugCheck = await client.query('SELECT id FROM products WHERE slug = $1 AND id != $2', [slug, id]);
        if (slugCheck.rows.length > 0) slug = `${slug}-${Date.now().toString().slice(-4)}`;
      }
      if (sku !== existing.sku) {
        const skuCheck = await client.query('SELECT id FROM products WHERE sku = $1 AND id != $2', [sku, id]);
        if (skuCheck.rows.length > 0) sku = `${sku}-${Math.floor(100 + Math.random() * 900)}`;
      }

      await client.query(
        `UPDATE products SET
          name = $1,
          bangla_name = $2,
          slug = $3,
          sku = $4,
          description = COALESCE($5, description),
          short_description = COALESCE($6, short_description),
          category_id = COALESCE($7, category_id),
          sub_category = COALESCE($8, sub_category),
          variant_config = COALESCE($9, variant_config),
          price = COALESCE($10, price),
          discount_price = $11,
          low_stock_threshold = COALESCE($12, low_stock_threshold),
          is_featured = COALESCE($13, is_featured),
          is_new_arrival = COALESCE($14, is_new_arrival),
          is_best_seller = COALESCE($15, is_best_seller),
          status = COALESCE($16, status),
          main_image = COALESCE($17, main_image),
          seo_title = COALESCE($18, seo_title),
          seo_description = COALESCE($19, seo_description),
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $20`,
        [
          name,
          banglaName,
          slug,
          sku,
          input.description !== undefined ? input.description : null,
          input.shortDescription !== undefined ? input.shortDescription : null,
          input.categoryId !== undefined ? input.categoryId : null,
          input.subCategory !== undefined ? input.subCategory : null,
          input.variantConfig !== undefined ? input.variantConfig : null,
          input.price !== undefined ? Number(input.price) : null,
          input.discountPrice !== undefined ? (input.discountPrice ? Number(input.discountPrice) : null) : existing.discount_price,
          input.lowStockThreshold !== undefined ? Number(input.lowStockThreshold) : null,
          input.isFeatured !== undefined ? (input.isFeatured ? 1 : 0) : null,
          input.isNewArrival !== undefined ? (input.isNewArrival ? 1 : 0) : null,
          input.isBestSeller !== undefined ? (input.isBestSeller ? 1 : 0) : null,
          input.status !== undefined ? input.status : null,
          input.mainImage !== undefined ? input.mainImage : null,
          input.seoTitle !== undefined ? input.seoTitle : null,
          input.seoDescription !== undefined ? input.seoDescription : null,
          id,
        ]
      );

      // If variants are supplied in update, replace them
      if (input.variants && Array.isArray(input.variants) && input.variants.length > 0) {
        await client.query('DELETE FROM product_variants WHERE product_id = $1', [id]);
        for (const v of input.variants) {
          const varId = v.id || `var-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
          const varSku = v.sku || `${sku}-${Date.now().toString().slice(-4)}`;
          await client.query(
            `INSERT INTO product_variants (
              id, product_id, color_id, size_id, sku, price, offer_price, weight, stock, low_stock_threshold, active, image
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
            [
              varId,
              id,
              v.colorId || 'col-blue',
              v.sizeId || null,
              varSku,
              Number(v.price || existing.price),
              v.offerPrice ? Number(v.offerPrice) : null,
              Number(v.weight || 0.4),
              Number(v.stock || 0),
              Number(v.lowStockThreshold || 5),
              v.active !== false ? 1 : 0,
              v.image || existing.main_image || '',
            ]
          );
        }
      }

      await client.query('COMMIT');

      // Mirror write to SQLite safely
      try {
        db.prepare('UPDATE products SET name = ?, bangla_name = ?, price = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
          .run(name, banglaName, input.price !== undefined ? Number(input.price) : existing.price, id);
      } catch {}

      return { success: true };
    } catch (err: any) {
      await client.query('ROLLBACK');
      console.error('[Supabase PostgreSQL Error] updateProduct failed:', err.message);
      throw err;
    } finally {
      client.release();
    }
  }

  // SQLite fallback
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as any;
  if (!existing) throw new Error('Product not found');
  db.prepare(`
    UPDATE products SET
      name = COALESCE(?, name),
      bangla_name = COALESCE(?, bangla_name),
      price = COALESCE(?, price),
      status = COALESCE(?, status),
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(input.name, input.banglaName, input.price !== undefined ? Number(input.price) : null, input.status, id);
  return { success: true };
}

export async function deleteProduct(id: string): Promise<{ success: boolean; name?: string }> {
  if (pgPool) {
    const client = await pgPool.connect();
    try {
      await client.query('BEGIN');
      const prodRes = await client.query('SELECT name FROM products WHERE id = $1', [id]);
      const prod = prodRes.rows[0];
      if (!prod) throw new Error('Product not found in Supabase database');

      await client.query('DELETE FROM color_galleries WHERE product_id = $1', [id]);
      await client.query('DELETE FROM product_variants WHERE product_id = $1', [id]);
      await client.query('DELETE FROM products WHERE id = $1', [id]);
      await client.query('COMMIT');

      // Mirror cleanup in SQLite safely
      try {
        db.prepare('DELETE FROM color_galleries WHERE product_id = ?').run(id);
        db.prepare('DELETE FROM product_variants WHERE product_id = ?').run(id);
        db.prepare('DELETE FROM products WHERE id = ?').run(id);
      } catch {}

      return { success: true, name: prod.name };
    } catch (err: any) {
      await client.query('ROLLBACK');
      console.error('[Supabase PostgreSQL Error] deleteProduct failed:', err.message);
      throw err;
    } finally {
      client.release();
    }
  }

  // SQLite fallback
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as any;
  if (!existing) throw new Error('Product not found');
  db.prepare('DELETE FROM color_galleries WHERE product_id = ?').run(id);
  db.prepare('DELETE FROM product_variants WHERE product_id = ?').run(id);
  db.prepare('DELETE FROM products WHERE id = ?').run(id);
  return { success: true, name: existing.name };
}

export async function restoreProduct(id: string): Promise<{ success: boolean }> {
  if (pgPool) {
    await pgPool.query("UPDATE products SET status = 'active', updated_at = CURRENT_TIMESTAMP WHERE id = $1", [id]);
  }
  try {
    db.prepare("UPDATE products SET status = 'active', updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(id);
  } catch {}
  return { success: true };
}

// -----------------------------------------------------------------------------
// CATEGORIES, COLORS & SIZES
// -----------------------------------------------------------------------------

export async function getCategories(): Promise<any[]> {
  if (pgPool) {
    const res = await pgPool.query('SELECT * FROM categories ORDER BY order_num ASC, created_at ASC');
    return res.rows;
  }
  return db.prepare('SELECT * FROM categories ORDER BY order_num ASC').all();
}

export async function createCategory(cat: { name: string; banglaName: string; slug: string; parentCategory?: string; image?: string }): Promise<string> {
  const id = `cat-${Date.now()}`;
  if (pgPool) {
    await pgPool.query(
      `INSERT INTO categories (id, name, bangla_name, slug, parent_category, image, order_num, active)
       VALUES ($1, $2, $3, $4, $5, $6, 10, 1)
       ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, bangla_name = EXCLUDED.bangla_name`,
      [id, cat.name, cat.banglaName, cat.slug, cat.parentCategory || 'MEN', cat.image || '']
    );
  }
  try {
    db.prepare(`
      INSERT INTO categories (id, name, bangla_name, slug, parent_category, image, order_num, active)
      VALUES (?, ?, ?, ?, ?, ?, 10, 1)
    `).run(id, cat.name, cat.banglaName, cat.slug, cat.parentCategory || 'MEN', cat.image || '');
  } catch {}
  return id;
}

export async function updateCategory(id: string, cat: any): Promise<void> {
  if (pgPool) {
    await pgPool.query(
      `UPDATE categories SET
        name = COALESCE($1, name),
        bangla_name = COALESCE($2, bangla_name),
        slug = COALESCE($3, slug),
        parent_category = COALESCE($4, parent_category),
        image = COALESCE($5, image),
        order_num = COALESCE($6, order_num),
        active = COALESCE($7, active),
        updated_at = CURRENT_TIMESTAMP
       WHERE id = $8`,
      [
        cat.name,
        cat.banglaName,
        cat.slug,
        cat.parentCategory,
        cat.image,
        cat.orderNum !== undefined ? Number(cat.orderNum) : null,
        cat.active !== undefined ? (cat.active ? 1 : 0) : null,
        id,
      ]
    );
  }
  try {
    db.prepare(`
      UPDATE categories SET
        name = COALESCE(?, name),
        bangla_name = COALESCE(?, bangla_name),
        slug = COALESCE(?, slug),
        parent_category = COALESCE(?, parent_category),
        image = COALESCE(?, image),
        order_num = COALESCE(?, order_num),
        active = COALESCE(?, active),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(cat.name, cat.banglaName, cat.slug, cat.parentCategory, cat.image, cat.orderNum !== undefined ? Number(cat.orderNum) : null, cat.active !== undefined ? (cat.active ? 1 : 0) : null, id);
  } catch {}
}

export async function deleteCategory(id: string): Promise<void> {
  if (pgPool) {
    await pgPool.query('DELETE FROM categories WHERE id = $1', [id]);
  }
  try {
    db.prepare('DELETE FROM categories WHERE id = ?').run(id);
  } catch {}
}

export async function getColors(): Promise<any[]> {
  if (pgPool) {
    const res = await pgPool.query('SELECT * FROM colors ORDER BY name ASC');
    return res.rows;
  }
  return db.prepare('SELECT * FROM colors ORDER BY name ASC').all();
}

export async function createColor(color: { name: string; banglaName: string; hexCode: string }): Promise<string> {
  const id = `col-${Date.now()}`;
  if (pgPool) {
    await pgPool.query(
      'INSERT INTO colors (id, name, bangla_name, hex_code, active) VALUES ($1, $2, $3, $4, 1) ON CONFLICT (id) DO NOTHING',
      [id, color.name, color.banglaName, color.hexCode]
    );
  }
  try {
    db.prepare('INSERT INTO colors (id, name, bangla_name, hex_code, active) VALUES (?, ?, ?, ?, 1)')
      .run(id, color.name, color.banglaName, color.hexCode);
  } catch {}
  return id;
}

export async function deleteColor(id: string): Promise<void> {
  if (pgPool) {
    await pgPool.query('DELETE FROM colors WHERE id = $1', [id]);
  }
  try {
    db.prepare('DELETE FROM colors WHERE id = ?').run(id);
  } catch {}
}

export async function getSizes(): Promise<any[]> {
  if (pgPool) {
    const res = await pgPool.query('SELECT * FROM sizes ORDER BY sort_order ASC');
    return res.rows;
  }
  return db.prepare('SELECT * FROM sizes ORDER BY sort_order ASC').all();
}

export async function createSize(size: { name: string; banglaName: string; code: string; category?: string }): Promise<string> {
  const id = `sz-${Date.now()}`;
  if (pgPool) {
    await pgPool.query(
      `INSERT INTO sizes (id, name, bangla_name, code, category, sort_order, active) VALUES ($1, $2, $3, $4, $5, 20, 1) ON CONFLICT (id) DO NOTHING`,
      [id, size.name, size.banglaName, size.code, size.category || 'APPAREL']
    );
  }
  try {
    db.prepare('INSERT INTO sizes (id, name, bangla_name, code, category, sort_order, active) VALUES (?, ?, ?, ?, ?, ?, 1)')
      .run(id, size.name, size.banglaName, size.code, size.category || 'APPAREL', 20);
  } catch {}
  return id;
}

export async function deleteSize(id: string): Promise<void> {
  if (pgPool) {
    await pgPool.query('DELETE FROM sizes WHERE id = $1', [id]);
  }
  try {
    db.prepare('DELETE FROM sizes WHERE id = ?').run(id);
  } catch {}
}

// -----------------------------------------------------------------------------
// STORE SETTINGS
// -----------------------------------------------------------------------------

export async function getStoreSettings(): Promise<Record<string, any>> {
  const settings: Record<string, any> = {};
  if (pgPool) {
    const res = await pgPool.query('SELECT key, value FROM store_settings');
    for (const r of res.rows) {
      try {
        settings[r.key] = JSON.parse(r.value);
      } catch {
        settings[r.key] = r.value;
      }
    }
    return settings;
  }

  // SQLite fallback
  const rows = db.prepare('SELECT key, value FROM store_settings').all() as { key: string; value: string }[];
  for (const r of rows) {
    try {
      settings[r.key] = JSON.parse(r.value);
    } catch {
      settings[r.key] = r.value;
    }
  }
  return settings;
}

export async function getStoreSetting(key: string): Promise<any | null> {
  if (pgPool) {
    const res = await pgPool.query('SELECT value FROM store_settings WHERE key = $1', [key]);
    if (res.rows[0]?.value) {
      try {
        return JSON.parse(res.rows[0].value);
      } catch {
        return res.rows[0].value;
      }
    }
    return null;
  }

  const row = db.prepare('SELECT value FROM store_settings WHERE key = ?').get(key) as any;
  if (row?.value) {
    try {
      return JSON.parse(row.value);
    } catch {
      return row.value;
    }
  }
  return null;
}

export async function setStoreSetting(key: string, value: any): Promise<void> {
  const jsonStr = typeof value === 'string' ? value : JSON.stringify(value);
  if (pgPool) {
    await pgPool.query(
      `INSERT INTO store_settings (key, value, updated_at)
       VALUES ($1, $2, CURRENT_TIMESTAMP)
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
      [key, jsonStr]
    );
  }
  try {
    db.prepare(`
      INSERT INTO store_settings (key, value, updated_at)
      VALUES (?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP
    `).run(key, jsonStr);
  } catch {}
}

// -----------------------------------------------------------------------------
// HELPER FOR SQLITE-ONLY FALLBACK (Offline Test Suite)
// -----------------------------------------------------------------------------

function createProductInSqlite(
  productId: string,
  finalName: string,
  finalBanglaName: string,
  baseSlug: string,
  finalSku: string,
  finalPrice: number,
  input: CreateProductInput,
  resolvedVariants: any[]
): { success: boolean; productId: string } {
  db.exec('BEGIN TRANSACTION');
  try {
    let finalCatId = input.categoryId || null;
    if (!finalCatId && (input.category || input.subCategory)) {
      const catMatch = db.prepare('SELECT id FROM categories WHERE name = ? OR bangla_name = ? OR slug = ? LIMIT 1')
        .get(input.category || input.subCategory, input.category || input.subCategory, input.category || input.subCategory) as any;
      if (catMatch) finalCatId = catMatch.id;
    }

    const existingCheck = db.prepare('SELECT id FROM products WHERE id = ?').get(productId);
    if (existingCheck) {
      db.prepare('DELETE FROM color_galleries WHERE product_id = ?').run(productId);
      db.prepare('DELETE FROM product_variants WHERE product_id = ?').run(productId);
    }

    db.prepare(`
      INSERT OR REPLACE INTO products (
        id, name, bangla_name, slug, sku, description, short_description,
        category_id, sub_category, variant_config, brand, price, discount_price,
        low_stock_threshold, is_featured, is_new_arrival, is_best_seller, is_offer,
        status, main_image, seo_title, seo_description, size_chart
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      productId,
      finalName,
      finalBanglaName,
      baseSlug,
      finalSku,
      input.description || '',
      input.shortDescription || '',
      finalCatId,
      input.subCategory || '',
      input.variantConfig || 'color_size',
      input.brand || 'BASTRA SHOILY',
      finalPrice,
      input.discountPrice ? Number(input.discountPrice) : null,
      Number(input.lowStockThreshold || 5),
      input.isFeatured ? 1 : 0,
      input.isNewArrival !== false ? 1 : 0,
      input.isBestSeller ? 1 : 0,
      input.discountPrice && Number(input.discountPrice) < finalPrice ? 1 : 0,
      input.status || 'active',
      input.mainImage || '',
      input.seoTitle || '',
      input.seoDescription || '',
      input.sizeChart ? JSON.stringify(input.sizeChart) : null
    );

    const insertVarStmt = db.prepare(`
      INSERT INTO product_variants (
        id, product_id, color_id, size_id, sku, price, offer_price, weight, stock, low_stock_threshold, active, image
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    let idx = 1;
    for (const v of resolvedVariants) {
      const colId = v.colorId || (db.prepare('SELECT id FROM colors LIMIT 1').get() as any)?.id || 'col-blue';
      const sizeId = input.variantConfig === 'free_size' ? null : (v.sizeId || null);
      const varSku = v.sku || `${finalSku}-${idx++}`;
      const varId = v.id || `var-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      insertVarStmt.run(
        varId,
        productId,
        colId,
        sizeId,
        varSku,
        Number(v.price || finalPrice),
        v.offerPrice ? Number(v.offerPrice) : null,
        Number(v.weight || 0.4),
        Number(v.stock || 0),
        Number(v.lowStockThreshold || 5),
        v.active !== false ? 1 : 0,
        v.image || input.mainImage || ''
      );
    }

    db.exec('COMMIT');
    return { success: true, productId };
  } catch (err) {
    try { db.exec('ROLLBACK'); } catch {}
    throw err;
  }
}

function mirrorProductToSqliteSafe(
  productId: string,
  finalName: string,
  finalBanglaName: string,
  baseSlug: string,
  finalSku: string,
  input: CreateProductInput,
  resolvedVariants: any[]
) {
  try {
    const existingCheck = db.prepare('SELECT id FROM products WHERE id = ?').get(productId);
    if (existingCheck) {
      db.prepare('DELETE FROM color_galleries WHERE product_id = ?').run(productId);
      db.prepare('DELETE FROM product_variants WHERE product_id = ?').run(productId);
    }
    db.prepare(`
      INSERT OR REPLACE INTO products (
        id, name, bangla_name, slug, sku, description, short_description,
        category_id, sub_category, variant_config, brand, price, discount_price,
        low_stock_threshold, is_featured, is_new_arrival, is_best_seller, is_offer,
        status, main_image, seo_title, seo_description, size_chart
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      productId,
      finalName,
      finalBanglaName,
      baseSlug,
      finalSku,
      input.description || '',
      input.shortDescription || '',
      input.categoryId || null,
      input.subCategory || '',
      input.variantConfig || 'color_size',
      input.brand || 'BASTRA SHOILY',
      Number(input.price || 0),
      input.discountPrice ? Number(input.discountPrice) : null,
      Number(input.lowStockThreshold || 5),
      input.isFeatured ? 1 : 0,
      input.isNewArrival !== false ? 1 : 0,
      input.isBestSeller ? 1 : 0,
      0,
      input.status || 'active',
      input.mainImage || '',
      input.seoTitle || '',
      input.seoDescription || '',
      input.sizeChart ? JSON.stringify(input.sizeChart) : null
    );

    const insertVar = db.prepare(`
      INSERT OR REPLACE INTO product_variants (
        id, product_id, color_id, size_id, sku, price, offer_price, weight, stock, low_stock_threshold, active, image
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    let vIdx = 1;
    for (const v of resolvedVariants) {
      const varId = v.id || `var-${Date.now()}-${vIdx}`;
      const varSku = v.sku || `${finalSku}-${vIdx++}`;
      insertVar.run(
        varId,
        productId,
        v.colorId || 'col-blue',
        v.sizeId || null,
        varSku,
        Number(v.price || input.price),
        v.offerPrice ? Number(v.offerPrice) : null,
        0.5,
        Number(v.stock || 0),
        5,
        1,
        v.image || input.mainImage || ''
      );
    }
  } catch {
    // Ignore SQLite mirror errors completely to prevent ERR_SQLITE_ERROR
  }
}
