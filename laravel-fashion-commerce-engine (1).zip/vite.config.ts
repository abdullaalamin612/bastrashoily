import tailwindcss from '@tailwindcss/vite';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [tailwindcss()],
    build: {
      outDir: 'public/build',
      manifest: true,
      rollupOptions: {
        input: [
          'resources/css/app.css',
          'resources/js/app.js'
        ],
      },
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, 'resources'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
