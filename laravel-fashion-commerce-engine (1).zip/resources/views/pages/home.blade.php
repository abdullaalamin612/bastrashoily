@extends('layouts.app')

@section('content')
@php
    $currencyService = app(\App\Services\CurrencyService::class);
    $settings = app(\App\Services\SettingsService::class);
    $locale = app()->getLocale();
    $currentCurrency = session('currency', 'BDT');

    // Sample fashion catalog items displaying real dynamic currency conversions
    $sampleProducts = [
        [
            'title_bn' => 'আভিজাত্যিক ঢাকাই জামদানি শাড়ি',
            'title_en' => 'Imperial Dhakai Jamdani Saree',
            'category_bn' => 'ঐতিহ্যবাহী শাড়ি',
            'category_en' => 'Heritage Sarees',
            'price_bdt' => 14500,
            'tag' => 'Signature',
            'image_color' => 'bg-[#2B231D]',
        ],
        [
            'title_bn' => 'প্রিমিয়াম হ্যান্ডলুম কটন পাঞ্জাবি',
            'title_en' => 'Premium Handloom Cotton Panjabi',
            'category_bn' => 'পুরুষদের ফ্যাশন',
            'category_en' => 'Men\'s Ethnic',
            'price_bdt' => 4850,
            'tag' => 'Bestseller',
            'image_color' => 'bg-[#3D3A37]',
        ],
        [
            'title_bn' => 'এমব্রয়ডারি করা সিল্ক কুর্তি সেট',
            'title_en' => 'Embroidered Pure Silk Kurti Set',
            'category_bn' => 'নারী ফ্যাশন',
            'category_en' => 'Women\'s Pret',
            'price_bdt' => 6200,
            'tag' => 'New Season',
            'image_color' => 'bg-[#4A443F]',
        ],
        [
            'title_bn' => 'খাঁটি চামড়ার হ্যান্ডক্রাফটেড ক্লাচ ব্যাগ',
            'title_en' => 'Handcrafted Full-Grain Leather Clutch',
            'category_bn' => 'অ্যাক্সেসরিজ',
            'category_en' => 'Leather Goods',
            'price_bdt' => 3500,
            'tag' => 'Limited',
            'image_color' => 'bg-[#232526]',
        ],
    ];
@endphp

<!-- Hero Section -->
<section class="relative bg-[#202020] text-white overflow-hidden py-16 sm:py-24 border-b border-[#333333]">
    <div class="absolute inset-0 opacity-10 bg-[radial-gradient(#D6C6AA_1px,transparent_1px)] [background-size:16px_16px]"></div>
    
    <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div class="lg:col-span-7 space-y-6 text-center lg:text-left">
                <div class="inline-flex items-center gap-2 px-3 py-1 bg-white/10 border border-[#D6C6AA]/30 text-[#D6C6AA] text-xs uppercase tracking-widest font-semibold">
                    <span>✨</span>
                    <span>{{ $locale === 'bn' ? 'শৈলী জোন — নতুন সিজন কালেকশন ২০২৬' : 'Shoily Zoon — New Season Haute Couture 2026' }}</span>
                </div>

                <h1 class="text-3xl sm:text-5xl lg:text-6xl font-serif font-bold tracking-tight text-[#F7F5F0] leading-tight">
                    @if($locale === 'bn')
                        ঐতিহ্যের সূক্ষ্ম কারুকাজ ও <br class="hidden sm:inline">
                        <span class="text-[#D6C6AA] italic">আধুনিক আভিজাত্যের মিলন</span>
                    @else
                        Timeless Heritage Tailoring & <br class="hidden sm:inline">
                        <span class="text-[#D6C6AA] italic">Contemporary Luxury</span>
                    @endif
                </h1>

                <p class="text-sm sm:text-base text-white/80 max-w-xl leading-relaxed mx-auto lg:mx-0">
                    @if($locale === 'bn')
                        বাংলাদেশের শীর্ষস্থানীয় তাঁতি ও কারিগরদের নিখুঁত হাতে বোনা জামদানি, এক্সক্লুসিভ পাঞ্জাবি ও আন্তর্জাতিক মানের পোশাক সম্ভার।
                    @else
                        Mastercrafted handloom textiles, royal Jamdani sarees, and signature ethnic couture tailored for discerning clients in Bangladesh and across the globe.
                    @endif
                </p>

                <!-- Call to Actions -->
                <div class="pt-4 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                    <a href="#featured" class="w-full sm:w-auto px-8 py-3.5 bg-[#D6C6AA] text-[#202020] text-xs font-bold uppercase tracking-widest hover:bg-[#C5B393] transition-all text-center">
                        {{ $locale === 'bn' ? 'কালেকশন দেখুন' : 'Explore Collections' }}
                    </a>
                    <a href="{{ route('admin.dashboard') }}" class="w-full sm:w-auto px-8 py-3.5 border border-white/30 text-white text-xs font-semibold uppercase tracking-widest hover:border-white hover:bg-white/5 transition-all text-center">
                        {{ __('admin.admin_panel') }}
                    </a>
                </div>

                <!-- Fast Currency Preview -->
                <div class="pt-4 text-xs text-white/60 flex items-center justify-center lg:justify-start gap-3">
                    <span>{{ __('messages.currency') }}:</span>
                    <span class="text-[#D6C6AA] font-bold">{{ $currentCurrency }}</span>
                    <span>•</span>
                    <span>{{ __('messages.language') }}:</span>
                    <span class="text-[#D6C6AA] font-bold">{{ $locale === 'bn' ? 'বাংলা (ডিফল্ট)' : 'English' }}</span>
                </div>
            </div>

            <!-- Hero Feature Card -->
            <div class="lg:col-span-5">
                <div class="relative bg-white/[0.04] p-8 border border-white/10 shadow-2xl backdrop-blur-sm">
                    <div class="flex items-center justify-between pb-6 border-b border-white/10">
                        <span class="text-xs uppercase tracking-widest text-[#D6C6AA] font-semibold">
                            {{ $locale === 'bn' ? 'সিগনেচার আর্কিটেকচার' : 'Platform Architecture' }}
                        </span>
                        <span class="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-mono uppercase tracking-wider border border-emerald-500/30">
                            Phase 1 Active
                        </span>
                    </div>

                    <div class="py-6 space-y-4 text-xs text-white/80">
                        <div class="flex items-center justify-between">
                            <span class="text-white/60">Backend Engine:</span>
                            <span class="font-mono text-white">Laravel 11.57 + PHP 8.2</span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-white/60">Database:</span>
                            <span class="font-mono text-emerald-400">MySQL / MariaDB (shoily_zoon)</span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-white/60">Frontend Stack:</span>
                            <span class="font-mono text-white">Blade + Tailwind + Livewire</span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-white/60">Multi-Currency:</span>
                            <span class="font-mono text-[#D6C6AA]">BDT (৳), USD ($), EUR (€), GBP (£), AED, SAR</span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-white/60">Default Market:</span>
                            <span class="font-mono text-white">Bangladesh (International Enabled)</span>
                        </div>
                    </div>

                    <div class="pt-4 border-t border-white/10">
                        <div class="p-3 bg-black/40 border border-white/5 rounded text-[11px] text-white/70">
                            💡 <strong>{{ $locale === 'bn' ? 'লাইভ কারেন্সি রূপান্তর সক্রিয়:' : 'Live Multi-Currency Activated:' }}</strong>
                            {{ $locale === 'bn' ? 'যেকোনো মুদ্রায় তাৎক্ষণিক মূল্য প্রদর্শন করতে উপরের মুদ্রা মেনু থেকে পরিবর্তন করুন।' : 'Prices dynamically convert to your selected currency using official database exchange rates.' }}
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- Featured Fashion Catalog (Dynamic Currency Preview) -->
<section id="featured" class="py-16 sm:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex flex-col md:flex-row md:items-end justify-between mb-12">
        <div>
            <span class="text-xs uppercase tracking-[0.2em] text-[#8C7355] font-semibold block mb-2">
                {{ $locale === 'bn' ? 'প্রিমিয়াম ক্যাটালগ আর্কিটেকচার' : 'Curated Showcase' }}
            </span>
            <h2 class="text-2xl sm:text-4xl font-serif font-bold text-[#202020]">
                {{ $locale === 'bn' ? 'শৈলী জোন এক্সক্লুসিভ সম্ভার' : 'Exclusive Signature Pieces' }}
            </h2>
        </div>
        <div class="mt-4 md:mt-0 text-xs text-[#737373]">
            {{ $locale === 'bn' ? 'রিয়েল-টাইম ডাটাবেজ কারেন্সি রূপান্তর সক্রিয়' : 'Real-time database multi-currency conversion active' }}
        </div>
    </div>

    <!-- Product Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        @foreach($sampleProducts as $product)
            <div class="fashion-card group bg-white border border-[#E8E4DC] flex flex-col justify-between overflow-hidden">
                <!-- Image Placeholder with luxury palette -->
                <div class="relative h-72 {{ $product['image_color'] }} flex items-center justify-center p-6 text-center text-white/90">
                    <div class="space-y-2">
                        <span class="text-4xl block">✨</span>
                        <span class="text-xs tracking-widest uppercase font-serif text-[#D6C6AA]">
                            {{ $locale === 'bn' ? $product['category_bn'] : $product['category_en'] }}
                        </span>
                    </div>
                    <span class="absolute top-3 left-3 bg-[#202020] text-[#D6C6AA] text-[10px] uppercase font-bold tracking-widest px-2.5 py-1">
                        {{ $product['tag'] }}
                    </span>
                </div>

                <!-- Product Content -->
                <div class="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                        <span class="text-[11px] uppercase tracking-wider text-[#737373] block mb-1">
                            {{ $locale === 'bn' ? $product['category_bn'] : $product['category_en'] }}
                        </span>
                        <h3 class="font-medium text-sm text-[#202020] group-hover:text-[#8C7355] transition-colors line-clamp-2">
                            {{ $locale === 'bn' ? $product['title_bn'] : $product['title_en'] }}
                        </h3>
                    </div>

                    <!-- Price & Actions -->
                    <div class="pt-3 border-t border-[#E8E4DC] flex items-center justify-between">
                        <div>
                            <span class="text-[10px] uppercase tracking-wider text-[#737373] block">
                                {{ __('messages.price') }}
                            </span>
                            <span class="font-serif text-lg font-bold text-[#202020]">
                                {{ $currencyService->format($product['price_bdt']) }}
                            </span>
                        </div>
                        <button type="button" class="px-3 py-1.5 bg-[#202020] text-white text-xs hover:bg-[#333333] transition-colors" title="{{ __('messages.add_to_cart') }}">
                            {{ __('messages.add_to_cart') }}
                        </button>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</section>

<!-- Category Highlights -->
<section class="bg-white py-16 border-y border-[#E8E4DC]">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-2xl mx-auto mb-12">
            <span class="text-xs uppercase tracking-[0.2em] text-[#8C7355] font-semibold block mb-2">
                {{ __('messages.categories') }}
            </span>
            <h2 class="text-2xl sm:text-3xl font-serif font-bold text-[#202020]">
                {{ $locale === 'bn' ? 'সকল ফ্যাশন বিভাগের জন্য তৈরি' : 'Crafted For Every Generation' }}
            </h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            <div class="p-6 border border-[#E8E4DC] text-center hover:border-[#202020] transition-colors bg-[#F7F5F0]">
                <span class="text-3xl block mb-2">👗</span>
                <h3 class="font-serif font-semibold text-sm sm:text-base text-[#202020]">{{ __('messages.women') }}</h3>
                <p class="text-[11px] text-[#737373] mt-1">{{ $locale === 'bn' ? 'শাড়ি, সালোয়ার কামিজ ও কুর্তি' : 'Sarees, Suits & Kurtis' }}</p>
            </div>
            <div class="p-6 border border-[#E8E4DC] text-center hover:border-[#202020] transition-colors bg-[#F7F5F0]">
                <span class="text-3xl block mb-2">👔</span>
                <h3 class="font-serif font-semibold text-sm sm:text-base text-[#202020]">{{ __('messages.men') }}</h3>
                <p class="text-[11px] text-[#737373] mt-1">{{ $locale === 'bn' ? 'পাঞ্জাবি, পায়জামা ও কাবলি' : 'Panjabis, Pajamas & Ethnic' }}</p>
            </div>
            <div class="p-6 border border-[#E8E4DC] text-center hover:border-[#202020] transition-colors bg-[#F7F5F0]">
                <span class="text-3xl block mb-2">🧒</span>
                <h3 class="font-serif font-semibold text-sm sm:text-base text-[#202020]">{{ __('messages.kids') }}</h3>
                <p class="text-[11px] text-[#737373] mt-1">{{ $locale === 'bn' ? 'উৎসব ও আধুনিক পোশাক' : 'Festive & Casual Wear' }}</p>
            </div>
            <div class="p-6 border border-[#E8E4DC] text-center hover:border-[#202020] transition-colors bg-[#F7F5F0]">
                <span class="text-3xl block mb-2">👜</span>
                <h3 class="font-serif font-semibold text-sm sm:text-base text-[#202020]">{{ __('messages.accessories') }}</h3>
                <p class="text-[11px] text-[#737373] mt-1">{{ $locale === 'bn' ? 'ব্যাগ, জুয়েলারি ও শাল' : 'Bags, Jewelry & Shawls' }}</p>
            </div>
        </div>
    </div>
</section>

<!-- Database & Architectural Health Badge (Phase 1 Transparency) -->
<section class="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="p-6 bg-white border border-[#E8E4DC] shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 bg-[#202020] text-[#D6C6AA] flex items-center justify-center font-bold text-xl rounded">
                ✓
            </div>
            <div>
                <h4 class="text-sm font-bold text-[#202020]">
                    {{ $locale === 'bn' ? 'ফেজ ১ ফাউন্ডেশন সফলভাবে সম্পন্ন ও পরিচালিত' : 'Phase 1 Architecture Live & Verified' }}
                </h4>
                <p class="text-xs text-[#737373] mt-0.5">
                    Laravel 11.57 • MySQL 10.11 (shoily_zoon) • Blade Layouts • Tailwind v4 Design Tokens • Multi-Currency Exchange Engine • Bilingual Architecture
                </p>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <a href="{{ route('admin.dashboard') }}" class="px-5 py-2.5 bg-[#202020] text-white text-xs font-semibold uppercase tracking-wider hover:bg-[#333333] transition-colors">
                {{ __('admin.dashboard') }}
            </a>
        </div>
    </div>
</section>
@endsection
