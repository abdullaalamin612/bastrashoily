@php
    $settingsService = app(\App\Services\SettingsService::class);
    $currencyService = app(\App\Services\CurrencyService::class);
    $brandName = $settingsService->get('brand_name', 'Shoily Zoon');
    $brandTagline = app()->getLocale() === 'bn' 
        ? $settingsService->get('brand_tagline_bn', 'শৈলী ও ঐতিহ্যের অনন্য সমাহার') 
        : $settingsService->get('brand_tagline_en', 'Elegance in Every Thread');
    $currentCurrency = $currencyService->findByCode(session('currency', 'BDT')) ?? $currencyService->getDefaultCurrency();
@endphp
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ $title ?? $brandName }} — {{ $brandTagline }}</title>
    <meta name="description" content="{{ $metaDescription ?? __('messages.brand_tagline') }}">

    <!-- Google Fonts: Hind Siliguri (Bengali) & Playfair Display / Inter (English) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Tailwind & Livewire Styles -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#202020',
                        secondary: '#D6C6AA',
                        background: '#F7F5F0',
                        surface: '#FFFFFF',
                        text: '#292929',
                        accent: '#C4A482',
                        borderBase: '#E8E4DC',
                    },
                    fontFamily: {
                        bengali: ['"Hind Siliguri"', 'sans-serif'],
                        serif: ['"Playfair Display"', 'Georgia', 'serif'],
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        :root {
            --color-primary: #202020;
            --color-secondary: #D6C6AA;
            --color-background: #F7F5F0;
            --color-surface: #FFFFFF;
            --color-text: #292929;
            --color-border: #E8E4DC;
        }
        body {
            background-color: #F7F5F0;
            color: #292929;
            font-family: 'Hind Siliguri', 'Plus Jakarta Sans', sans-serif;
        }
    </style>
    @livewireStyles
    @stack('styles')
</head>
<body class="min-h-screen flex flex-col bg-[#F7F5F0] text-[#292929] selection:bg-[#D6C6AA] selection:text-[#202020]">

    <!-- Announcement Bar -->
    <div class="bg-[#202020] text-[#D6C6AA] text-xs py-2 px-4 text-center tracking-wider font-medium flex items-center justify-center gap-2">
        <span>✨</span>
        <span>{{ __('messages.free_delivery_badge') }}</span>
        <span>•</span>
        <span class="text-white/80">{{ __('messages.support_helpline') }}</span>
    </div>

    <!-- Header & Navigation -->
    @include('partials.header')

    <!-- Main Content -->
    <main class="flex-grow">
        {{ $slot ?? '' }}
        @yield('content')
    </main>

    <!-- Footer -->
    @include('partials.footer')

    @livewireScripts
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    @stack('scripts')
</body>
</html>
