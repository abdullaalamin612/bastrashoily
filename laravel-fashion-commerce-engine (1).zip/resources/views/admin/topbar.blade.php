@php
    $locale = app()->getLocale();
@endphp

<header class="h-20 bg-white border-b border-[#E2E0D8] px-4 sm:px-6 lg:px-8 flex items-center justify-between sticky top-0 z-30">
    <div class="flex items-center gap-4">
        <!-- Mobile Sidebar Toggle -->
        <button @click="sidebarOpen = true" class="lg:hidden p-2 text-[#202020] hover:text-[#737373]">
            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
        </button>

        <!-- Context Breadcrumb -->
        <div class="flex items-center gap-2 text-xs text-[#737373]">
            <span class="font-medium text-[#202020]">{{ __('admin.admin_panel') }}</span>
            <span>/</span>
            <span>{{ $title ?? __('admin.dashboard') }}</span>
        </div>
    </div>

    <!-- Actions & System Status -->
    <div class="flex items-center space-x-4 text-xs">
        
        <!-- Database Health Indicator -->
        <div class="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-medium rounded">
            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>MySQL 10.11 • {{ __('admin.database_connected') }}</span>
        </div>

        <!-- Language Switcher in Admin -->
        <div class="flex items-center border border-[#E2E0D8] rounded text-[11px] font-semibold overflow-hidden">
            <a href="{{ request()->fullUrlWithQuery(['lang' => 'bn']) }}" 
               class="px-2 py-1 {{ $locale === 'bn' ? 'bg-[#202020] text-white' : 'bg-white text-[#737373] hover:text-[#202020]' }}">
                বাং
            </a>
            <a href="{{ request()->fullUrlWithQuery(['lang' => 'en']) }}" 
               class="px-2 py-1 {{ $locale === 'en' ? 'bg-[#202020] text-white' : 'bg-white text-[#737373] hover:text-[#202020]' }}">
                EN
            </a>
        </div>

        <!-- Admin Profile -->
        <div class="flex items-center gap-2.5 pl-2 border-l border-[#E2E0D8]">
            <div class="w-8 h-8 rounded-full bg-[#202020] text-[#D6C6AA] flex items-center justify-center font-bold text-xs uppercase font-serif">
                SZ
            </div>
            <div class="hidden md:flex flex-col text-left">
                <span class="font-semibold text-[#202020] leading-none">Super Administrator</span>
                <span class="text-[10px] text-[#737373] leading-tight">admin@shoilyzoon.com</span>
            </div>
        </div>
    </div>
</header>
