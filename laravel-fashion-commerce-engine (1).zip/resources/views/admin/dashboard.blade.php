@extends('layouts.admin')

@section('content')
@php
    $settings = app(\App\Services\SettingsService::class);
    $brandName = $settings->get('brand_name', 'Shoily Zoon');
    $brandColors = $settings->get('theme_colors', []);
    $userCount = \App\Models\User::count();
    $currencyCount = \App\Models\Currency::count();
    $roleCount = \App\Models\Role::count();
    $permissionCount = \App\Models\Permission::count();
    $settingCount = \App\Models\Setting::count();
    $locale = app()->getLocale();
@endphp

<div class="space-y-8">
    
    <!-- Top Welcome Banner -->
    <div class="bg-[#202020] text-white p-6 sm:p-8 rounded-none border-b-2 border-[#D6C6AA] shadow-sm">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <div class="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#D6C6AA] font-semibold mb-2">
                    <span>👑</span>
                    <span>{{ __('admin.admin_panel') }} — {{ $brandName }}</span>
                </div>
                <h1 class="text-2xl sm:text-3xl font-serif font-bold text-[#F7F5F0]">
                    {{ $locale === 'bn' ? 'ফ্যাশন ই-কমার্স কন্ট্রোল সেন্টার' : 'Enterprise E-commerce Architecture' }}
                </h1>
                <p class="text-xs text-white/70 mt-1">
                    {{ $locale === 'bn' ? 'ফেজ ১ ফাউন্ডেশন: সিস্টেম পর্যবেক্ষণ, কনফিগারেশন ও ডাটাবেজ স্ট্যাটাস' : 'Phase 1 Foundation: Architectural Blueprint, Database Status & System Health' }}
                </p>
            </div>

            <div class="flex items-center gap-3">
                <a href="{{ route('home') }}" class="px-4 py-2 border border-white/30 text-white text-xs hover:bg-white/10 transition-colors uppercase tracking-wider font-medium">
                    {{ __('messages.home') }}
                </a>
            </div>
        </div>
    </div>

    <!-- Live System & Database KPI Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        <!-- MySQL Database Connected -->
        <div class="bg-white p-5 border border-[#E2E0D8] shadow-sm">
            <div class="flex items-center justify-between">
                <span class="text-xs uppercase tracking-wider text-[#737373] font-medium">{{ __('admin.system_health') }}</span>
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            </div>
            <div class="mt-3">
                <span class="text-xl font-bold font-mono text-[#202020]">MySQL 10.11</span>
                <span class="text-xs text-emerald-600 block mt-1 font-medium">shoily_zoon (Connected)</span>
            </div>
            <div class="mt-3 pt-3 border-t border-[#E2E0D8] text-[11px] text-[#737373]">
                17 Tables • Utf8mb4 • InnoDB
            </div>
        </div>

        <!-- Currencies Configured -->
        <div class="bg-white p-5 border border-[#E2E0D8] shadow-sm">
            <div class="flex items-center justify-between">
                <span class="text-xs uppercase tracking-wider text-[#737373] font-medium">{{ __('messages.currency') }} Engine</span>
                <span class="text-xs text-[#8C7355] font-bold">BDT (Default)</span>
            </div>
            <div class="mt-3">
                <span class="text-2xl font-bold font-serif text-[#202020]">{{ $currencyCount }} Currencies</span>
                <span class="text-xs text-[#737373] block mt-1">BDT, USD, EUR, GBP, AED, SAR</span>
            </div>
            <div class="mt-3 pt-3 border-t border-[#E2E0D8] text-[11px] text-[#737373]">
                DECIMAL(14,6) Financial Precision
            </div>
        </div>

        <!-- Identity & Roles -->
        <div class="bg-white p-5 border border-[#E2E0D8] shadow-sm">
            <div class="flex items-center justify-between">
                <span class="text-xs uppercase tracking-wider text-[#737373] font-medium">Identity & RBAC</span>
                <span class="text-xs text-[#202020] font-bold">{{ $userCount }} Users</span>
            </div>
            <div class="mt-3">
                <span class="text-2xl font-bold font-serif text-[#202020]">{{ $roleCount }} Roles</span>
                <span class="text-xs text-[#737373] block mt-1">{{ $permissionCount }} Granular Permissions</span>
            </div>
            <div class="mt-3 pt-3 border-t border-[#E2E0D8] text-[11px] text-[#737373]">
                Super-Admin, Admin, Manager, Customer
            </div>
        </div>

        <!-- Persistent Settings -->
        <div class="bg-white p-5 border border-[#E2E0D8] shadow-sm">
            <div class="flex items-center justify-between">
                <span class="text-xs uppercase tracking-wider text-[#737373] font-medium">{{ __('admin.settings') }}</span>
                <span class="text-xs text-[#8C7355] font-bold">Persistent</span>
            </div>
            <div class="mt-3">
                <span class="text-2xl font-bold font-serif text-[#202020]">{{ $settingCount }} Business Settings</span>
                <span class="text-xs text-[#737373] block mt-1">Stored in Database Table</span>
            </div>
            <div class="mt-3 pt-3 border-t border-[#E2E0D8] text-[11px] text-[#737373]">
                Brand, Design, Contact, Shipping, SEO
            </div>
        </div>
    </div>

    <!-- Architectural Deep-Dive Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- Left Column: Database Settings Live Inspection -->
        <div class="lg:col-span-7 bg-white border border-[#E2E0D8] p-6 shadow-sm">
            <div class="flex items-center justify-between pb-4 border-b border-[#E2E0D8]">
                <div>
                    <h3 class="font-serif font-bold text-base text-[#202020]">
                        {{ $locale === 'bn' ? 'সক্রিয় সিস্টেম সেটিংস (ডাটাবেজ থেকে লোডকৃত)' : 'Active System Settings (Loaded from Database)' }}
                    </h3>
                    <p class="text-xs text-[#737373] mt-0.5">Settings are persisted in MySQL and cached in memory.</p>
                </div>
                <span class="px-2 py-1 bg-[#F4F4F1] border border-[#E2E0D8] text-[10px] font-mono">
                    SettingsService
                </span>
            </div>

            <div class="divide-y divide-[#E2E0D8] text-xs">
                <div class="py-3 flex items-center justify-between">
                    <span class="font-medium text-[#737373]">Brand Name:</span>
                    <span class="font-bold text-[#202020] font-serif">{{ $settings->get('brand_name') }}</span>
                </div>
                <div class="py-3 flex items-center justify-between">
                    <span class="font-medium text-[#737373]">Bangla Tagline:</span>
                    <span class="text-[#202020]">{{ $settings->get('brand_tagline_bn') }}</span>
                </div>
                <div class="py-3 flex items-center justify-between">
                    <span class="font-medium text-[#737373]">English Tagline:</span>
                    <span class="text-[#202020]">{{ $settings->get('brand_tagline_en') }}</span>
                </div>
                <div class="py-3 flex items-center justify-between">
                    <span class="font-medium text-[#737373]">Headquarters:</span>
                    <span class="text-[#202020] text-right">{{ $settings->get('business_address') }}</span>
                </div>
                <div class="py-3 flex items-center justify-between">
                    <span class="font-medium text-[#737373]">Customer Care:</span>
                    <span class="text-[#202020]">{{ $settings->get('contact_email') }} • {{ $settings->get('contact_phone') }}</span>
                </div>
                <div class="py-3 flex items-center justify-between">
                    <span class="font-medium text-[#737373]">Active Design Palette:</span>
                    <div class="flex items-center gap-1.5">
                        <span class="w-4 h-4 rounded-full border border-black/20" style="background-color: #202020" title="Primary #202020"></span>
                        <span class="w-4 h-4 rounded-full border border-black/20" style="background-color: #D6C6AA" title="Secondary #D6C6AA"></span>
                        <span class="w-4 h-4 rounded-full border border-black/20" style="background-color: #F7F5F0" title="Background #F7F5F0"></span>
                        <span class="w-4 h-4 rounded-full border border-black/20" style="background-color: #FFFFFF" title="Surface #FFFFFF"></span>
                        <span class="w-4 h-4 rounded-full border border-black/20" style="background-color: #292929" title="Text #292929"></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column: Multi-Market & Security Readiness -->
        <div class="lg:col-span-5 space-y-6">
            
            <!-- Multi-Market Ready Box -->
            <div class="bg-white border border-[#E2E0D8] p-6 shadow-sm">
                <h3 class="font-serif font-bold text-base text-[#202020] mb-2">
                    {{ $locale === 'bn' ? 'মাল্টি-মার্কেট ও কারেন্সি টেবিল' : 'Multi-Market & Currency Registry' }}
                </h3>
                <p class="text-xs text-[#737373] mb-4">
                    Exchange rates relative to base Bangladeshi Taka (BDT ৳):
                </p>

                <div class="space-y-2">
                    @foreach(\App\Models\Currency::all() as $curr)
                        <div class="flex items-center justify-between p-2.5 bg-[#F4F4F1] border border-[#E2E0D8] text-xs">
                            <div class="flex items-center gap-2">
                                <span class="font-bold text-[#202020]">{{ $curr->code }}</span>
                                <span class="text-[#737373]">({{ $curr->name }})</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="font-mono text-[11px] text-[#737373]">Rate: {{ $curr->exchange_rate }}</span>
                                <span class="font-serif font-bold text-sm text-[#202020]">{{ $curr->symbol }}</span>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <!-- Phase 2 Roadmap Box -->
            <div class="bg-[#202020] text-white p-6 shadow-sm">
                <span class="text-[10px] uppercase tracking-widest text-[#D6C6AA] font-bold block mb-1">
                    Architectural Roadmap
                </span>
                <h4 class="font-serif font-bold text-base text-white mb-2">
                    Phase 2 Next Steps
                </h4>
                <ul class="text-xs text-white/70 space-y-2">
                    <li class="flex items-start gap-2">
                        <span class="text-[#D6C6AA]">1.</span>
                        <span>Product catalog schema (categories, attributes, variant SKUs, size charts)</span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span class="text-[#D6C6AA]">2.</span>
                        <span>Shopping cart & session-backed multi-currency checkout</span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span class="text-[#D6C6AA]">3.</span>
                        <span>Courier APIs (Steadfast, Pathao, RedX) and Payment Gateway integrations</span>
                    </li>
                </ul>
            </div>

        </div>

    </div>

</div>
@endsection
