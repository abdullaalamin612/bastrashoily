<?php
    $settings = app(\App\Services\SettingsService::class);
    $currencies = app(\App\Services\CurrencyService::class)->getActiveCurrencies();
    $currentCurrency = session('currency', 'BDT');
    $currentLocale = app()->getLocale();
    $brandName = $settings->get('brand_name', 'Shoily Zoon');
?>

<header x-data="{ mobileMenuOpen: false, searchOpen: false }" class="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#E8E4DC]">
    <!-- Top Utility Bar -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-20">
            
            <!-- Mobile Menu Button -->
            <div class="flex items-center lg:hidden">
                <button @click="mobileMenuOpen = !mobileMenuOpen" type="button" class="p-2 text-[#202020] hover:text-[#D6C6AA] transition-colors" aria-label="Toggle Navigation">
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>

            <!-- Brand Logo -->
            <div class="flex-shrink-0 flex items-center">
                <a href="<?php echo e(route('home')); ?>" class="group flex flex-col items-center">
                    <span class="font-serif text-2xl sm:text-3xl tracking-widest uppercase font-bold text-[#202020] group-hover:text-[#A89269] transition-colors">
                        <?php echo e($brandName); ?>

                    </span>
                    <span class="text-[9px] uppercase tracking-[0.3em] text-[#737373] -mt-1 font-sans">
                        <?php echo e($currentLocale === 'bn' ? 'শৈলী ও ঐতিহ্য' : 'Luxury Fashion'); ?>

                    </span>
                </a>
            </div>

            <!-- Desktop Search Bar -->
            <div class="hidden md:flex flex-1 max-w-md mx-8">
                <div class="relative w-full">
                    <input type="text" 
                           placeholder="<?php echo e(__('messages.search_placeholder')); ?>" 
                           class="w-full bg-[#F7F5F0] border border-[#E8E4DC] px-4 py-2 pl-10 text-xs sm:text-sm text-[#202020] placeholder-[#737373] focus:outline-none focus:border-[#202020] transition-colors">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg class="h-4 w-4 text-[#737373]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                    </div>
                </div>
            </div>

            <!-- User Utilities & Selectors -->
            <div class="flex items-center space-x-3 sm:space-x-5 text-sm">
                
                <!-- Currency Selector -->
                <div class="relative" x-data="{ open: false }">
                    <button @click="open = !open" type="button" class="inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-[#202020] hover:text-[#A89269] px-2 py-1 border border-[#E8E4DC] bg-[#F7F5F0] transition-colors">
                        <span><?php echo e($currentCurrency); ?></span>
                        <svg class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div x-show="open" @click.away="open = false" x-cloak class="absolute right-0 mt-2 w-32 bg-white border border-[#E8E4DC] shadow-lg py-1 z-50 text-xs">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(request()->fullUrlWithQuery(['currency' => $curr->code])); ?>" 
                               class="flex items-center justify-between px-3 py-1.5 hover:bg-[#F7F5F0] <?php echo e($currentCurrency === $curr->code ? 'font-bold text-[#202020] bg-[#F7F5F0]' : 'text-[#737373]'); ?>">
                                <span><?php echo e($curr->code); ?></span>
                                <span class="font-serif"><?php echo e($curr->symbol); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <!-- Language Selector -->
                <div class="flex items-center border border-[#E8E4DC] text-xs font-semibold overflow-hidden">
                    <a href="<?php echo e(request()->fullUrlWithQuery(['lang' => 'bn'])); ?>" 
                       class="px-2.5 py-1 transition-colors <?php echo e($currentLocale === 'bn' ? 'bg-[#202020] text-white' : 'bg-white text-[#737373] hover:text-[#202020]'); ?>">
                        বাং
                    </a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['lang' => 'en'])); ?>" 
                       class="px-2.5 py-1 transition-colors <?php echo e($currentLocale === 'en' ? 'bg-[#202020] text-white' : 'bg-white text-[#737373] hover:text-[#202020]'); ?>">
                        EN
                    </a>
                </div>

                <!-- Cart Icon -->
                <a href="#cart" class="relative p-2 text-[#202020] hover:text-[#A89269] transition-colors" title="<?php echo e(__('messages.cart')); ?>">
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                    </svg>
                    <span class="absolute top-1 right-1 bg-[#202020] text-[#D6C6AA] text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">0</span>
                </a>

                <!-- Admin Link -->
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="hidden sm:inline-flex items-center gap-1.5 text-xs tracking-wider uppercase px-3 py-1.5 border border-[#202020] text-[#202020] hover:bg-[#202020] hover:text-white transition-all font-medium">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/>
                    </svg>
                    <span><?php echo e(__('admin.admin_panel')); ?></span>
                </a>
            </div>
        </div>

        <!-- Desktop Navigation Categories -->
        <nav class="hidden lg:flex items-center justify-center space-x-10 py-3 border-t border-[#E8E4DC] text-xs font-medium uppercase tracking-[0.15em] text-[#292929]">
            <a href="<?php echo e(route('home')); ?>" class="hover:text-[#A89269] transition-colors border-b-2 border-transparent hover:border-[#202020] pb-1"><?php echo e(__('messages.home')); ?></a>
            <a href="#women" class="hover:text-[#A89269] transition-colors border-b-2 border-transparent hover:border-[#202020] pb-1"><?php echo e(__('messages.women')); ?></a>
            <a href="#men" class="hover:text-[#A89269] transition-colors border-b-2 border-transparent hover:border-[#202020] pb-1"><?php echo e(__('messages.men')); ?></a>
            <a href="#kids" class="hover:text-[#A89269] transition-colors border-b-2 border-transparent hover:border-[#202020] pb-1"><?php echo e(__('messages.kids')); ?></a>
            <a href="#accessories" class="hover:text-[#A89269] transition-colors border-b-2 border-transparent hover:border-[#202020] pb-1"><?php echo e(__('messages.accessories')); ?></a>
            <a href="#new" class="text-[#8C7355] font-semibold hover:text-[#202020] transition-colors border-b-2 border-transparent hover:border-[#8C7355] pb-1"><?php echo e(__('messages.new_arrivals')); ?></a>
        </nav>
    </div>

    <!-- Mobile Drawer Navigation -->
    <div x-show="mobileMenuOpen" x-cloak class="lg:hidden border-t border-[#E8E4DC] bg-white px-4 pt-3 pb-6 space-y-3">
        <a href="<?php echo e(route('home')); ?>" class="block text-sm font-medium text-[#202020] py-2"><?php echo e(__('messages.home')); ?></a>
        <a href="#women" class="block text-sm font-medium text-[#202020] py-2"><?php echo e(__('messages.women')); ?></a>
        <a href="#men" class="block text-sm font-medium text-[#202020] py-2"><?php echo e(__('messages.men')); ?></a>
        <a href="#kids" class="block text-sm font-medium text-[#202020] py-2"><?php echo e(__('messages.kids')); ?></a>
        <a href="#accessories" class="block text-sm font-medium text-[#202020] py-2"><?php echo e(__('messages.accessories')); ?></a>
        <a href="#new" class="block text-sm font-medium text-[#8C7355] py-2"><?php echo e(__('messages.new_arrivals')); ?></a>
        <div class="pt-2 border-t border-[#E8E4DC]">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="block text-center w-full py-2 border border-[#202020] text-xs uppercase tracking-wider font-semibold">
                <?php echo e(__('admin.admin_panel')); ?>

            </a>
        </div>
    </div>
</header>
<?php /**PATH /app/applet/resources/views/partials/header.blade.php ENDPATH**/ ?>