<?php
    $settings = app(\App\Services\SettingsService::class);
    $brandName = $settings->get('brand_name', 'Shoily Zoon');
    $currentRoute = request()->route()?->getName();
?>

<!-- Mobile Backdrop -->
<div x-show="sidebarOpen" @click="sidebarOpen = false" x-cloak class="fixed inset-0 z-40 bg-black/60 lg:hidden"></div>

<!-- Sidebar Container -->
<aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'" 
       class="fixed inset-y-0 left-0 z-50 w-64 bg-[#1A1A1A] text-[#F7F5F0] transition-transform duration-300 ease-in-out lg:translate-x-0 flex flex-col border-r border-white/10">
    
    <!-- Sidebar Header -->
    <div class="h-20 flex items-center justify-between px-6 border-b border-white/10">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex flex-col">
            <span class="font-serif text-lg tracking-widest uppercase font-bold text-white"><?php echo e($brandName); ?></span>
            <span class="text-[9px] uppercase tracking-[0.25em] text-[#D6C6AA]">Administration</span>
        </a>
        <button @click="sidebarOpen = false" class="lg:hidden text-white/60 hover:text-white">
            <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
    </div>

    <!-- Navigation Menu -->
    <nav class="flex-1 overflow-y-auto px-4 py-6 space-y-1 text-xs">
        
        <!-- Core -->
        <div class="px-3 pb-2 text-[10px] font-semibold tracking-wider text-white/40 uppercase">Core Operations</div>
        
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center gap-3 px-3 py-2.5 rounded text-white bg-white/10 font-medium transition-colors">
            <svg class="w-4 h-4 text-[#D6C6AA]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
            </svg>
            <span><?php echo e(__('admin.dashboard')); ?></span>
        </a>

        <!-- Catalog Domain -->
        <div class="pt-5 px-3 pb-2 text-[10px] font-semibold tracking-wider text-white/40 uppercase">Catalog Domain</div>
        
        <a href="#admin-products" class="flex items-center gap-3 px-3 py-2 rounded text-white/70 hover:text-white hover:bg-white/5 transition-colors">
            <svg class="w-4 h-4 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
            <span><?php echo e(__('admin.products')); ?></span>
        </a>

        <a href="#admin-categories" class="flex items-center gap-3 px-3 py-2 rounded text-white/70 hover:text-white hover:bg-white/5 transition-colors">
            <svg class="w-4 h-4 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
            </svg>
            <span><?php echo e(__('admin.categories')); ?></span>
        </a>

        <a href="#admin-brands" class="flex items-center gap-3 px-3 py-2 rounded text-white/70 hover:text-white hover:bg-white/5 transition-colors">
            <svg class="w-4 h-4 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
            <span><?php echo e(__('admin.brands')); ?></span>
        </a>

        <!-- Orders & Fulfillment -->
        <div class="pt-5 px-3 pb-2 text-[10px] font-semibold tracking-wider text-white/40 uppercase">Sales & Fulfillment</div>

        <a href="#admin-orders" class="flex items-center gap-3 px-3 py-2 rounded text-white/70 hover:text-white hover:bg-white/5 transition-colors">
            <svg class="w-4 h-4 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            <span><?php echo e(__('admin.orders')); ?></span>
        </a>

        <a href="#admin-shipping" class="flex items-center gap-3 px-3 py-2 rounded text-white/70 hover:text-white hover:bg-white/5 transition-colors">
            <svg class="w-4 h-4 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
            </svg>
            <span><?php echo e(__('admin.shipping')); ?></span>
        </a>

        <a href="#admin-inventory" class="flex items-center gap-3 px-3 py-2 rounded text-white/70 hover:text-white hover:bg-white/5 transition-colors">
            <svg class="w-4 h-4 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
            <span><?php echo e(__('admin.inventory')); ?></span>
        </a>

        <!-- System & Governance -->
        <div class="pt-5 px-3 pb-2 text-[10px] font-semibold tracking-wider text-white/40 uppercase">System & Governance</div>

        <a href="#admin-settings" class="flex items-center gap-3 px-3 py-2 rounded text-white/70 hover:text-white hover:bg-white/5 transition-colors">
            <svg class="w-4 h-4 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span><?php echo e(__('admin.settings')); ?></span>
        </a>

        <a href="#admin-logs" class="flex items-center gap-3 px-3 py-2 rounded text-white/70 hover:text-white hover:bg-white/5 transition-colors">
            <svg class="w-4 h-4 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <span><?php echo e(__('admin.audit_logs')); ?></span>
        </a>
    </nav>

    <!-- Sidebar Footer -->
    <div class="p-4 border-t border-white/10 text-[11px] text-white/50 flex items-center justify-between">
        <a href="<?php echo e(route('home')); ?>" class="hover:text-white flex items-center gap-1.5 transition-colors">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            <span>View Storefront</span>
        </a>
        <span class="text-[10px] text-[#D6C6AA]">v1.0 (Phase 1)</span>
    </div>
</aside>
<?php /**PATH /app/applet/resources/views/admin/sidebar.blade.php ENDPATH**/ ?>