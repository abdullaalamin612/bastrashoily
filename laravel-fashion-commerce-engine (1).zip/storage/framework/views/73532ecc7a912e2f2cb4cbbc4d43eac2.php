<?php
    $settings = app(\App\Services\SettingsService::class);
    $brandName = $settings->get('brand_name', 'Shoily Zoon');
    $brandAddress = $settings->get('business_address', 'House #12, Road #4, Dhanmondi, Dhaka-1205, Bangladesh');
    $contactEmail = $settings->get('contact_email', 'contact@shoilyzoon.com');
    $contactPhone = $settings->get('contact_phone', '+880 1700-000000');
    $locale = app()->getLocale();
?>

<footer class="bg-[#202020] text-[#F7F5F0] pt-16 pb-12 border-t border-[#333333]">
    <!-- Trust Badges -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-white/10">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div class="p-4 border border-white/5 bg-white/[0.02]">
                <div class="text-2xl mb-2 text-[#D6C6AA]">🚚</div>
                <h4 class="text-xs uppercase font-semibold tracking-wider text-white"><?php echo e(__('messages.fast_delivery')); ?></h4>
                <p class="text-[11px] text-white/60 mt-1"><?php echo e($locale === 'bn' ? 'সারা দেশে ২-৪ দিনে ডেলিভারি' : 'Nationwide 2-4 Days'); ?></p>
            </div>
            <div class="p-4 border border-white/5 bg-white/[0.02]">
                <div class="text-2xl mb-2 text-[#D6C6AA]">💵</div>
                <h4 class="text-xs uppercase font-semibold tracking-wider text-white"><?php echo e(__('messages.cash_on_delivery')); ?></h4>
                <p class="text-[11px] text-white/60 mt-1"><?php echo e($locale === 'bn' ? 'পণ্য হাতে পেয়ে মূল্য পরিশোধ' : 'Pay after receiving package'); ?></p>
            </div>
            <div class="p-4 border border-white/5 bg-white/[0.02]">
                <div class="text-2xl mb-2 text-[#D6C6AA]">🔄</div>
                <h4 class="text-xs uppercase font-semibold tracking-wider text-white"><?php echo e(__('messages.easy_return')); ?></h4>
                <p class="text-[11px] text-white/60 mt-1"><?php echo e($locale === 'bn' ? '৭ দিনের মধ্যে সহজ রিটার্ন সুবিধা' : '7 Days Hassel-free Exchange'); ?></p>
            </div>
            <div class="p-4 border border-white/5 bg-white/[0.02]">
                <div class="text-2xl mb-2 text-[#D6C6AA]">🔒</div>
                <h4 class="text-xs uppercase font-semibold tracking-wider text-white"><?php echo e(__('messages.secure_payment')); ?></h4>
                <p class="text-[11px] text-white/60 mt-1"><?php echo e($locale === 'bn' ? 'bKash, Nagad ও আন্তর্জাতিক কার্ড' : 'bKash, Nagad & Cards'); ?></p>
            </div>
        </div>
    </div>

    <!-- Main Footer Columns -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-4 gap-10">
        <!-- Brand Info -->
        <div class="space-y-4">
            <span class="font-serif text-2xl tracking-widest uppercase font-bold text-white block">
                <?php echo e($brandName); ?>

            </span>
            <p class="text-xs leading-relaxed text-white/70">
                <?php echo e($locale === 'bn' 
                    ? 'বাংলাদেশের ঐতিহ্যবাহী কারুশিল্প ও আধুনিক বৈশ্বিক ফ্যাশনের সমন্বয়ে তৈরি প্রিমিয়াম পোশাক।' 
                    : 'A curated fashion collective merging timeless heritage tailoring with contemporary luxury silhouettes.'); ?>

            </p>
            <div class="text-xs text-white/60 space-y-1">
                <p><?php echo e($brandAddress); ?></p>
                <p><?php echo e($contactEmail); ?> • <?php echo e($contactPhone); ?></p>
            </div>
        </div>

        <!-- Collections -->
        <div>
            <h5 class="text-xs uppercase tracking-widest text-[#D6C6AA] font-semibold mb-4"><?php echo e($locale === 'bn' ? 'কালেকশন' : 'Collections'); ?></h5>
            <ul class="text-xs space-y-2.5 text-white/70">
                <li><a href="#women" class="hover:text-white transition-colors"><?php echo e(__('messages.women')); ?> (শাড়ি, কুর্তি, সালোয়ার)</a></li>
                <li><a href="#men" class="hover:text-white transition-colors"><?php echo e(__('messages.men')); ?> (প্রিমিয়াম পাঞ্জাবি, কাবলি)</a></li>
                <li><a href="#kids" class="hover:text-white transition-colors"><?php echo e(__('messages.kids')); ?> (উৎসব কালেকশন)</a></li>
                <li><a href="#accessories" class="hover:text-white transition-colors"><?php echo e(__('messages.accessories')); ?></a></li>
                <li><a href="#new" class="text-[#D6C6AA] hover:text-white transition-colors"><?php echo e(__('messages.new_arrivals')); ?></a></li>
            </ul>
        </div>

        <!-- Customer Support -->
        <div>
            <h5 class="text-xs uppercase tracking-widest text-[#D6C6AA] font-semibold mb-4"><?php echo e($locale === 'bn' ? 'গ্রাহক সেবা' : 'Customer Service'); ?></h5>
            <ul class="text-xs space-y-2.5 text-white/70">
                <li><a href="#track" class="hover:text-white transition-colors"><?php echo e($locale === 'bn' ? 'অর্ডার ট্র্যাক করুন' : 'Track Order'); ?></a></li>
                <li><a href="#shipping" class="hover:text-white transition-colors"><?php echo e($locale === 'bn' ? 'ডেলিভারি ও শিপিং নীতি' : 'Shipping Policy'); ?></a></li>
                <li><a href="#returns" class="hover:text-white transition-colors"><?php echo e($locale === 'bn' ? 'রিটার্ন ও রিফান্ড নীতি' : 'Return Policy'); ?></a></li>
                <li><a href="#size-guide" class="hover:text-white transition-colors"><?php echo e($locale === 'bn' ? 'সাইজ চার্ট গাইড' : 'Size Chart Guide'); ?></a></li>
                <li><a href="#faq" class="hover:text-white transition-colors"><?php echo e($locale === 'bn' ? 'সাধারণ প্রশ্নাবলী (FAQ)' : 'FAQs'); ?></a></li>
            </ul>
        </div>

        <!-- Multi-market & Payment Methods -->
        <div>
            <h5 class="text-xs uppercase tracking-widest text-[#D6C6AA] font-semibold mb-4"><?php echo e($locale === 'bn' ? 'পেমেন্ট ও আন্তর্জাতিক' : 'Payments & Delivery'); ?></h5>
            <p class="text-xs text-white/70 mb-3">
                <?php echo e($locale === 'bn' ? 'বিশ্বস্ত পেমেন্ট পার্টনারদের মাধ্যমে নিরাপদ লেনদেন:' : 'Secure transactions backed by global payment standards:'); ?>

            </p>
            <div class="flex flex-wrap gap-2 text-[10px] text-white/80 font-mono">
                <span class="px-2 py-1 bg-white/10 border border-white/10">bKash</span>
                <span class="px-2 py-1 bg-white/10 border border-white/10">Nagad</span>
                <span class="px-2 py-1 bg-white/10 border border-white/10">Visa</span>
                <span class="px-2 py-1 bg-white/10 border border-white/10">Mastercard</span>
                <span class="px-2 py-1 bg-white/10 border border-white/10">COD</span>
            </div>
            <div class="mt-4 text-[11px] text-white/50">
                <span><?php echo e($locale === 'bn' ? 'বৈশ্বিক বাজার: বাংলাদেশ • ইউএসএ • ইউরোপ • মধ্যপ্রাচ্য' : 'Markets: Bangladesh • USA • Europe • Middle East'); ?></span>
            </div>
        </div>
    </div>

    <!-- Copyright Bar -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-white/50 gap-4">
        <p><?php echo e(__('messages.copyright', ['year' => date('Y')])); ?></p>
        <div class="flex space-x-6 text-[11px]">
            <a href="#privacy" class="hover:text-white transition-colors"><?php echo e($locale === 'bn' ? 'গোপনীয়তা নীতি' : 'Privacy Policy'); ?></a>
            <a href="#terms" class="hover:text-white transition-colors"><?php echo e($locale === 'bn' ? 'শর্তাবলী' : 'Terms of Service'); ?></a>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="hover:text-[#D6C6AA] transition-colors"><?php echo e(__('admin.admin_panel')); ?></a>
        </div>
    </div>
</footer>
<?php /**PATH /app/applet/resources/views/partials/footer.blade.php ENDPATH**/ ?>