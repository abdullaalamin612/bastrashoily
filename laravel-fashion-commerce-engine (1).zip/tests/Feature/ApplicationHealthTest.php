<?php

namespace Tests\Feature;

use Tests\TestCase;

class ApplicationHealthTest extends TestCase
{
    /**
     * Test Laravel standard health check route.
     */
    public function test_application_up_health_check_responds(): void
    {
        $response = $this->get('/up');
        $response->assertStatus(200);
    }

    /**
     * Test JSON API health endpoint with database status and runtime metadata.
     */
    public function test_api_health_endpoint_returns_json_metadata(): void
    {
        $response = $this->getJson('/api/health');

        $response->assertStatus(200)
            ->assertJson([
                'status' => 'ok',
                'application' => config('app.name'),
                'default_currency' => 'BDT',
                'default_locale' => 'bn',
            ]);
    }
}
