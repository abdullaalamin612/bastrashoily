<?php

namespace Tests\Feature;

use Tests\TestCase;

class StorefrontRouteTest extends TestCase
{
    /**
     * Test storefront home page route returns 200 and renders brand layout.
     */
    public function test_storefront_homepage_renders_successfully(): void
    {
        $response = $this->get('/');

        $brandName = \App\Models\Setting::get('brand_name', config('app.name'));

        $response->assertStatus(200)
            ->assertSee($brandName);
    }

    /**
     * Test switching locale to English updates session and renders English copy.
     */
    public function test_switching_language_to_english(): void
    {
        $response = $this->get('/?lang=en');

        $response->assertStatus(200)
            ->assertSessionHas('locale', 'en')
            ->assertSee('Elegance in Every Thread');
    }

    /**
     * Test switching currency to USD updates session and displays USD amounts.
     */
    public function test_switching_currency_to_usd(): void
    {
        $response = $this->get('/?currency=USD');

        $response->assertStatus(200)
            ->assertSessionHas('currency', 'USD')
            ->assertSee('USD');
    }

    /**
     * Test customer layout contains essential navigation and trust elements.
     */
    public function test_customer_layout_contains_navigation_and_footer(): void
    {
        $response = $this->get('/');

        $response->assertStatus(200)
            ->assertSee('হোম')
            ->assertSee('পুরুষ')
            ->assertSee('নারী')
            ->assertSee('অ্যাক্সেসরিজ')
            ->assertSee('ক্যাশ অন ডেলিভারি');
    }
}
