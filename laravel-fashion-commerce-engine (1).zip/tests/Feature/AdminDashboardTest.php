<?php

namespace Tests\Feature;

use App\Models\Role;
use App\Models\User;
use Tests\TestCase;

class AdminDashboardTest extends TestCase
{
    /**
     * Test admin dashboard renders successfully with KPIs and live database indicator.
     */
    public function test_admin_dashboard_renders_successfully(): void
    {
        $response = $this->get('/admin');

        $brandName = \App\Models\Setting::get('brand_name', config('app.name'));

        $response->assertStatus(200)
            ->assertSee($brandName)
            ->assertSee('Administration')
            ->assertSee('MySQL 10.11')
            ->assertSee('BDT, USD, EUR, GBP, AED, SAR');
    }

    /**
     * Test role-based authorization check.
     */
    public function test_user_without_admin_role_cannot_access_protected_areas(): void
    {
        $customerRole = Role::where('slug', 'customer')->first();
        $user = User::factory()->make();

        // Guest or customer user should be restricted
        $this->assertFalse($user->isAdmin());
    }

    /**
     * Test administrator user has admin privileges.
     */
    public function test_admin_user_has_admin_privileges(): void
    {
        $adminUser = User::where('email', 'admin@shoilyzoon.com')->first();

        $this->assertNotNull($adminUser);
        $this->assertTrue($adminUser->isAdmin());
        $this->assertTrue($adminUser->hasRole('super-admin'));
    }
}
