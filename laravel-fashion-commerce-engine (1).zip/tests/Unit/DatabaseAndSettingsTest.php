<?php

namespace Tests\Unit;

use App\Models\Currency;
use App\Models\Setting;
use App\Services\CurrencyService;
use App\Services\SettingsService;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class DatabaseAndSettingsTest extends TestCase
{
    /**
     * Test active database connection to MySQL / MariaDB.
     */
    public function test_database_connection_is_functional(): void
    {
        $pdo = DB::connection()->getPdo();
        $this->assertNotNull($pdo);

        $tables = DB::select('SHOW TABLES');
        $this->assertNotEmpty($tables);
    }

    /**
     * Test persistent SettingsService retrieval and casting.
     */
    public function test_settings_service_loads_persisted_values(): void
    {
        $service = app(SettingsService::class);

        $brandName = $service->get('brand_name');
        $this->assertEquals('Shoily Zoon', $brandName);

        $themeColors = $service->get('theme_colors');
        $this->assertIsArray($themeColors);
        $this->assertEquals('#202020', $themeColors['primary']);
        $this->assertEquals('#D6C6AA', $themeColors['secondary']);
    }

    /**
     * Test CurrencyService resolves BDT default and converts to USD accurately.
     */
    public function test_currency_service_converts_amounts_properly(): void
    {
        $service = app(CurrencyService::class);

        $defaultCurrency = $service->getDefaultCurrency();
        $this->assertEquals('BDT', $defaultCurrency->code);
        $this->assertEquals('৳', $defaultCurrency->symbol);

        // Test conversion: 12000 BDT at rate 0.008333 is ~100 USD
        $converted = $service->convertFromBase(12000, 'USD');
        $this->assertGreaterThan(90.0, $converted);
        $this->assertLessThan(110.0, $converted);

        $formatted = $service->format(5000, 'BDT');
        $this->assertStringContainsString('৳', $formatted);
    }
}
