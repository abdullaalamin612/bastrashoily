<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. Color Management
        Schema::create('product_colors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->string('name_bn', 100);
            $table->string('name_en', 100);
            $table->string('hex_code', 20)->default('#000000');
            $table->string('swatch_image')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // Color-specific image gallery (Black shows Black only; White shows White only)
        Schema::create('product_color_images', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_color_id')->constrained('product_colors')->cascadeOnDelete();
            $table->string('image_path');
            $table->string('thumbnail_path')->nullable();
            $table->string('alt_text')->nullable();
            $table->integer('sort_order')->default(0)->index();
            $table->boolean('is_primary')->default(false);
            $table->timestamps();
        });

        // 2. Size Management
        Schema::create('product_sizes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->string('size_code', 30); // S, M, L, XL, XXL, 40, Free Size
            $table->string('size_label', 100)->nullable(); // e.g. 40" Chest / Semi-Fit
            $table->integer('sort_order')->default(0);
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
        });

        // 3. Variant Matrix (Color × Size)
        Schema::create('product_variants', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->foreignId('product_color_id')->nullable()->constrained('product_colors')->cascadeOnDelete();
            $table->foreignId('product_size_id')->nullable()->constrained('product_sizes')->cascadeOnDelete();
            
            $table->string('sku', 100)->unique()->index();
            $table->decimal('purchase_cost', 12, 2)->default(0.00);
            $table->decimal('regular_price', 12, 2);
            $table->decimal('sale_price', 12, 2)->nullable()->index();
            $table->string('variant_image')->nullable();
            $table->boolean('is_active')->default(true)->index();
            
            $table->timestamps();
            $table->softDeletes();

            $table->unique(['product_id', 'product_color_id', 'product_size_id'], 'prod_color_size_unique');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('product_variants');
        Schema::dropIfExists('product_sizes');
        Schema::dropIfExists('product_color_images');
        Schema::dropIfExists('product_colors');
    }
};
