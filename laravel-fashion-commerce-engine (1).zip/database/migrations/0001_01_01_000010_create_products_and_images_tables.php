<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name_bn', 255);
            $table->string('name_en', 255);
            $table->string('slug', 255)->unique();
            $table->string('sku', 100)->unique()->index();
            $table->foreignId('category_id')->constrained('categories')->restrictOnDelete();
            $table->foreignId('subcategory_id')->nullable()->constrained('categories')->nullOnDelete();
            $table->foreignId('brand_id')->nullable()->constrained('brands')->nullOnDelete();
            $table->foreignId('size_chart_id')->nullable()->constrained('size_charts')->nullOnDelete();
            
            // Descriptions
            $table->text('short_description_bn')->nullable();
            $table->text('short_description_en')->nullable();
            $table->longText('full_description_bn')->nullable();
            $table->longText('full_description_en')->nullable();
            
            // Financials (DECIMAL for financial precision, never float)
            $table->decimal('purchase_cost', 12, 2)->default(0.00);
            $table->decimal('regular_price', 12, 2);
            $table->decimal('sale_price', 12, 2)->nullable()->index();
            $table->decimal('discount_amount', 12, 2)->default(0.00);
            $table->string('discount_type', 20)->default('fixed'); // fixed or percentage

            // Fashion Attributes
            $table->string('material', 100)->nullable();
            $table->string('pattern', 100)->nullable();
            $table->string('occasion', 100)->nullable();
            $table->enum('gender', ['men', 'women', 'kids', 'unisex'])->default('unisex')->index();
            $table->unsignedInteger('weight_grams')->default(0);

            // Merchandising & Status Flags
            $table->boolean('is_featured')->default(false)->index();
            $table->boolean('is_new_arrival')->default(false)->index();
            $table->boolean('is_bestseller')->default(false)->index();
            $table->enum('status', ['draft', 'published', 'archived'])->default('published')->index();

            // SEO Metadata
            $table->string('seo_title')->nullable();
            $table->text('seo_description')->nullable();

            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('product_images', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->string('image_path');
            $table->string('thumbnail_path')->nullable();
            $table->string('alt_text')->nullable();
            $table->integer('sort_order')->default(0)->index();
            $table->boolean('is_primary')->default(false)->index();
            $table->timestamps();
        });

        Schema::create('tags', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->string('slug', 100)->unique();
            $table->timestamps();
        });

        Schema::create('product_tag', function (Blueprint $table) {
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->foreignId('tag_id')->constrained('tags')->cascadeOnDelete();
            $table->primary(['product_id', 'tag_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('product_tag');
        Schema::dropIfExists('tags');
        Schema::dropIfExists('product_images');
        Schema::dropIfExists('products');
    }
};
