<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('addresses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->enum('type', ['shipping', 'billing'])->default('shipping');
            $table->boolean('is_default')->default(false)->index();
            $table->string('recipient_name', 150);
            $table->string('phone', 25);
            $table->string('alternative_phone', 25)->nullable();
            $table->string('email', 150)->nullable();
            $table->char('country_code', 2)->default('BD')->index();
            $table->string('division', 100)->nullable(); // BD: Dhaka, Chittagong, Sylhet, etc.
            $table->string('district', 100)->nullable(); // BD: Dhaka, Gazipur, Narayanganj, etc.
            $table->string('upazila', 100)->nullable();  // BD: Dhanmondi, Gulshan, Mirpur, etc.
            $table->text('street_address');
            $table->string('postal_code', 20)->nullable();
            $table->string('landmark')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('addresses');
    }
};
