<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('group', 50)->index(); // general, brand, localization, shipping, payment, seo
            $table->string('key', 100)->unique();
            $table->longText('value')->nullable();
            $table->enum('type', ['string', 'boolean', 'integer', 'float', 'json', 'array'])->default('string');
            $table->boolean('is_public')->default(false)->index();
            $table->string('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('settings');
    }
};
