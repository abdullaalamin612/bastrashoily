<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Current Stock snapshot per variant
        Schema::create('inventory_stocks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->foreignId('product_variant_id')->unique()->constrained('product_variants')->cascadeOnDelete();
            
            $table->integer('physical_quantity')->default(0);
            $table->integer('reserved_quantity')->default(0);
            $table->integer('available_quantity')->default(0); // Available = physical - reserved
            $table->unsignedInteger('low_stock_threshold')->default(5);
            
            $table->timestamps();
        });

        // Immutable Audit Trail of Every Single Stock Change
        Schema::create('stock_movements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('inventory_stock_id')->constrained('inventory_stocks')->cascadeOnDelete();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->foreignId('product_variant_id')->constrained('product_variants')->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete(); // Actor who changed stock
            
            $table->enum('movement_type', [
                'opening_stock',
                'purchase',
                'sale',
                'return_restock',
                'damage',
                'manual_adjustment',
                'cancellation_release',
            ])->index();
            
            $table->integer('quantity'); // Positive for additions, negative for deductions
            $table->integer('balance_before');
            $table->integer('balance_after');
            
            $table->string('reference_type', 100)->nullable(); // e.g. App\Models\Order
            $table->unsignedBigInteger('reference_id')->nullable(); // Order ID, Purchase ID
            
            $table->string('reason')->nullable();
            $table->text('notes')->nullable();
            
            $table->timestamps();
            
            $table->index(['reference_type', 'reference_id']);
        });

        // Formal Batch Stock Adjustments
        Schema::create('stock_adjustments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->string('adjustment_number', 50)->unique();
            $table->string('reason', 150);
            $table->enum('status', ['draft', 'approved'])->default('approved');
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('stock_adjustments');
        Schema::dropIfExists('stock_movements');
        Schema::dropIfExists('inventory_stocks');
    }
};
