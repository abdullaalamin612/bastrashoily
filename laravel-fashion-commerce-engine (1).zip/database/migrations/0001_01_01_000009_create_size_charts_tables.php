<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('size_charts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->nullable()->constrained('categories')->nullOnDelete();
            $table->string('name_bn', 150);
            $table->string('name_en', 150);
            $table->string('code', 50)->unique(); // e.g. 'panjabi-standard', 'tshirt-mens'
            $table->text('description')->nullable();
            $table->json('measurement_columns'); // e.g. ["chest", "length", "shoulder", "sleeve"]
            $table->string('default_unit', 10)->default('inch'); // inch or cm
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('size_chart_rows', function (Blueprint $table) {
            $table->id();
            $table->foreignId('size_chart_id')->constrained('size_charts')->cascadeOnDelete();
            $table->string('size_code', 20); // S, M, L, XL, XXL, 38, 40, Free Size
            $table->string('size_label', 50)->nullable(); // Small (38"), Medium (40")
            $table->json('measurements_inch'); // {"chest": "38-40", "length": "40", "shoulder": "18"}
            $table->json('measurements_cm');   // {"chest": "96-101", "length": "101", "shoulder": "45"}
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('size_chart_rows');
        Schema::dropIfExists('size_charts');
    }
};
