<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_number', 50)->unique()->index();
            $table->foreignId('customer_id')->nullable()->constrained('users')->nullOnDelete();
            
            // Customer contact snapshot
            $table->string('customer_name', 150);
            $table->string('customer_phone', 25)->index();
            $table->string('customer_email', 150)->nullable()->index();
            
            // Complete immutable address snapshots
            $table->json('shipping_address_snapshot');
            $table->json('billing_address_snapshot')->nullable();

            // Financial Calculations (DECIMAL for monetary precision, never float)
            $table->decimal('subtotal', 12, 2);
            $table->decimal('discount_amount', 12, 2)->default(0.00);
            $table->decimal('shipping_cost', 12, 2)->default(0.00);
            $table->decimal('tax_amount', 12, 2)->default(0.00);
            $table->decimal('grand_total', 12, 2)->index();

            // Multi-Currency Snapshot
            $table->char('currency_code', 3)->default('BDT')->index();
            $table->decimal('exchange_rate', 14, 6)->default(1.000000);
            $table->decimal('base_currency_total', 12, 2); // Amount in BDT for uniform financial reporting

            // Fulfillment & Payment Statuses
            $table->enum('order_status', [
                'pending',
                'confirmed',
                'processing',
                'packed',
                'shipped',
                'delivered',
                'cancelled',
                'returned',
                'refunded',
            ])->default('pending')->index();

            $table->string('payment_method', 50)->default('cod')->index(); // cod, bkash, nagad, sslcommerz, card
            $table->enum('payment_status', ['pending', 'paid', 'failed', 'refunded'])->default('pending')->index();
            $table->string('payment_transaction_id', 150)->nullable();

            // Notes & Anti-duplication Idempotency
            $table->text('customer_notes')->nullable();
            $table->text('admin_notes')->nullable();
            $table->string('idempotency_token', 100)->nullable()->unique();
            
            $table->timestamp('confirmed_at')->nullable();
            $table->timestamp('shipped_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->timestamp('cancelled_at')->nullable();

            $table->timestamps();
            $table->softDeletes();
        });

        // Historical Snapshot of each item in the order
        Schema::create('order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->foreignId('product_id')->nullable()->constrained('products')->nullOnDelete();
            $table->foreignId('product_variant_id')->nullable()->constrained('product_variants')->nullOnDelete();

            // Snapshot fields that never change even if products are renamed or prices updated
            $table->string('product_name', 255);
            $table->string('product_sku', 100);
            $table->string('variant_sku', 100);
            $table->string('selected_color', 100)->nullable();
            $table->string('selected_size', 50)->nullable();
            $table->string('product_image')->nullable();

            $table->decimal('purchase_cost', 12, 2)->default(0.00); // Historical COGS snapshot
            $table->decimal('unit_price', 12, 2);
            $table->unsignedInteger('quantity');
            $table->decimal('discount_amount', 12, 2)->default(0.00);
            $table->decimal('line_total', 12, 2);

            $table->timestamps();
        });

        // Audit Trail of every Order Status change
        Schema::create('order_status_histories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete(); // Admin or Customer who caused the change
            $table->string('from_status', 50)->nullable();
            $table->string('to_status', 50);
            $table->text('comment')->nullable();
            $table->boolean('notify_customer')->default(false);
            $table->timestamps();
        });

        // Internal notes on orders
        Schema::create('order_notes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->text('note');
            $table->boolean('is_customer_visible')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('order_notes');
        Schema::dropIfExists('order_status_histories');
        Schema::dropIfExists('order_items');
        Schema::dropIfExists('orders');
    }
};
