<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            // Brand Information
            [
                'group' => 'brand',
                'key' => 'brand_name',
                'value' => 'Shoily Zoon',
                'type' => 'string',
                'is_public' => true,
                'description' => 'Official Brand Display Name',
            ],
            [
                'group' => 'brand',
                'key' => 'brand_tagline_bn',
                'value' => 'শৈলী ও ঐতিহ্যের অনন্য সমাহার',
                'type' => 'string',
                'is_public' => true,
                'description' => 'Bengali Brand Tagline',
            ],
            [
                'group' => 'brand',
                'key' => 'brand_tagline_en',
                'value' => 'Elegance in Every Thread',
                'type' => 'string',
                'is_public' => true,
                'description' => 'English Brand Tagline',
            ],
            [
                'group' => 'brand',
                'key' => 'brand_logo',
                'value' => '/images/shoily-zoon-logo.svg',
                'type' => 'string',
                'is_public' => true,
                'description' => 'Storefront Header Logo Path',
            ],
            [
                'group' => 'brand',
                'key' => 'brand_favicon',
                'value' => '/favicon.ico',
                'type' => 'string',
                'is_public' => true,
                'description' => 'Browser Favicon URL',
            ],
            // Design Tokens
            [
                'group' => 'design',
                'key' => 'theme_colors',
                'value' => json_encode([
                    'primary' => '#202020',
                    'secondary' => '#D6C6AA',
                    'background' => '#F7F5F0',
                    'surface' => '#FFFFFF',
                    'text' => '#292929',
                    'accent' => '#C4A482',
                    'border' => '#E8E4DC',
                ]),
                'type' => 'json',
                'is_public' => true,
                'description' => 'Configurable Brand Design Palette',
            ],
            [
                'group' => 'design',
                'key' => 'typography',
                'value' => json_encode([
                    'font_family_bn' => "'Hind Siliguri', 'Noto Sans Bengali', sans-serif",
                    'font_family_en' => "'Playfair Display', 'Inter', serif",
                    'base_font_size' => '16px',
                ]),
                'type' => 'json',
                'is_public' => true,
                'description' => 'Typography Settings for Multilingual Rendering',
            ],
            // Contact & Business Information
            [
                'group' => 'contact',
                'key' => 'contact_email',
                'value' => 'contact@shoilyzoon.com',
                'type' => 'string',
                'is_public' => true,
                'description' => 'Customer Care Email',
            ],
            [
                'group' => 'contact',
                'key' => 'contact_phone',
                'value' => '+880 1700-000000',
                'type' => 'string',
                'is_public' => true,
                'description' => 'Customer Helpline',
            ],
            [
                'group' => 'contact',
                'key' => 'business_address',
                'value' => 'House #12, Road #4, Dhanmondi, Dhaka-1205, Bangladesh',
                'type' => 'string',
                'is_public' => true,
                'description' => 'Physical Headquarters Address',
            ],
            [
                'group' => 'contact',
                'key' => 'social_links',
                'value' => json_encode([
                    'facebook' => 'https://facebook.com/shoilyzoon',
                    'instagram' => 'https://instagram.com/shoilyzoon',
                    'youtube' => 'https://youtube.com/@shoilyzoon',
                ]),
                'type' => 'json',
                'is_public' => true,
                'description' => 'Official Social Media Profiles',
            ],
            // Localization & Markets
            [
                'group' => 'localization',
                'key' => 'default_locale',
                'value' => 'bn',
                'type' => 'string',
                'is_public' => true,
                'description' => 'Default Storefront Language',
            ],
            [
                'group' => 'localization',
                'key' => 'supported_locales',
                'value' => json_encode(['bn', 'en']),
                'type' => 'json',
                'is_public' => true,
                'description' => 'Supported Language Codes',
            ],
            [
                'group' => 'localization',
                'key' => 'default_currency',
                'value' => 'BDT',
                'type' => 'string',
                'is_public' => true,
                'description' => 'Default Store Currency Code',
            ],
            [
                'group' => 'localization',
                'key' => 'supported_currencies',
                'value' => json_encode(['BDT', 'USD', 'EUR', 'GBP', 'AED', 'SAR']),
                'type' => 'json',
                'is_public' => true,
                'description' => 'Available Currencies for Multi-currency Checkout',
            ],
            // Shipping Defaults
            [
                'group' => 'shipping',
                'key' => 'shipping_config',
                'value' => json_encode([
                    'inside_dhaka_rate' => 70.00,
                    'outside_dhaka_rate' => 130.00,
                    'free_shipping_threshold' => 3000.00,
                    'international_shipping_enabled' => true,
                ]),
                'type' => 'json',
                'is_public' => true,
                'description' => 'Baseline Shipping Rules and Thresholds',
            ],
            // Payment Gateway Flags
            [
                'group' => 'payment',
                'key' => 'payment_methods_active',
                'value' => json_encode([
                    'cod' => true,
                    'bkash' => true,
                    'nagad' => true,
                    'sslcommerz' => true,
                    'card_international' => true,
                ]),
                'type' => 'json',
                'is_public' => true,
                'description' => 'Active Payment Gateways',
            ],
            // SEO Meta Defaults
            [
                'group' => 'seo',
                'key' => 'seo_meta',
                'value' => json_encode([
                    'meta_title' => 'Shoily Zoon | শৌখিন ফ্যাশন ও পোশাক সম্ভার',
                    'meta_description' => 'প্রিমিয়াম মানের শাড়ি, পাঞ্জাবি, কুর্তি ও আধুনিক ফ্যাশন অ্যাক্সেসরিজ। সমগ্র বাংলাদেশ ও বিশ্বব্যাপী নির্ভরযোগ্য ডেলিভারি।',
                    'meta_keywords' => 'shoily zoon, fashion bangladesh, saree, panjabi, kurtis, dhaka fashion, luxury clothing',
                ]),
                'type' => 'json',
                'is_public' => true,
                'description' => 'Default Global SEO Metadata',
            ],
        ];

        foreach ($settings as $setting) {
            Setting::updateOrCreate(['key' => $setting['key']], $setting);
        }
    }
}
