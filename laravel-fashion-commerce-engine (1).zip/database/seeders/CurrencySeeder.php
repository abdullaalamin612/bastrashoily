<?php

namespace Database\Seeders;

use App\Models\Currency;
use Illuminate\Database\Seeder;

class CurrencySeeder extends Seeder
{
    public function run(): void
    {
        $currencies = [
            [
                'code' => 'BDT',
                'name' => 'Bangladeshi Taka',
                'symbol' => '৳',
                'exchange_rate' => 1.000000,
                'format' => '৳:value',
                'decimal_places' => 2,
                'is_default' => true,
                'is_active' => true,
            ],
            [
                'code' => 'USD',
                'name' => 'US Dollar',
                'symbol' => '$',
                'exchange_rate' => 0.008333, // 1 BDT = ~0.00833 USD (~120 BDT/USD)
                'format' => '$:value',
                'decimal_places' => 2,
                'is_default' => false,
                'is_active' => true,
            ],
            [
                'code' => 'EUR',
                'name' => 'Euro',
                'symbol' => '€',
                'exchange_rate' => 0.007800,
                'format' => '€:value',
                'decimal_places' => 2,
                'is_default' => false,
                'is_active' => true,
            ],
            [
                'code' => 'GBP',
                'name' => 'British Pound',
                'symbol' => '£',
                'exchange_rate' => 0.006600,
                'format' => '£:value',
                'decimal_places' => 2,
                'is_default' => false,
                'is_active' => true,
            ],
            [
                'code' => 'AED',
                'name' => 'UAE Dirham',
                'symbol' => 'د.إ',
                'exchange_rate' => 0.030600,
                'format' => ':value د.إ',
                'decimal_places' => 2,
                'is_default' => false,
                'is_active' => true,
            ],
            [
                'code' => 'SAR',
                'name' => 'Saudi Riyal',
                'symbol' => '﷼',
                'exchange_rate' => 0.031200,
                'format' => ':value ﷼',
                'decimal_places' => 2,
                'is_default' => false,
                'is_active' => true,
            ],
        ];

        foreach ($currencies as $curr) {
            Currency::updateOrCreate(['code' => $curr['code']], $curr);
        }
    }
}
