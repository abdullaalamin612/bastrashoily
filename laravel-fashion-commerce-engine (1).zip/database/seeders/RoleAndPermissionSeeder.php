<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class RoleAndPermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            // Dashboard
            ['name' => 'View Dashboard', 'slug' => 'view-dashboard', 'group' => 'dashboard'],
            // Catalog
            ['name' => 'Manage Products', 'slug' => 'manage-products', 'group' => 'catalog'],
            ['name' => 'Manage Categories', 'slug' => 'manage-categories', 'group' => 'catalog'],
            ['name' => 'Manage Brands', 'slug' => 'manage-brands', 'group' => 'catalog'],
            // Orders & Shipping
            ['name' => 'Manage Orders', 'slug' => 'manage-orders', 'group' => 'orders'],
            ['name' => 'Process Shipments', 'slug' => 'process-shipments', 'group' => 'shipping'],
            // Inventory
            ['name' => 'Manage Inventory', 'slug' => 'manage-inventory', 'group' => 'inventory'],
            // Customers
            ['name' => 'Manage Customers', 'slug' => 'manage-customers', 'group' => 'customers'],
            // Settings & Security
            ['name' => 'Manage Settings', 'slug' => 'manage-settings', 'group' => 'system'],
            ['name' => 'Manage Users & Roles', 'slug' => 'manage-users', 'group' => 'system'],
            ['name' => 'View Audit Logs', 'slug' => 'view-audit-logs', 'group' => 'system'],
        ];

        foreach ($permissions as $perm) {
            Permission::updateOrCreate(['slug' => $perm['slug']], $perm);
        }

        $allPermissionIds = Permission::pluck('id');

        // Roles
        $superAdmin = Role::updateOrCreate(
            ['slug' => 'super-admin'],
            [
                'name' => 'Super Administrator',
                'description' => 'Unrestricted access to all store and administrative systems',
                'is_system' => true,
            ]
        );
        $superAdmin->permissions()->sync($allPermissionIds);

        $admin = Role::updateOrCreate(
            ['slug' => 'admin'],
            [
                'name' => 'Store Administrator',
                'description' => 'Comprehensive management of catalog, orders, and store operations',
                'is_system' => true,
            ]
        );
        $admin->permissions()->sync(
            Permission::whereIn('group', ['dashboard', 'catalog', 'orders', 'shipping', 'inventory', 'customers'])->pluck('id')
        );

        $storeManager = Role::updateOrCreate(
            ['slug' => 'store-manager'],
            [
                'name' => 'Store Manager',
                'description' => 'Catalog and inventory supervisor',
                'is_system' => true,
            ]
        );
        $storeManager->permissions()->sync(
            Permission::whereIn('slug', ['view-dashboard', 'manage-products', 'manage-categories', 'manage-brands', 'manage-inventory'])->pluck('id')
        );

        $customer = Role::updateOrCreate(
            ['slug' => 'customer'],
            [
                'name' => 'Customer',
                'description' => 'Registered shopper',
                'is_system' => true,
            ]
        );

        // Seed Default Super Admin
        $adminUser = User::updateOrCreate(
            ['email' => 'admin@shoilyzoon.com'],
            [
                'name' => 'Shoily Zoon Administrator',
                'phone' => '+8801700000001',
                'password' => Hash::make('Admin@Shoily2026!'),
                'email_verified_at' => now(),
                'status' => 'active',
                'preferred_locale' => 'bn',
                'preferred_currency' => 'BDT',
            ]
        );
        $adminUser->roles()->syncWithoutDetaching([$superAdmin->id]);

        // Seed Sample Customer
        $customerUser = User::updateOrCreate(
            ['email' => 'customer@shoilyzoon.com'],
            [
                'name' => 'Nusrat Jahan',
                'phone' => '+8801800000002',
                'password' => Hash::make('Customer@Shoily2026!'),
                'email_verified_at' => now(),
                'status' => 'active',
                'preferred_locale' => 'bn',
                'preferred_currency' => 'BDT',
            ]
        );
        $customerUser->roles()->syncWithoutDetaching([$customer->id]);
    }
}
