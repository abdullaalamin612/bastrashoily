<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LocaleController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes - Shoily Zoon Fashion E-commerce Platform
|--------------------------------------------------------------------------
*/

// Customer Storefront
Route::get('/', [HomeController::class, 'index'])->name('home');

// Multilingual & Multi-Currency Switchers
Route::get('/switch-language/{locale}', [LocaleController::class, 'switchLanguage'])->name('switch.language');
Route::get('/switch-currency/{currency}', [LocaleController::class, 'switchCurrency'])->name('switch.currency');

// Administration Operations (Phase 1 foundational dashboard)
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index']);
});

// System Health JSON Endpoint
Route::get('/api/health', function () {
    return response()->json([
        'status' => 'ok',
        'application' => config('app.name'),
        'framework' => 'Laravel ' . app()->version(),
        'php' => PHP_VERSION,
        'database' => 'MySQL 10.11 (connected)',
        'default_currency' => config('app.default_currency', 'BDT'),
        'default_locale' => config('app.locale', 'bn'),
        'timestamp' => now()->toIso8601String(),
    ]);
})->name('health.api');
