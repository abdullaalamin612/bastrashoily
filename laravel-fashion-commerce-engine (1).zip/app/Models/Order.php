<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'order_number',
        'customer_id',
        'customer_name',
        'customer_phone',
        'customer_email',
        'shipping_address_snapshot',
        'billing_address_snapshot',
        'subtotal',
        'discount_amount',
        'shipping_cost',
        'tax_amount',
        'grand_total',
        'currency_code',
        'exchange_rate',
        'base_currency_total',
        'order_status',
        'payment_method',
        'payment_status',
        'payment_transaction_id',
        'customer_notes',
        'admin_notes',
        'idempotency_token',
        'confirmed_at',
        'shipped_at',
        'delivered_at',
        'cancelled_at',
    ];

    protected $casts = [
        'shipping_address_snapshot' => 'array',
        'billing_address_snapshot' => 'array',
        'subtotal' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'shipping_cost' => 'decimal:2',
        'tax_amount' => 'decimal:2',
        'grand_total' => 'decimal:2',
        'exchange_rate' => 'decimal:6',
        'base_currency_total' => 'decimal:2',
        'confirmed_at' => 'datetime',
        'shipped_at' => 'datetime',
        'delivered_at' => 'datetime',
        'cancelled_at' => 'datetime',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function statusHistories(): HasMany
    {
        return $this->hasMany(OrderStatusHistory::class)->latest();
    }

    public function notes(): HasMany
    {
        return $this->hasMany(OrderNote::class)->latest();
    }

    /**
     * Generate unique sequential order number, e.g. ORD-2026-0001
     */
    public static function generateOrderNumber(): string
    {
        $year = date('Y');
        $lastOrder = static::whereYear('created_at', $year)->latest('id')->first();
        $nextNumber = $lastOrder ? ((int) substr($lastOrder->order_number, -5)) + 1 : 1;

        return sprintf('ORD-%s-%05d', $year, $nextNumber);
    }

    /**
     * Change order status with automatic status history logging.
     */
    public function transitionTo(string $newStatus, ?string $comment = null, ?User $actor = null): self
    {
        return DB::transaction(function () use ($newStatus, $comment, $actor) {
            $fromStatus = $this->order_status;
            
            if ($fromStatus === $newStatus) {
                return $this;
            }

            $updateData = ['order_status' => $newStatus];

            if ($newStatus === 'confirmed' && ! $this->confirmed_at) {
                $updateData['confirmed_at'] = now();
            } elseif ($newStatus === 'shipped' && ! $this->shipped_at) {
                $updateData['shipped_at'] = now();
            } elseif ($newStatus === 'delivered' && ! $this->delivered_at) {
                $updateData['delivered_at'] = now();
                $updateData['payment_status'] = 'paid';
            } elseif ($newStatus === 'cancelled' && ! $this->cancelled_at) {
                $updateData['cancelled_at'] = now();
            }

            $this->update($updateData);

            $this->statusHistories()->create([
                'user_id' => $actor?->id ?? auth()->id(),
                'from_status' => $fromStatus,
                'to_status' => $newStatus,
                'comment' => $comment,
            ]);

            return $this;
        });
    }

    public function scopeStatus($query, string $status)
    {
        return $query->where('order_status', $status);
    }
}
