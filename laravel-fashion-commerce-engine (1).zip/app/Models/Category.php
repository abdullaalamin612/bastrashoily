<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'parent_id',
        'name_bn',
        'name_en',
        'slug',
        'description_bn',
        'description_en',
        'image',
        'thumbnail',
        'seo_title',
        'seo_description',
        'display_order',
        'is_active',
        'show_in_menu',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'show_in_menu' => 'boolean',
        'display_order' => 'integer',
    ];

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(Category::class, 'parent_id')->orderBy('display_order');
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class, 'category_id');
    }

    public function subcategoryProducts(): HasMany
    {
        return $this->hasMany(Product::class, 'subcategory_id');
    }

    public function sizeCharts(): HasMany
    {
        return $this->hasMany(SizeChart::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeRoots($query)
    {
        return $query->whereNull('parent_id');
    }

    /**
     * Get localized category name based on current locale.
     */
    public function getNameAttribute(): string
    {
        return app()->getLocale() === 'bn' ? $this->name_bn : ($this->name_en ?: $this->name_bn);
    }

    /**
     * Safety check: can this category be safely deleted?
     */
    public function canBeDeleted(): bool
    {
        return $this->products()->count() === 0 && $this->children()->count() === 0;
    }
}
