<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SizeChartRow extends Model
{
    use HasFactory;

    protected $fillable = [
        'size_chart_id',
        'size_code',
        'size_label',
        'measurements_inch',
        'measurements_cm',
        'sort_order',
    ];

    protected $casts = [
        'measurements_inch' => 'array',
        'measurements_cm' => 'array',
        'sort_order' => 'integer',
    ];

    public function sizeChart(): BelongsTo
    {
        return $this->belongsTo(SizeChart::class);
    }
}
