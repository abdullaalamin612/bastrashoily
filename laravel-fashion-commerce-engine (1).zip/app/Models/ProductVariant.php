<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductVariant extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'product_id',
        'product_color_id',
        'product_size_id',
        'sku',
        'purchase_cost',
        'regular_price',
        'sale_price',
        'variant_image',
        'is_active',
    ];

    protected $casts = [
        'purchase_cost' => 'decimal:2',
        'regular_price' => 'decimal:2',
        'sale_price' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function color(): BelongsTo
    {
        return $this->belongsTo(ProductColor::class, 'product_color_id');
    }

    public function size(): BelongsTo
    {
        return $this->belongsTo(ProductSize::class, 'product_size_id');
    }

    public function stock(): HasOne
    {
        return $this->hasOne(InventoryStock::class);
    }

    public function getEffectivePriceAttribute(): float
    {
        return (float) ($this->sale_price ?? $this->regular_price);
    }

    public function getAvailableStockAttribute(): int
    {
        return (int) ($this->stock?->available_quantity ?? 0);
    }

    public function getPhysicalStockAttribute(): int
    {
        return (int) ($this->stock?->physical_quantity ?? 0);
    }

    public function getIsInStockAttribute(): bool
    {
        return $this->is_active && $this->available_stock > 0;
    }

    public function getDisplayTitleAttribute(): string
    {
        $parts = [$this->product->name];
        if ($this->color) {
            $parts[] = $this->color->name;
        }
        if ($this->size) {
            $parts[] = $this->size->size_code;
        }

        return implode(' - ', $parts);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
