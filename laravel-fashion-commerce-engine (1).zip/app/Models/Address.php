<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Address extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'type',
        'is_default',
        'recipient_name',
        'phone',
        'alternative_phone',
        'email',
        'country_code',
        'division',
        'district',
        'upazila',
        'street_address',
        'postal_code',
        'landmark',
    ];

    protected $casts = [
        'is_default' => 'boolean',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Return formatted single line address string.
     */
    public function getFormattedAddressAttribute(): string
    {
        $parts = array_filter([
            $this->street_address,
            $this->landmark ? "(Near {$this->landmark})" : null,
            $this->upazila,
            $this->district,
            $this->division,
            $this->postal_code,
            $this->country_code === 'BD' ? 'Bangladesh' : $this->country_code,
        ]);

        return implode(', ', $parts);
    }
}
