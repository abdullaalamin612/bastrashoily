<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    use HasFactory;

    protected $fillable = [
        'code',
        'name',
        'symbol',
        'exchange_rate',
        'format',
        'decimal_places',
        'is_default',
        'is_active',
    ];

    protected $casts = [
        'exchange_rate' => 'decimal:6',
        'decimal_places' => 'integer',
        'is_default' => 'boolean',
        'is_active' => 'boolean',
    ];

    /**
     * Scope for active currencies.
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Get default currency.
     */
    public static function default(): ?self
    {
        return static::where('is_default', true)->first()
            ?? static::where('code', 'BDT')->first();
    }

    /**
     * Format a price amount in this currency.
     */
    public function formatAmount(float|int|string $amount): string
    {
        $formattedNumber = number_format((float) $amount, $this->decimal_places);
        
        // Handle format pattern e.g. ':symbol:value' or ':value :symbol'
        return str_replace(
            [':symbol', ':value', ':code'],
            [$this->symbol, $formattedNumber, $this->code],
            $this->format
        );
    }
}
