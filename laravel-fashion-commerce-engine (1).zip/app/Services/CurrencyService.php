<?php

namespace App\Services;

use App\Models\Currency;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;

class CurrencyService
{
    /**
     * Get all active currencies.
     */
    public function getActiveCurrencies(): Collection
    {
        return Cache::remember('currencies:active', 3600, function () {
            return Currency::active()->orderBy('is_default', 'desc')->get();
        });
    }

    /**
     * Get default currency.
     */
    public function getDefaultCurrency(): Currency
    {
        return Currency::default() ?? Currency::firstOrCreate(
            ['code' => 'BDT'],
            [
                'name' => 'Bangladeshi Taka',
                'symbol' => '৳',
                'exchange_rate' => 1.000000,
                'format' => '৳:value',
                'decimal_places' => 2,
                'is_default' => true,
                'is_active' => true,
            ]
        );
    }

    /**
     * Find currency by 3-letter code.
     */
    public function findByCode(string $code): ?Currency
    {
        return $this->getActiveCurrencies()->firstWhere('code', strtoupper($code));
    }

    /**
     * Convert an amount from BDT (base currency) to another currency.
     */
    public function convertFromBase(float|int $amountInBDT, string $targetCurrencyCode): float
    {
        $currency = $this->findByCode($targetCurrencyCode) ?? $this->getDefaultCurrency();
        return round($amountInBDT * (float) $currency->exchange_rate, $currency->decimal_places);
    }

    /**
     * Format money in specific currency.
     */
    public function format(float|int $amountInBDT, ?string $currencyCode = null): string
    {
        $currencyCode = $currencyCode ?? session('currency', 'BDT');
        $currency = $this->findByCode($currencyCode) ?? $this->getDefaultCurrency();
        $converted = $this->convertFromBase($amountInBDT, $currency->code);

        return $currency->formatAmount($converted);
    }
}
