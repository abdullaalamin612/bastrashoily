<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Support\Facades\Cache;

class SettingsService
{
    /**
     * Retrieve a setting by key with fallback default.
     */
    public function get(string $key, mixed $default = null): mixed
    {
        return Setting::get($key, $default);
    }

    /**
     * Set a setting in the database and clear cache.
     */
    public function set(string $key, mixed $value, string $group = 'general', string $type = 'string', bool $isPublic = false, ?string $description = null): Setting
    {
        return Setting::set($key, $value, $group, $type, $isPublic, $description);
    }

    /**
     * Retrieve all settings under a group.
     */
    public function getGroup(string $group): array
    {
        return Cache::remember("settings:group:{$group}", 3600, function () use ($group) {
            return Setting::where('group', $group)
                ->get()
                ->mapWithKeys(fn ($item) => [$item->key => $item->castValue()])
                ->toArray();
        });
    }

    /**
     * Retrieve all public settings for frontend asset injection.
     */
    public function getPublicSettings(): array
    {
        return Cache::remember('settings:public', 3600, function () {
            return Setting::where('is_public', true)
                ->get()
                ->mapWithKeys(fn ($item) => [$item->key => $item->castValue()])
                ->toArray();
        });
    }

    /**
     * Get design tokens for layout injection.
     */
    public function getDesignTokens(): array
    {
        return [
            'colors' => $this->get('theme_colors', [
                'primary' => '#202020',
                'secondary' => '#D6C6AA',
                'background' => '#F7F5F0',
                'surface' => '#FFFFFF',
                'text' => '#292929',
                'accent' => '#C4A482',
                'border' => '#E8E4DC',
            ]),
            'typography' => $this->get('typography', [
                'font_family_bn' => "'Hind Siliguri', 'Noto Sans Bengali', sans-serif",
                'font_family_en' => "'Playfair Display', 'Inter', serif",
            ]),
        ];
    }
}
