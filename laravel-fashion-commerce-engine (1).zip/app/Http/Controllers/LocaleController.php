<?php

namespace App\Http\Controllers;

use App\Models\Currency;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class LocaleController extends Controller
{
    /**
     * Switch language between Bengali and English.
     */
    public function switchLanguage(Request $request, string $locale): RedirectResponse
    {
        if (in_array($locale, ['bn', 'en'])) {
            session(['locale' => $locale]);

            if ($request->user()) {
                $request->user()->update(['preferred_locale' => $locale]);
            }
        }

        return back();
    }

    /**
     * Switch current shopping currency.
     */
    public function switchCurrency(Request $request, string $currency): RedirectResponse
    {
        $code = strtoupper($currency);
        if (Currency::where('code', $code)->where('is_active', true)->exists()) {
            session(['currency' => $code]);

            if ($request->user()) {
                $request->user()->update(['preferred_currency' => $code]);
            }
        }

        return back();
    }
}
