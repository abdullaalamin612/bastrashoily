<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use App\Models\Setting;
use App\Models\User;
use App\Services\SettingsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __construct(
        protected SettingsService $settingsService
    ) {}

    /**
     * Display the administrative overview.
     */
    public function index(Request $request): View
    {
        $dbStatus = 'Connected';
        try {
            DB::connection()->getPdo();
        } catch (\Throwable $e) {
            $dbStatus = 'Error: ' . $e->getMessage();
        }

        return view('admin.dashboard', [
            'brandName' => $this->settingsService->get('brand_name', 'Shoily Zoon'),
            'dbStatus' => $dbStatus,
            'userCount' => User::count(),
            'currencyCount' => Currency::count(),
            'settingCount' => Setting::count(),
        ]);
    }
}
