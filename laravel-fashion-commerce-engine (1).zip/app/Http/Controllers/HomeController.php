<?php

namespace App\Http\Controllers;

use App\Services\CurrencyService;
use App\Services\SettingsService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class HomeController extends Controller
{
    public function __construct(
        protected SettingsService $settingsService,
        protected CurrencyService $currencyService
    ) {}

    /**
     * Display the storefront home page.
     */
    public function index(Request $request): View
    {
        return view('pages.home', [
            'brandName' => $this->settingsService->get('brand_name', 'Shoily Zoon'),
            'currentCurrency' => session('currency', 'BDT'),
        ]);
    }
}
