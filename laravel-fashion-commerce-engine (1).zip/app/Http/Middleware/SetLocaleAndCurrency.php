<?php

namespace App\Http\Middleware;

use App\Models\Currency;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Symfony\Component\HttpFoundation\Response;

class SetLocaleAndCurrency
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        // 1. Locale handling: default to Bengali ('bn'), support English ('en')
        $locale = $request->query('lang');
        if ($locale && in_array($locale, ['bn', 'en'])) {
            session(['locale' => $locale]);
        } elseif (! session()->has('locale')) {
            $user = $request->user();
            $locale = $user?->preferred_locale ?? config('app.locale', 'bn');
            session(['locale' => $locale]);
        }

        App::setLocale(session('locale', 'bn'));

        // 2. Currency handling: default to 'BDT', support configurable currencies
        $currency = $request->query('currency');
        if ($currency && Currency::where('code', strtoupper($currency))->where('is_active', true)->exists()) {
            session(['currency' => strtoupper($currency)]);
        } elseif (! session()->has('currency')) {
            $user = $request->user();
            $currency = $user?->preferred_currency ?? config('app.default_currency', 'BDT');
            session(['currency' => $currency]);
        }

        return $next($request);
    }
}
